# Tania's Sound Box identity

Original mark: an amber waveform emerging through the opening of a sound box.
The dark tile is used by the app window and Linux launcher. The name is always
**Tania's Sound Box**, with no separating slash.

- `tanias-sound-box.svg`: scalable app icon.
- `logo.svg`: transparent horizontal logo for dark backgrounds.
- `logo-light.svg`: transparent horizontal logo for light backgrounds.
- `icon-32.png`, `icon-64.png`, `icon-256.png`, `icon-512.png`: desktop/Tk exports.

Current colours: navy #151d2b, amber #ffc66d, light text #e8edf5.
Wordmark font: DejaVu Sans Bold (SVG text uses the viewer's installed font).
Artwork follows the repository's AGPL-3.0-or-later license.
PNG exports can be regenerated with `python3 linux/scripts/export-logo.py`
using Pillow; Pillow is not a runtime dependency of Sound Box.
