# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
from mic_controls import validate,save,load,MIC_NAME,MIC_CAPTURE
from mic_graph import arguments,parameters,route,eligible
from mic_session import MicrophoneSession
from mic_presets import MicPresets
from mic_test import levels
from audio_backend import AudioError


def discovery(available=True,graph=True,ready=True):
    names=([('physical','Audio/Source',1)] if available else [])+([(MIC_CAPTURE,'Stream/Input/Audio',2),(MIC_NAME,'Audio/Source',3)] if graph else [])
    objects=[{'id':identity,'type':'PipeWire:Interface:Node','info':{'props':{'node.name':name,'media.class':kind,'audio.channels':2,**({'target.object':'physical'} if name==MIC_CAPTURE else {})}}} for name,kind,identity in names]
    if ready and available and graph:
        objects.extend({'id':10+port,'type':'PipeWire:Interface:Link','info':{'output-node-id':1,'input-node-id':2,'input-port-id':port,'state':'active'}} for port in (1,2))
    return {'connected':True,'inputs':([{'name':'physical','role':'input'}] if available else [])+([{'name':MIC_NAME,'role':'sound_box_microphone'}] if graph else []),'outputs':[]},objects

class MicLogicTests(unittest.TestCase):
    def test_controls_and_portable_settings(self):
        self.assertFalse(validate({})['muted']);self.assertFalse(validate({})['gate_enabled'])
        for values in ({'mode':'invented'},{'gate_attack':0},{'muted':1},{'highpass':float('nan')}):
            with self.assertRaises(ValueError):validate(values)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'microphone.json';values=validate({'gate_enabled':True,'mode':'Right channel'})
            save(values,'usb microphone',path);self.assertEqual(load(path),(values,'usb microphone'))
            before=path.read_bytes()
            with self.assertRaises(ValueError):save({'gain':99},'hw',path)
            self.assertEqual(path.read_bytes(),before)
    def test_bypass_mute_and_selected_target(self):
        values={'muted':True,'bypass':True,'gate_enabled':True,'deess_enabled':True,'compressor':True,'gain':12}
        params=parameters(values)
        self.assertEqual(params['left_gain:Gain 1'],0)
        self.assertEqual(params['right_gain:Gain 1'],0)
        for key in ('mic:HP Enabled','mic:Gate Enabled','mic:Deess Enabled','compressor:Enabled','limiter:Enabled'):
            self.assertEqual(params[key],0)
        with patch('mic_graph.limiter_plugin',return_value=Path('/plugin.so')),patch('processing_graph.limiter_plugin',return_value=Path('/plugin.so')):
            args=arguments('physical input',values)
        self.assertEqual(args['capture.props']['target.object'],'physical input')
        self.assertTrue(args['capture.props']['node.dont-reconnect'])
        self.assertEqual(args['playback.props']['node.name'],MIC_NAME)
        self.assertEqual(len(args['filter.graph']['inputs']),2)
        self.assertFalse(eligible({'name':MIC_NAME,'role':'sound_box_microphone'}))
    def test_route_requires_distinct_channels_and_correct_source(self):
        current,objects=discovery()
        self.assertTrue(route(objects,'physical')['ready'])
        self.assertFalse(route(objects,'another mic')['ready'])
        objects[-1]['info']['input-port-id']=1
        self.assertFalse(route(objects,'physical')['ready'])
    def test_lost_input_does_not_fallback_and_disable_cancels_recovery(self):
        session=MicrophoneSession();session.enabled=True;session.source='physical';session.controls=validate({'gain':-9})
        with patch.object(session,'read',return_value=discovery(available=False)),patch.object(session,'launch') as launch:
            result=session.poll();self.assertEqual(result['microphone']['state'],'waiting_input');launch.assert_not_called()
            self.assertEqual(session.controls['gain'],-9)
            session.disable();session.poll();launch.assert_not_called();self.assertFalse(session.enabled)
    def test_apply_loss_queues_complete_controls_without_false_confirmation(self):
        session=MicrophoneSession();session.enabled=True;session.source='physical'
        with patch.object(session,'read',return_value=discovery(graph=False,ready=False)):
            result=session.apply({'gain':-6,'muted':True})
        self.assertIsNone(result['microphone']['confirmed_controls'])
        self.assertEqual(result['microphone']['desired_controls']['gain'],-6)
    def test_presets_and_recording_measurements(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);presets=MicPresets(root/'library.json')
            presets.export(root/'export.json','Natural voice',{'deess_enabled':True})
            name,values=presets.decode(root/'export.json');presets.save(name,values)
            self.assertTrue(presets.all()[name]['deess_enabled'])
            (root/'wrong.json').write_text(json.dumps({'schema':1,'name':'Playback','controls':{}}))
            with self.assertRaises(ValueError):presets.decode(root/'wrong.json')
        stats=levels([0,.5,-.5,1,float('nan')]);self.assertEqual(stats['peak_db'],0)
        self.assertEqual(stats['clipped_samples'],1);self.assertEqual(levels([0])['peak_db'],-120)

if __name__=='__main__':unittest.main()
