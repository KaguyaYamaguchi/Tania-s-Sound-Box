// SPDX-License-Identifier: AGPL-3.0-or-later
#include "AudioProcessor.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
int main() {
    try {
        tania::AudioProcessor processor;
        tania::Controls controls;
        std::vector<float> samples{0.2f,-0.3f,0.4f,0.1f};
        auto original=samples;
        processor.configure(48000,controls); processor.process(samples.data(),2);
        check(samples==original,"flat response must preserve samples");
        controls.gainDb=6;
        processor.configure(48000,controls); samples=original; processor.process(samples.data(),2);
        check(std::abs(samples[0]/original[0]-std::pow(10,0.3))<1e-6,"gain conversion");
        controls.balance=-100;
        processor.configure(48000,controls); samples=original; processor.process(samples.data(),2);
        check(samples[1]==0 && samples[3]==0 && samples[0]!=0,"left balance endpoint");
        controls.balance=100;
        processor.configure(48000,controls); samples=original; processor.process(samples.data(),2);
        check(samples[0]==0 && samples[2]==0 && samples[1]!=0,"right balance endpoint");
        controls.bypass=true;
        processor.configure(48000,controls); samples=original; processor.process(samples.data(),2);
        check(samples==original,"bypass must preserve samples");
        for (double rate : {44100.,48000.,96000.}) {
            for (double db : {-12.,12.}) {
                controls={}; controls.eqDb[4]=db;
                processor.configure(rate,controls);
                samples.resize(static_cast<std::size_t>(rate)*2);
                for (std::size_t i=0;i<samples.size()/2;++i) {
                    samples[i*2]=static_cast<float>(0.1*std::sin(2*std::acos(-1.)*1000*i/rate));
                    samples[i*2+1]=0;
                }
                processor.process(samples.data(),samples.size()/2);
                double energy=0;
                for (std::size_t i=samples.size()/4;i<samples.size()/2;++i) {
                    energy+=samples[i*2]*samples[i*2];
                    check(samples[i*2+1]==0,"no channel crosstalk");
                }
                const double amplitude=std::sqrt(energy/(samples.size()/4)*2)/0.1;
                check(std::abs(20*std::log10(amplitude)-db)<0.02,"EQ center response");
            }
        }
        controls={}; controls.eqDb.fill(12);
        processor.configure(48000,controls);
        tania::AudioProcessor split; split.configure(48000,controls);
        samples.assign(8192,0); samples[0]=0.1f; original=samples;
        processor.process(samples.data(),4096);
        split.process(original.data(),100); split.process(original.data()+200,3996);
        check(samples==original,"filter state must survive block boundaries");
        for (float sample : samples) check(std::isfinite(sample),"impulse stability");
        bool rejected=false;
        controls.gainDb=std::numeric_limits<double>::quiet_NaN();
        try { processor.configure(48000,controls); } catch(const std::invalid_argument&) { rejected=true; }
        check(rejected,"invalid control validation");
        std::cout<<"DSP checks passed\n";
    } catch(const std::exception& error) { std::cerr<<error.what()<<'\n'; return 1; }
}
