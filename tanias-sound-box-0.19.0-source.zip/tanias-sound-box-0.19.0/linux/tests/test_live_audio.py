"""Opt-in live PipeWire test with isolated nodes and no hardware playback."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from array import array
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import wave
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
import processing_graph as graph
from audio_backend import raw_snapshot


def check_audio(rate=48000):
    suffix=str(os.getpid())
    graph.PLAYBACK_NAME='tanias_sound_box.test_playback.'+suffix
    graph.MONITOR_NAME='tanias_sound_box.test_monitor.'+suffix
    with tempfile.TemporaryDirectory(prefix='tania-live-test-') as d:
        folder=Path(d)
        config=folder/'test.conf';config.write_text(graph.graph_configuration())
        input_file=folder/'tone.wav'
        samples=array('h')
        for frame in range(rate):
            sample=round(.02*32767*math.sin(2*math.pi*1000*frame/rate))
            samples.extend((sample,sample))
        if sys.byteorder!='little':samples.byteswap()
        with wave.open(str(input_file),'wb') as stream:
            stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(rate)
            stream.writeframes(samples.tobytes())
        with tempfile.TemporaryFile() as log:
            client=subprocess.Popen(graph.graph_command(config),stdout=log,stderr=log)
            try:
                deadline=time.monotonic()+5
                while graph.processing_node(raw_snapshot()) is None:
                    if time.monotonic()>deadline or client.poll() is not None:
                        log.seek(0);raise AssertionError(log.read().decode(errors='replace'))
                    time.sleep(.05)
                def measure(values,bypass=False):
                    graph.apply_controls(values,bypass)
                    output=folder/'capture.wav'
                    properties='application.name = "Tania DSP Test '+suffix+'" media.role = "DSPTest'+suffix+'" state.restore-props = false state.restore-target = false state.default-volume = 1.0'
                    recorder=subprocess.Popen(['pw-record','--target',graph.MONITOR_NAME,
                        '--rate',str(rate),'--channels','2','--format','s16','--volume','1',
                        '-P',properties,str(output)],
                        stdout=log,stderr=log)
                    try:
                        time.sleep(.2)
                        subprocess.run(['pw-play','--target',graph.PLAYBACK_NAME,'--volume','1',
                                        '-P',properties,str(input_file)],
                                       stdout=log,stderr=log,check=True,timeout=5)
                        time.sleep(.15)
                    finally:
                        recorder.terminate();recorder.wait(timeout=3)
                    with wave.open(str(output),'rb') as stream:
                        assert stream.getnchannels()==2 and stream.getsampwidth()==2
                        captured=array('h',stream.readframes(stream.getnframes()))
                    if sys.byteorder!='little':captured.byteswap()
                    # Peak of a steady sinusoid; exclude brief filter startup by
                    # using the median of 50 ms blocks containing the test tone.
                    amplitudes=[]
                    block=rate//20*2
                    for channel in (0,1):
                        peaks=[max(abs(sample) for sample in captured[start+channel:start+block:2])/32767
                               for start in range(0,len(captured)-block,block)]
                        peaks=[peak for peak in peaks if peak>.0001]
                        assert peaks,'No recorded test audio'
                        peaks.sort();amplitudes.append(peaks[len(peaks)//2])
                    return amplitudes
                for values,bypass,expected in (
                    ({'gain':-6,'balance':50},False,(.02*10**(-.3)*.5,.02*10**(-.3))),
                    ({'eq_1000':6},False,(.02*10**(.3),.02*10**(.3))),
                    ({'gain':12,'balance':50,'eq_1000':12,'ceiling':-12},False,(10**(-.6)*.5,10**(-.6))),
                    ({'gain':12,'eq_1000':12,'limiter':False},False,(.02*10**(1.2),.02*10**(1.2))),
                    ({'gain':-12,'balance':100,'eq_1000':12},True,(.02,.02))):
                    measured=measure(values,bypass)
                    for actual,wanted in zip(measured,expected):
                        assert abs(actual-wanted)<.001,(measured,expected)
                    print('Measured live monitor amplitudes:',[round(value,5) for value in measured])
                compressed=measure({'compressor':True, 'threshold':-40, 'ratio':4, 'attack':1, 'compressor_release':2000, 'balance':50})
                wanted=10**((-40+(20*math.log10(.02)+40)/4)/20)
                assert abs(compressed[1]-wanted)<.001,(compressed,wanted)
                assert abs(compressed[0]*2-compressed[1])<.0001,compressed
                print('Measured live compressor amplitudes:',compressed)
                print('Live gain, stereo balance, EQ, linked limiter ceiling, disabled limiter, bypass, and stereo-linked compression capture passed.')
            finally:
                client.terminate();client.wait(timeout=3)


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--rate',type=int,choices=(44100,48000,96000),default=48000)
    check_audio(parser.parse_args().rate)
