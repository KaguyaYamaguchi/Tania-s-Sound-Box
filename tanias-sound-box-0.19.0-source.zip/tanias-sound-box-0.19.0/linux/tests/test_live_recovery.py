"""Opt-in owned-client recovery check. Never restarts the user's audio server."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from session import AudioSession
from audio_backend import snapshot, raw_snapshot, MONITOR_NAME
from processing_graph import processing_node, node_controls

def monitor_id():
    return next(o['id'] for o in raw_snapshot() if o.get('info', {}).get('props', {}).get('node.name') == MONITOR_NAME)

current = snapshot()
hardware = [o for o in current['outputs'] if o['role'] == 'hardware_output']
assert hardware, 'A hardware output is required'
target = next((o['name'] for o in hardware if o['default']), hardware[0]['name'])
session = AudioSession()
try:
    session.enable(target, {'gain': -6, 'compressor': True, 'threshold': -24})
    original = monitor_id()
    session.devices.detach_hardware()
    assert session.poll()['routing']['ready']
    assert monitor_id() == original, 'Route repair changed OBS source identity'
    session.devices.end_process(session.devices.processes[0])
    assert session.poll()['routing']['ready']
    controls = node_controls(processing_node(raw_snapshot()))
    assert abs(controls['left_gain:Gain 1'] - 10**(-6/20)) < 1e-5
    assert controls['compressor:Enabled']
    assert controls['compressor:Threshold dB'] == -24
    print('Hardware repair preserved OBS source; graph recovery restored gain and dynamics.')
finally:
    session.disable()
