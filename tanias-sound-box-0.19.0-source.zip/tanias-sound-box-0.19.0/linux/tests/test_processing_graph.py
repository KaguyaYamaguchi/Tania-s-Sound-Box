# SPDX-License-Identifier: AGPL-3.0-or-later
import json, math, os
from pathlib import Path
import sys, tempfile, unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
from controls import BANDS,validate,save_settings,settings_path
from processing_graph import graph_arguments,control_params,apply_controls,transition_params,parameter_batches
from audio_backend import AudioError,parse_snapshot,PLAYBACK_NAME

class GraphTests(unittest.TestCase):
    def test_stereo_graph_connectivity(self):
        graph=graph_arguments()['filter.graph']
        self.assertEqual(len(graph['nodes']),22)
        self.assertEqual(len(graph['links']),22)
        self.assertEqual(len(graph['inputs']),2)
        self.assertEqual(len(graph['outputs']),2)
        for link in graph['links']:
            if not link['input'].startswith(('limiter:', 'compressor:')):
                self.assertEqual(link['input'].split('_')[0],link['output'].split('_')[0])

    def test_gain_balance_and_eq(self):
        params=control_params({'gain':6,'balance':100,'eq_1000':-3})
        self.assertEqual(params['left_gain:Gain 1'],0)
        self.assertAlmostEqual(params['right_gain:Gain 1'],10**.3)
        self.assertEqual(params['left_eq_1000:Gain'],-3)
        self.assertEqual(params['right_eq_1000:Gain'],-3)
        params=control_params({'balance':-100})
        self.assertEqual(params['right_gain:Gain 1'],0)
        self.assertEqual(params['left_gain:Gain 1'],1)

    def test_bypass_neutralizes_all_processing(self):
        params=control_params({'gain':12,'balance':-100,'eq_60':12},bypass=True)
        for key,value in params.items():
            if 'eq_' in key: self.assertEqual(value,0)
            elif '_gain:' in key: self.assertEqual(value,1)
        self.assertEqual(params['limiter:Enabled'],0)
        nodes=graph_arguments({'gain':12,'eq_60':12,'bypass':True})['filter.graph']['nodes']
        for node in nodes:
            if node['label']=='bq_peaking': self.assertEqual(node['control']['Gain'],0)
            elif node['label']=='mixer': self.assertEqual(node['control']['Gain 1'],1)
            else: self.assertEqual(node['control']['Enabled'],0)

    def test_smoothing_and_bounded_batches(self):
        initial=control_params({'gain':-12,'limiter':False})
        target=control_params({'gain':12,'limiter':True,'eq_1000':6})
        transition=transition_params(initial,target)
        self.assertEqual(transition[-1],target)
        self.assertEqual(transition[0]['limiter:Enabled'],1)
        gains=[initial['left_gain:Gain 1']]+[step['left_gain:Gain 1'] for step in transition]
        self.assertEqual(gains,sorted(gains))
        for step in transition:
            batches=parameter_batches(step)
            self.assertTrue(all(len(batch)<=8 for batch in batches))
            self.assertEqual({key:value for batch in batches for key,value in batch.items()},step)
        disabled=transition_params(target,initial)
        self.assertEqual(disabled[-1]['limiter:Enabled'],0)
        self.assertTrue(all(step['limiter:Enabled']==1 for step in disabled[:-1]))

    def test_settings_legacy_and_round_trip(self):
        self.assertFalse(validate({})['bypass'])
        self.assertTrue(validate({})['limiter'])
        self.assertEqual(validate({})['ceiling'],-1)
        self.assertEqual(validate({})['release'],100)
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'settings.json'
            save_settings(path,{'gain':-6,'bypass':True})
            self.assertTrue(validate(json.loads(path.read_text()))['bypass'])
            self.assertEqual(validate(json.loads(path.read_text()))['gain'],-6)
        for data in ({'bypass':1},{'gain':float('nan')},{'gain':True},{'eq_60':13}):
            with self.assertRaises(ValueError):validate(data)

    def test_processing_status(self):
        node={'type':'PipeWire:Interface:Node','info':{'props':{
            'node.name':PLAYBACK_NAME,'media.class':'Audio/Sink','tania.processing':True}}}
        self.assertTrue(parse_snapshot([node])['processing'])

    @patch('processing_graph.raw_snapshot',return_value=[])
    def test_apply_rejects_missing_graph(self, snapshot):
        with self.assertRaises(AudioError): apply_controls({})

if __name__=='__main__':unittest.main()
