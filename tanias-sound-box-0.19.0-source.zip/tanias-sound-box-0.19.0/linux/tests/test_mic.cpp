// SPDX-License-Identifier: AGPL-3.0-or-later
#include "MicTools.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
void check(bool value,const char* message) { if(!value) throw std::runtime_error(message); }
int main() {
 try {
    for(double rate : {44100.,48000.,96000.}) {
        tania::MicTools tools(rate);tania::MicControls c;c.highpass=false;
        std::vector<float> l(static_cast<std::size_t>(rate),.2f),r(l.size(),.1f),ol(l.size()),orr(l.size());
        tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);
        check(std::abs(ol.back()-.15f)<1e-6 && ol==orr,"mono mix failed");
        c.mode=1;tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);check(ol==l && orr==l,"left selection");
        c.mode=2;tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);check(ol==r && orr==r,"right selection");
        c.mode=3;c.highpass=true;tools.reset();tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);
        check(std::abs(ol.back())<1e-8,"highpass DC rejection");
        c.highpass=false;c.gate=true;c.thresholdDb=-20;c.rangeDb=-60;c.holdMs=0;c.releaseMs=10;
        l.assign(l.size(),.001f);r.assign(l.size(),.0005f);tools.reset();
        tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);
        check(std::abs(ol.back()-1e-6)<1e-8 && std::abs(orr.back()-5e-7)<1e-8,"gate floor/stereo linking");
        l.assign(l.size(),.5f);r.assign(l.size(),.25f);tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);
        check(std::abs(ol.back()-.5f)<1e-6,"gate attack/open");
        c.gate=false;c.deess=true;c.deessHz=4000;c.deessThresholdDb=-30;c.deessRatio=8;
        for(std::size_t i=0;i<l.size();++i) { l[i]=static_cast<float>(.2*std::sin(2*std::acos(-1.)*8000*i/rate));r[i]=l[i]*.5f; }
        tools.reset();tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);
        double input=0,output=0;
        for(std::size_t i=l.size()/2;i<l.size();++i) { input+=l[i]*l[i];output+=ol[i]*ol[i];check(std::abs(ol[i]*.5f-orr[i])<1e-6,"deess stereo image"); }
        check(output<input*.8,"deesser did not reduce high frequency");
        c.deess=false;c.highpass=false;tools.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),c);check(ol==l && orr==r,"neutral stereo transparency");
        l[0]=std::numeric_limits<float>::quiet_NaN();r[0]=std::numeric_limits<float>::infinity();tools.reset();
        tools.process(l.data(),r.data(),ol.data(),orr.data(),1,c);check(ol[0]==0 && orr[0]==0,"nonfinite mic input");
    }
    std::cout<<"Mic channel mapping, highpass, gate, deesser, bypass and nonfinite checks passed.\n";
 } catch(const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
