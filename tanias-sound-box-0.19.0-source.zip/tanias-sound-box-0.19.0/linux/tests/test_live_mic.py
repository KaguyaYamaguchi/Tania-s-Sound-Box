"""Generated virtual microphone only; never opens a physical microphone."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from array import array
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import wave
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
from audio_backend import raw_snapshot
from mic_controls import MIC_NAME,MIC_CAPTURE
from mic_session import MicrophoneSession
from mic_test import LevelMeter,MicRecording,properties
from processing_graph import named_node
from virtual_devices import VirtualDevices


def run():
    suffix=str(os.getpid());sink='tania_mic_test.sink.'+suffix;source='tania_mic_test.source.'+suffix
    session=MicrophoneSession();meter=LevelMeter();recording=MicRecording()
    with tempfile.TemporaryDirectory() as d,tempfile.TemporaryFile() as log:
        folder=Path(d);rate=48000
        tone=folder/'tone.wav';samples=array('h')
        for frame in range(rate*6):
            v=math.sin(2*math.pi*1000*frame/rate);samples.extend((round(.04*32767*v),round(.02*32767*v)))
        if sys.byteorder!='little':samples.byteswap()
        with wave.open(str(tone),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(rate);w.writeframes(samples.tobytes())
        common={'audio.position':['FL','FR'],'audio.channels':2,'node.virtual':True,'priority.session':1}
        generator=subprocess.Popen(['pw-loopback','--capture-props',json.dumps({**common,'node.name':sink,'media.class':'Audio/Sink'}),
                                    '--playback-props',json.dumps({**common,'node.name':source,'media.class':'Audio/Source'})],stdout=log,stderr=log)
        player=None
        try:
            deadline=time.monotonic()+6
            while named_node(raw_snapshot(),source) is None:
                assert time.monotonic()<deadline and generator.poll() is None
                time.sleep(.05)
            result=session.enable(source,{'gain':-6,'highpass_enabled':False})
            assert result['microphone']['route']['ready'],result['microphone']
            original=named_node(raw_snapshot(),MIC_NAME)['id']
            meter.start(MIC_NAME)
            player=subprocess.Popen(['pw-play','--target',sink,'--volume','1','-P',properties(),str(tone)],stdout=log,stderr=log)
            stats=recording.record(MIC_NAME,seconds=3)
            expected=.03*10**(-6/20)
            peak=10**(stats['peak_db']/20)
            assert abs(peak-expected)<.001,(peak,expected)
            measured=meter.latest();assert measured and abs(10**(measured['peak_db']/20)-expected)<.001,measured
            recording.export(folder/'export.wav');assert (folder/'export.wav').stat().st_size>100
            session.mute(True)
            assert named_node(raw_snapshot(),MIC_NAME)['id']==original
            time.sleep(.25)
            assert meter.latest()['peak_db']<=-100,meter.latest()
            session.apply({'gain':12,'highpass_enabled':False,'ceiling':-12})
            time.sleep(.25)
            assert meter.latest()['peak_db']<=-12+.1,meter.latest()
            player.wait(timeout=8);player=None
            session.disable();assert not session.active
            print('Live virtual-mic route, mono mix/gain, level meter, recording/export, mute, limiter and stable node identity passed.')
        finally:
            meter.stop();recording.close();session.disable()
            if player is not None:VirtualDevices.end_process(player)
            VirtualDevices.end_process(generator)

if __name__=='__main__':
    try:
        run()
        Path('build/validation/live-mic-result.txt').write_text('PASS: generated virtual microphone only; routing, gain/mono, meter, record/export, mute, limiter, stable identity.\n')
    except Exception as error:
        Path('build/validation/live-mic-result.txt').write_text('FAIL: '+str(error)+'\n')
        raise
