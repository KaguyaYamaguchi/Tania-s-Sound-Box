# SPDX-License-Identifier: AGPL-3.0-or-later
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from audio_backend import AudioError, PLAYBACK_NAME, MONITOR_NAME
from virtual_devices import commands, VirtualDevices, PLAYBACK_LABEL, MONITOR_LABEL

class DeviceTests(unittest.TestCase):
    def test_routing_names_and_monitor_capture(self):
        graph, hardware=commands('hardware with spaces', '/tmp/test-graph.conf')
        props=lambda cmd, flag: json.loads(cmd[cmd.index(flag)+1])
        from processing_graph import graph_arguments
        config=graph_arguments()
        self.assertEqual(graph, ['pipewire', '-c', '/tmp/test-graph.conf'])
        self.assertEqual(config['capture.props']['node.description'],PLAYBACK_LABEL)
        self.assertEqual(config['capture.props']['node.name'],PLAYBACK_NAME)
        self.assertEqual(config['playback.props']['node.name'],MONITOR_NAME)
        self.assertEqual(config['playback.props']['node.description'],MONITOR_LABEL)
        self.assertEqual(config['playback.props']['media.class'],'Audio/Source')
        self.assertEqual(props(hardware,'--playback-props')['target.object'],'hardware with spaces')
        self.assertTrue(props(hardware,'--playback-props')['node.dont-reconnect'])
        self.assertEqual(props(hardware,'--capture-props')['target.object'],MONITOR_NAME)

    @patch('virtual_devices.snapshot')
    def test_missing_hardware_and_duplicate_nodes(self, snapshot):
        devices=VirtualDevices()
        snapshot.return_value={'outputs':[],'inputs':[]}
        with self.assertRaises(AudioError): devices.start('removed')
        snapshot.return_value={'outputs':[{'name':'hardware','role':'hardware_output'},
            {'name':PLAYBACK_NAME,'role':'sound_box_playback'}],'inputs':[]}
        with self.assertRaises(AudioError): devices.start('hardware')
        self.assertFalse(devices.processes)

    def test_stop_is_owned_and_idempotent(self):
        devices=VirtualDevices()
        first, second=Mock(),Mock()
        first.poll.return_value=second.poll.return_value=None
        devices.processes=[first,second]
        self.assertTrue(devices.active)
        devices.stop(); devices.stop()
        first.terminate.assert_called_once(); second.terminate.assert_called_once()
        self.assertFalse(devices.active)

    def test_guardian_survives_launching_worker_thread(self):
        import os, subprocess, threading, time
        import virtual_devices
        launched = []
        def launch():
            launched.append(subprocess.Popen([sys.executable, virtual_devices.__file__,
                '--owned-loopback', str(os.getpid()), sys.executable, '-c',
                'import time; time.sleep(30)']))
        thread = threading.Thread(target=launch)
        thread.start(); thread.join()
        guardian = launched[0]
        try:
            time.sleep(0.2)
            self.assertIsNone(guardian.poll())
        finally:
            guardian.terminate(); guardian.wait(timeout=3)

    def test_parent_crash_removes_owned_child_and_temporary_config(self):
        import os, subprocess, tempfile, time
        import virtual_devices
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            config_dir=root/'tanias-sound-box-crash-test';config_dir.mkdir()
            config=config_dir/'processing.conf'
            child_pid=root/'child.pid';guardian_pid=root/'guardian.pid'
            config.write_text(str(child_pid))
            fake=root/'pipewire'
            fake.write_text('#!'+sys.executable+'\nimport os,sys,time\nfrom pathlib import Path\nPath(Path(sys.argv[2]).read_text()).write_text(str(os.getpid()))\ntime.sleep(30)\n')
            fake.chmod(0o755)
            command=[sys.executable,virtual_devices.__file__,'--owned-loopback']
            launcher="""import os,sys,subprocess,time
from pathlib import Path
command=__import__('json').loads(sys.argv[1])
child=subprocess.Popen(command+[str(os.getpid()),'pipewire','-c',sys.argv[2]])
Path(sys.argv[3]).write_text(str(child.pid))
time.sleep(30)
"""
            env={**os.environ,'PATH':str(root)+os.pathsep+os.environ.get('PATH','')}
            parent=subprocess.Popen([sys.executable,'-c',launcher,json.dumps(command),str(config),str(guardian_pid)],env=env)
            def running(pid):
                try:
                    # An exited orphan may await PID 1's reaping as a zombie.
                    return Path(f'/proc/{pid}/stat').read_text().split(') ',1)[1].split()[0]!='Z'
                except FileNotFoundError:return False
            guardian=None
            try:
                deadline=time.monotonic()+5
                while not child_pid.exists():
                    self.assertLess(time.monotonic(),deadline,'Guardian child did not start')
                    time.sleep(.02)
                guardian=int(guardian_pid.read_text());child=int(child_pid.read_text())
                parent.kill();parent.wait(timeout=2)
                deadline=time.monotonic()+5
                while config_dir.exists() or running(child):
                    self.assertLess(time.monotonic(),deadline,'Owned child/config survived parent crash')
                    time.sleep(.02)
                self.assertFalse(running(child))
                self.assertFalse(config_dir.exists())
            finally:
                if parent.poll() is None:parent.terminate();parent.wait(timeout=2)
                if guardian is not None and running(guardian):os.kill(guardian,15)

    @patch('virtual_devices.subprocess.Popen',side_effect=FileNotFoundError())
    @patch('virtual_devices.snapshot')
    def test_start_failure_releases_lock_and_logs(self, snapshot, popen):
        import tempfile, os
        snapshot.return_value={'outputs':[{'name':'hw','role':'hardware_output'}],'inputs':[]}
        with tempfile.TemporaryDirectory() as runtime, patch.dict(os.environ,{'XDG_RUNTIME_DIR':runtime}):
            devices=VirtualDevices()
            with self.assertRaises(AudioError): devices.start('hw')
            self.assertIsNone(devices.lock)
            self.assertEqual(devices.logs,[])
            self.assertEqual(devices.processes,[])

if __name__=='__main__': unittest.main()
