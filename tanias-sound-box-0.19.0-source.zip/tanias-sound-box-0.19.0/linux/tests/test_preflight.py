# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from preflight import runtime_errors, check_runtime
from audio_backend import AudioError
from virtual_devices import VirtualDevices

class RequirementsTests(unittest.TestCase):
    @patch('preflight.limiter_plugin', side_effect=AudioError('missing'))
    @patch('preflight.shutil.which', return_value=None)
    def test_errors_are_actionable(self, *mocks):
        with patch.dict(os.environ, {'XDG_RUNTIME_DIR': ''}):
            errors = runtime_errors()
            self.assertEqual(len(errors), 5)
            self.assertIn('pipewire-bin', errors[0])
            self.assertIn('desktop session', errors[1])
            with self.assertRaises(AudioError): check_runtime()
    @patch('preflight.limiter_plugin', return_value=Path('/plugin.so'))
    @patch('preflight.shutil.which', return_value='/usr/bin/tool')
    def test_ready_runtime(self, *mocks):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {'XDG_RUNTIME_DIR': directory}):
            self.assertEqual(runtime_errors(), [])
    @patch('virtual_devices.check_runtime', side_effect=AudioError('Missing pw-loopback'))
    @patch('virtual_devices.subprocess.Popen')
    def test_failure_precedes_any_spawn(self, spawn, runtime):
        devices = VirtualDevices()
        with self.assertRaisesRegex(AudioError, 'Missing pw-loopback'): devices.start('hw')
        spawn.assert_not_called()
        self.assertIsNone(devices.lock)

if __name__ == '__main__': unittest.main()
