# SPDX-License-Identifier: AGPL-3.0-or-later
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from audio_backend import AudioError, parse_snapshot, snapshot, route_status, MONITOR_NAME


def node(name, kind='Audio/Sink'):
    return {'type':'PipeWire:Interface:Node','info':{'state':'suspended',
            'props':{'media.class':kind,'node.name':name,'node.description':name}}}


class DiscoveryTests(unittest.TestCase):
    def test_route_health_detects_removed_links(self):
        nodes=[]
        for index,name in enumerate((MONITOR_NAME,'tanias_sound_box.hardware_capture',
                                     'tanias_sound_box.hardware_playback','hw')):
            obj=node(name);obj['id']=index
            if name=='tanias_sound_box.hardware_playback':
                obj['info']['props']['target.object']='hw'
            nodes.append(obj)
        links=[{'id':index+10,'type':'PipeWire:Interface:Link','info':{
            'output-node-id':output,'input-node-id':input,'state':'paused'}}
            for index,(output,input) in enumerate(((0,1),(0,1),(2,3),(2,3)))]
        self.assertTrue(route_status(nodes+links)['ready'])
        self.assertFalse(route_status(nodes+links[:2])['ready'])
        links[0]['info']['state']='error'
        self.assertFalse(route_status(nodes+links)['ready'])
    def test_stereo_requires_distinct_ports_and_mono_requires_one(self):
        nodes=[]
        for index,name in enumerate((MONITOR_NAME,'tanias_sound_box.hardware_capture',
                                     'tanias_sound_box.hardware_playback','hw')):
            obj=node(name);obj['id']=index
            if name=='tanias_sound_box.hardware_playback': obj['info']['props']['target.object']='hw'
            nodes.append(obj)
        links=[{'id':index+10,'type':'PipeWire:Interface:Link','info':{
            'output-node-id':output,'input-node-id':target,'input-port-id':port,'state':'active'}}
            for index,(output,target,port) in enumerate(((0,1,10),(0,1,11),(2,3,20),(2,3,20)))]
        self.assertFalse(route_status(nodes+links)['ready'])
        nodes[-1]['info']['props']['audio.channels']=1
        self.assertTrue(route_status(nodes+links)['ready'])
        links[1]['info']['state']='error'
        self.assertFalse(route_status(nodes+links)['ready'])

    def test_format_and_requested_latency_are_not_inferred_measurements(self):
        obj=node('hw');obj['info']['props'].update({'audio.rate':'48000','audio.channels':'2','node.latency':'256/48000'})
        obj['info']['params']={'Format':[{'rate':44100,'channels':1}]}
        fmt=parse_snapshot([obj])['outputs'][0]['format']
        self.assertEqual(fmt,{'sample_rate':44100,'channels':1,'requested_latency':'256/48000'})
        self.assertIsNone(parse_snapshot([node('other')])['outputs'][0]['format']['sample_rate'])

    def test_dump_updates_removals_and_id_reuse(self):
        from audio_backend import decode_dump
        initial=node('hw');initial['id']=4
        stream=json.dumps([initial])+"\n"+json.dumps([{'id':4,'info':{'state':'running'}}])
        objects=decode_dump(stream)
        self.assertEqual(objects[0]['info']['props']['node.name'],'hw')
        self.assertEqual(objects[0]['info']['state'],'running')
        self.assertEqual(decode_dump(stream+json.dumps([{'id':4}])),[])
        replacement=node('usb');replacement['id']=4
        self.assertEqual(decode_dump(stream+json.dumps([replacement]))[0]['info']['props']['node.name'],'usb')
        for bad in ('', '[] garbage', '{}', '[{'):
            with self.assertRaises(ValueError): decode_dump(bad)

    def test_default_metadata_and_inputs_filtered(self):
        for value in ({'name':'speakers'}, json.dumps({'name':'speakers'})):
            result=parse_snapshot([node('speakers'),node('mic','Audio/Source'),
                {'type':'PipeWire:Interface:Metadata','metadata':[
                    {'subject':0,'key':'default.audio.sink','value':value}]}])
            self.assertEqual(len(result['outputs']),1)
            self.assertTrue(result['outputs'][0]['default'])
            self.assertFalse(result['processing'])

    def test_removed_default_not_inferred(self):
        result=parse_snapshot([node('usb')])
        self.assertIsNone(result['default_output'])
        self.assertFalse(result['outputs'][0]['default'])
        self.assertEqual(parse_snapshot([])['outputs'],[])

    @patch('audio_backend.subprocess.run')
    def test_read_only_command_and_timeout(self, run):
        run.return_value=subprocess.CompletedProcess([],0,'[]','')
        self.assertEqual(snapshot()['outputs'],[])
        run.assert_called_once_with(['pw-dump','-N'],capture_output=True,text=True,timeout=4,check=False)
        for error in (FileNotFoundError(),subprocess.TimeoutExpired('pw-dump',4)):
            run.side_effect=error
            with self.assertRaises(AudioError): snapshot()

    @patch('audio_backend.subprocess.run')
    def test_bad_data_and_session_failure(self, run):
        for code, output in ((0,'bad json'),(0,'{}'),(1,'')):
            run.return_value=subprocess.CompletedProcess([],code,output,'unavailable')
            with self.assertRaises(AudioError): snapshot()


if __name__=='__main__':
    unittest.main()
