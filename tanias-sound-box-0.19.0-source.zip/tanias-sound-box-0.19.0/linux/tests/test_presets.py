import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from presets import Presets, decode

class PresetTests(unittest.TestCase):
    def test_roundtrip_and_portability(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            library = Presets(root / 'library.json')
            library.save('Recording', {'gain': -6, 'hardware_output': 'must-not-export'})
            library.export(root / 'export.json', 'Recording', library.all()['Recording'])
            other = Presets(root / 'other.json')
            self.assertEqual(other.import_file(root / 'export.json'), 'Recording')
            self.assertEqual(other.all()['Recording']['gain'], -6)
            self.assertNotIn('hardware_output', (root / 'export.json').read_text())
            self.assertIn('Flat', other.all())
    def test_factory_export_imports_as_custom_without_overwriting_factory(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);library=Presets(root/'library.json')
            library.export(root/'flat.json','Flat',{'gain':-6})
            self.assertEqual(library.import_file(root/'flat.json'),'Flat (custom)')
            self.assertEqual(library.all()['Flat']['gain'],0)
            self.assertEqual(library.all()['Flat (custom)']['gain'],-6)

    def test_invalid_controls_and_schema(self):
        for data in ({'schema': 9}, {'schema': 1, 'name': '../', 'controls': {'gain': float('nan')}},
                     {'schema': 1, 'name': 'bad\nname', 'controls': {}}):
            with self.assertRaises(ValueError): decode(data)
    def test_rejection_preserves_library(self):
        with tempfile.TemporaryDirectory() as directory:
            library = Presets(Path(directory) / 'library.json')
            library.save('Good', {})
            before = library.path.read_bytes()
            with self.assertRaises(ValueError): library.save('Bad', {'limiter': 'yes'})
            with self.assertRaises(ValueError): library.save('Flat', {})
            self.assertEqual(library.path.read_bytes(), before)

if __name__ == '__main__': unittest.main()
