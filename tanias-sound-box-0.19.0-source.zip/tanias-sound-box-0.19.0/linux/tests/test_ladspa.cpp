// SPDX-License-Identifier: AGPL-3.0-or-later
#include <ladspa.h>
#include <dlfcn.h>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
void check(bool value,const char* message) { if(!value) throw std::runtime_error(message); }
void verify(const char* path,const char* label,unsigned count,bool limiter) {
    void* library=dlopen(path,RTLD_NOW|RTLD_LOCAL);
    check(library!=nullptr,"native plugin cannot load");
    auto descriptorFunction=reinterpret_cast<LADSPA_Descriptor_Function>(dlsym(library,"ladspa_descriptor"));
    check(descriptorFunction!=nullptr,"descriptor export missing");
    const auto* descriptor=descriptorFunction(0);
    check(descriptor && std::string(descriptor->Label)==label,"wrong plugin label");
    check(descriptorFunction(1)==nullptr && descriptor->PortCount==count,"wrong descriptor/port count");
    check(std::string(descriptor->PortNames[4])=="Enabled","toggle port mismatch");
    auto handle=descriptor->instantiate(descriptor,48000);
    check(handle!=nullptr,"instantiate failed");
    std::vector<std::vector<float>> ports(count);
    for(unsigned index=0;index<count;++index) {
        ports[index].assign(index<4 ? 4800 : 1,0);
        descriptor->connect_port(handle,index,ports[index].data());
    }
    ports[0].assign(4800,.5f);ports[1].assign(4800,.25f);
    // Reconnect after vector mutation, as a host may replace its buffers.
    for(unsigned index=0;index<4;++index) descriptor->connect_port(handle,index,ports[index].data());
    ports[5][0]=limiter ? -12 : -20;ports[6][0]=limiter ? 100 : 4;
    if(!limiter) { ports[7][0]=1;ports[8][0]=100;ports[9][0]=0; }
    descriptor->activate(handle);descriptor->run(handle,4800);
    check(ports[2]==ports[0] && ports[3]==ports[1],"plugin bypass wiring changed audio");
    ports[4][0]=1;descriptor->run(handle,4800);
    const double expected=limiter ? std::pow(10.,-.6) : std::pow(10.,(-20+(20*std::log10(.5)+20)/4)/20);
    check(std::abs(ports[2].back()-expected)<.0001,"hosted dynamics curve wrong");
    check(std::abs(ports[3].back()*2-ports[2].back())<1e-6,"hosted stereo image wrong");
    descriptor->cleanup(handle);dlclose(library);
}
int main(int argc,char* argv[]) {
    try {
        check(argc==3,"pass limiter and compressor shared objects");
        verify(argv[1],"tania_stereo_limiter",9,true);
        verify(argv[2],"tania_stereo_compressor",10,false);
        std::cout<<"Native plugin load, ABI, ports, bypass and dynamics curves passed.\n";
    } catch(const std::exception& error) { std::cerr<<error.what()<<'\n';return 1; }
}
