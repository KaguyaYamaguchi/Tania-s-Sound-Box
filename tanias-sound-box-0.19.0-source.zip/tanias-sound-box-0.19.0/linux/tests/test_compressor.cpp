// SPDX-License-Identifier: AGPL-3.0-or-later
#include "StereoCompressor.h"
#include <vector>
#include <cmath>
#include <limits>
#include <iostream>
int main() {
    tania::StereoCompressor compressor(48000);
    std::vector<float> l(48000,.5f), r(48000,.25f), outL(48000), outR(48000);
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),l.size(),true,-20,4,1,100,0);
    const float expected=std::pow(10.f,(-20.f+(20.f*std::log10(.5f)+20.f)/4.f)/20.f);
    if(std::abs(outL.back()-expected)>.0001 || std::abs(outR.back()*2-outL.back())>.00001) return 1;
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),l.size(),false,-60,20,1,100,12);
    if(outL!=l || outR!=r) return 2;
    compressor.reset();
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),l.size(),true,-20,1,1,100,6);
    if(std::abs(outL.back()-.5f*std::pow(10.f,.3f))>.0001) return 3;
    l[0]=std::numeric_limits<float>::infinity();r[0]=std::numeric_limits<float>::quiet_NaN();
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),1,true,-20,4,1,100,0);
    if(outL[0]!=0 || outR[0]!=0) return 4;
    compressor.reset(); l.assign(48000,.5f);r.assign(48000,.25f);
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),1,true,-20,4,100,100,0);
    if(outL[0]<.49f) return 5; // attack deliberately allows the initial transient
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),48000,true,-20,4,1,100,0);
    l.assign(48000,.01f);r.assign(48000,.005f);
    compressor.process(l.data(),r.data(),outL.data(),outR.data(),48000,true,-20,4,1,100,0);
    if(outL.front()>=outL.back() || std::abs(outL.back()-.01f)>.00001) return 6;
    std::cout<<"Compression curve, linked channels, attack/release, unity ratio, makeup, bypass and nonfinite handling passed.\n";
}
