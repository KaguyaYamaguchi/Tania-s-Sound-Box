// SPDX-License-Identifier: AGPL-3.0-or-later
#include "StereoLimiter.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
void check(bool value,const char* message) { if(!value) throw std::runtime_error(message); }
int main() {
    try {
        tania::StereoLimiter limiter(48000);
        std::vector<float> l(4800,2),r(4800,-1),ol(4800),orr(4800);
        float peak,reduction;
        limiter.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),true,-1,100,peak,reduction);
        const float ceiling=static_cast<float>(std::pow(10.,-.05));
        for(std::size_t i=0;i<ol.size();++i) {
            check(std::abs(ol[i])<=ceiling+1e-7,"sample ceiling exceeded");
            check(std::abs(ol[i]+2*orr[i])<1e-7,"stereo image changed");
        }
        check(std::abs(peak+1)<1e-4 && reduction>6,"limiter meters");
        l.assign(4800,.1f);r.assign(4800,.1f);
        limiter.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),true,-1,100,peak,reduction);
        check(ol.back()>ol.front() && ol.back()<.1f,"release envelope");
        limiter.reset();
        limiter.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),true,-1,100,peak,reduction);
        check(ol==l && orr==r,"quiet signal changed");
        l[0]=2;r[0]=-1;
        limiter.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),false,-1,100,peak,reduction);
        check(ol==l && orr==r,"bypass changed signal");
        l[0]=std::numeric_limits<float>::quiet_NaN();r[0]=std::numeric_limits<float>::infinity();
        limiter.process(l.data(),r.data(),ol.data(),orr.data(),l.size(),true,-1,100,peak,reduction);
        check(std::isfinite(ol[0]) && std::isfinite(orr[0]),"nonfinite input escaped");
        std::cout<<"Stereo limiter checks passed\n";
    } catch(const std::exception& error) { std::cerr<<error.what()<<'\n';return 1; }
}
