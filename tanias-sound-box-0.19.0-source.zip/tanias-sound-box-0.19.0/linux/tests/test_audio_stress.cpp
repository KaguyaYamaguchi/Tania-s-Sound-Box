// SPDX-License-Identifier: AGPL-3.0-or-later
#include "StereoCompressor.h"
#include "StereoLimiter.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <vector>
void check(bool condition,const char* message) { if(!condition) throw std::runtime_error(message); }
int main() {
    try {
        const auto start=std::chrono::steady_clock::now();
        std::mt19937 random(49002);
        std::uniform_real_distribution<float> noise(-4,4);
        double audioSeconds=0;
        for(double rate : {8000.,44100.,48000.,96000.,192000.}) {
            tania::StereoCompressor compressor(rate), split(rate);
            tania::StereoLimiter limiter(rate), splitLimiter(rate);
            std::vector<float> left(4096),right(4096),outL(4096),outR(4096),partL(4096),partR(4096);
            for(std::size_t i=0;i<left.size();++i) { left[i]=noise(random);right[i]=left[i]*.25f; }
            compressor.process(left.data(),right.data(),outL.data(),outR.data(),left.size(),true,-18,4,10,150,6);
            std::size_t offset=0;
            for(std::size_t block : {1u,17u,128u,1024u,2926u}) {
                split.process(left.data()+offset,right.data()+offset,partL.data()+offset,partR.data()+offset,block,true,-18,4,10,150,6);
                offset+=block;
            }
            check(offset==left.size() && outL==partL && outR==partR,"compressor block discontinuity");
            float peak,reduction;
            limiter.process(outL.data(),outR.data(),outL.data(),outR.data(),left.size(),true,-6,100,peak,reduction);
            offset=0;
            for(std::size_t block : {1u,17u,128u,1024u,2926u}) {
                splitLimiter.process(partL.data()+offset,partR.data()+offset,partL.data()+offset,partR.data()+offset,block,true,-6,100,peak,reduction);
                offset+=block;
            }
            check(outL==partL && outR==partR,"limiter block discontinuity or in-place failure");
            for(unsigned block=0;block<2000;++block) {
                const auto frames=static_cast<std::size_t>(1+random()%4096);
                for(std::size_t i=0;i<frames;++i) { left[i]=noise(random);right[i]=left[i]*.25f; }
                if(block%31==0) { left[0]=std::numeric_limits<float>::quiet_NaN();right[0]=std::numeric_limits<float>::infinity(); }
                if(block%47==0) { left[0]=std::numeric_limits<float>::max();right[0]=left[0]*.25f; }
                compressor.process(left.data(),right.data(),outL.data(),outR.data(),frames,block%7!=0,
                                   -static_cast<float>(block%61),1+block%20,1+block%200,10+block%1991,block%13);
                limiter.process(outL.data(),outR.data(),outL.data(),outR.data(),frames,true,-6,10+block%991,peak,reduction);
                for(std::size_t i=0;i<frames;++i) {
                    check(std::isfinite(outL[i]) && std::isfinite(outR[i]),"nonfinite output");
                    check(std::abs(outL[i])<=std::pow(10.,-.3)+1e-6 && std::abs(outR[i])<=std::pow(10.,-.3)+1e-6,"stress ceiling exceeded");
                    // Saturation of an extreme float input can alter ratio, but
                    // normal PCM must retain the exact linked stereo image.
                    if(std::isfinite(left[i]) && std::abs(left[i])<10 && std::isfinite(right[i]))
                        check(std::abs(outL[i]*.25f-outR[i])<1e-6,"linked image lost");
                }
                audioSeconds+=frames/rate;
            }
        }
        // Unity-ratio makeup must still produce finite output for extreme input.
        tania::StereoCompressor compressor(48000);
        float l=std::numeric_limits<float>::max(),r=l,ol=0,orr=0;
        compressor.process(&l,&r,&ol,&orr,1,true,-18,1,10,150,12);
        check(std::isfinite(ol) && std::isfinite(orr),"makeup overflow");
        const auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        std::cout<<"Stress passed: "<<audioSeconds<<" seconds of native dynamics in "<<elapsed
                 <<" seconds wall time (includes generation/assertions; not full PipeWire CPU).\n";
    } catch(const std::exception& error) { std::cerr<<error.what()<<'\n';return 1; }
}
