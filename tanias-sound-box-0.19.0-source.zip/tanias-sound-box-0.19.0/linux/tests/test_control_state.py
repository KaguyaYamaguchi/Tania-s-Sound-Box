# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
from control_state import ControlState
from controls import validate
from settings_store import load, save

class StateTests(unittest.TestCase):
    def test_edit_while_apply_runs_stays_pending_after_old_confirmation(self):
        state = ControlState({})
        applied = validate({'gain': -6})
        state.stage(applied)
        state.stage({'gain': -12})
        state.observe({'enabled': True, 'desired_controls': applied, 'confirmed_controls': applied})
        self.assertTrue(state.unapplied)
        self.assertTrue(state.unsaved)
        self.assertIn('not applied', state.describe())
        state.mark_saved(state.editor)
        self.assertFalse(state.unsaved)
        self.assertTrue(state.unapplied)
        state.observe({'enabled': True, 'desired_controls': state.editor, 'confirmed_controls': None})
        self.assertIn('queued', state.describe())
        state.observe({'enabled': True, 'confirmed_controls': state.editor})
        self.assertFalse(state.unapplied)
    def test_fresh_or_unreadable_settings_are_never_reported_saved(self):
        state=ControlState({},persisted=False)
        self.assertTrue(state.unsaved)
        self.assertIn('not saved',state.describe())
        state.mark_saved(state.editor)
        self.assertFalse(state.unsaved)

    def test_disabling_does_not_discard_edits_or_imply_applied(self):
        state = ControlState({});state.stage({'compressor': True})
        state.observe({'enabled': False})
        self.assertTrue(state.unsaved)
        self.assertIn('disabled', state.describe())
    def test_legacy_upgrade_and_atomic_bundle(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ, {'XDG_CONFIG_HOME': directory}):
            path = Path(directory) / 'settings.json'
            path.write_text(json.dumps({'gain': -9}))
            values, output = load(path)
            self.assertEqual(values['gain'], -9)
            self.assertFalse(values['compressor'])
            save(values, 'selected-output', path)
            self.assertEqual(load(path), (values, 'selected-output'))
            before = path.read_bytes()
            with self.assertRaises(ValueError): save({'gain': float('nan')}, 'hw', path)
            self.assertEqual(path.read_bytes(), before)
            with patch('controls.os.replace', side_effect=OSError('disk failure')):
                with self.assertRaises(OSError): save({'gain': -3}, 'different', path)
            self.assertEqual(path.read_bytes(), before)
            self.assertEqual(list(Path(directory).iterdir()), [path])
    def test_corrupt_settings_recovery_preserves_exact_original(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            original = b'{broken settings'
            path.write_bytes(original)
            backup = save({'gain':-6}, 'hw', path)
            self.assertEqual(backup.read_bytes(), original)
            self.assertEqual(load(path)[0]['gain'], -6)
            path.write_text('{"schema": 99, "controls": {}}')
            before = path.read_bytes()
            with self.assertRaises(ValueError): save({}, 'hw', path)
            self.assertEqual(path.read_bytes(), before)

    def test_unknown_schema_is_not_silently_reset(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'settings.json'
            path.write_text('{"schema": true, "controls": {}}')
            with self.assertRaises(ValueError): load(path)

if __name__ == '__main__': unittest.main()
