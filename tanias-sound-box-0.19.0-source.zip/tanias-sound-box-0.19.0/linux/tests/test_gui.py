"""Hidden desktop smoke for all three tabs; no audio enable or recording."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import tkinter as tk
from unittest.mock import patch
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'build'))
from sound_box import SoundBox
from mic_controls import load

with tempfile.TemporaryDirectory() as config:
    os.environ['XDG_CONFIG_HOME']=config
    root=tk.Tk();root.withdraw();app=SoundBox(root)
    try:
        assert [app.notebook.tab(i,'text') for i in range(3)]==['Sound controls','Mic configurator','Capture Point']
        deadline=time.monotonic()+15
        while (app.audio_busy or app.mic_panel.busy or app.capture_panel.busy) and time.monotonic()<deadline:
            root.update();time.sleep(.02)
        assert not (app.audio_busy or app.mic_panel.busy or app.capture_panel.busy),'Queries did not finish'
        assert not app.session.enabled and not app.mic_panel.session.enabled
        assert app.navigation.get()==0
        assert len(app.effects_notebook.tabs())==2
        assert len(app.mic_panel.effects_notebook.tabs())==4
        assert len(app.capture_panel.sections.tabs())==4
        for index in range(3):
            app.notebook.select(index);root.update()
            assert app.navigation.get()==index
        app.notebook.select(0);root.update()
        assert app.mic_panel.meter.target is None and app.mic_panel.recording.process is None
        assert app.capture_panel.last_snapshot is not None,app.capture_panel.status.get()
        assert app.capture_panel.devices,'No connected devices listed'
        mic=app.mic_panel;mic.values['gain'].set(6);mic.flags['gate_enabled'].set(True)
        assert 'not saved' in mic.control_text.get()
        assert mic.save();stored,source=load();assert stored['gain']==6 and stored['gate_enabled']
        mic.preset_choice.set('Natural voice');mic.load_preset();assert mic.current()['gain']==0
        assert not mic.session.enabled and mic.meter.target is None
        app.notebook.select(2);app.capture_panel.tree.selection_set(app.capture_panel.tree.get_children()[0]);root.update()
        selected=app.capture_panel.device();assert selected['name'] in app.capture_panel.details.get()
        assert 'system' in app.capture_panel.tree['columns']
        assert app.capture_panel.points.get_children()
        point=app.capture_panel.points.get_children()[0]
        app.capture_panel.points.selection_set(point);app.capture_panel.select_point()
        assert app.capture_panel.device()['name']==app.capture_panel.device_rows[point]['name']
        capture=app.capture_panel
        snapshot=deepcopy(capture.last_snapshot)
        capture.alias.set('Unsaved device label')
        capture.points.item(point,open=False)
        with patch.object(capture.tree,'delete',wraps=capture.tree.delete) as delete, patch.object(capture.tree,'insert',wraps=capture.tree.insert) as insert, patch.object(capture.tree,'item',wraps=capture.tree.item) as item, patch.object(capture.tree,'move',wraps=capture.tree.move) as move:
            capture.render(snapshot)
            delete.assert_not_called();insert.assert_not_called();move.assert_not_called()
            assert not any(call.kwargs for call in item.call_args_list),'Unchanged rows must not be rewritten'
        assert capture.points.selection()==(point,)
        assert not capture.points.item(point,'open')
        assert capture.alias.get()=='Unsaved device label'
        chosen=capture.device()['name']
        snapshot['devices'].reverse();capture.render(snapshot)
        assert capture.device()['name']==chosen
        assert capture.alias.get()=='Unsaved device label'
        # A changed volume updates its row while retaining identity and selection.
        selected=capture.device_rows[point]
        changed=next(d for d in snapshot['devices'] if d['name']==selected['name'] and d['kind']==selected['kind'])
        changed['volume_percent']=42
        capture.render(snapshot)
        assert capture.tree.set(point,'volume')=='42.0%'
        assert capture.tree.selection()==(point,)
        if mic.inputs:
            mic.choice.current(0);mic.remember_source()
            assert mic.selected_source in mic.target_text.get()
        assert app.save()
        print('Three tabs, real device inventory, independent mic save/presets, staged state and no automatic capture passed.')
        Path('build/validation/gui-mic-result.txt').write_text('PASS: three tabs, inventory, mic save/presets, staging; no auto capture.\n')
    finally:
        app.closing=True;app.mic_panel.closing=True;app.capture_panel.closing=True
        while app.audio_busy or app.mic_panel.busy or app.capture_panel.busy:
            root.update();time.sleep(.02)
        app.mic_panel.close();app.capture_panel.close();app.session.disable();root.destroy()
