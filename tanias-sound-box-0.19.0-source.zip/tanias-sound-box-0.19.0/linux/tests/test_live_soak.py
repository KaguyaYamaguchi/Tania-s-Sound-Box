"""Continuous isolated monitor capture while controls change; no hardware route."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import argparse
from array import array
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import wave
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
import processing_graph as graph
from audio_backend import raw_snapshot
from virtual_devices import VirtualDevices


def run(seconds, updates):
    suffix = str(os.getpid())
    graph.PLAYBACK_NAME = 'tanias_sound_box.soak_playback.' + suffix
    graph.MONITOR_NAME = 'tanias_sound_box.soak_monitor.' + suffix
    rate = 48000
    with tempfile.TemporaryDirectory(prefix='tania-soak-') as directory, tempfile.TemporaryFile() as log:
        folder = Path(directory)
        config = folder / 'processing.conf'
        config.write_text(graph.graph_configuration({'ceiling': -6}))
        tone = array('h')
        for frame in range(rate):
            sample = round(.2 * 32767 * math.sin(2 * math.pi * 1000 * frame / rate))
            tone.extend((sample, sample))
        if sys.byteorder != 'little': tone.byteswap()
        source = folder / 'tone.wav'
        with wave.open(str(source), 'wb') as stream:
            stream.setnchannels(2);stream.setsampwidth(2);stream.setframerate(rate)
            for _ in range(seconds): stream.writeframes(tone.tobytes())
        client = subprocess.Popen(graph.graph_command(config), stdout=log, stderr=log)
        recorder = player = None
        try:
            deadline = time.monotonic() + 6
            while graph.processing_node(raw_snapshot()) is None:
                assert client.poll() is None, 'Processing client exited'
                assert time.monotonic() < deadline, 'Graph creation timed out'
                time.sleep(.05)
            node_id = graph.processing_node(raw_snapshot())['id']
            props = ('application.name = "Tania Soak '+suffix+'" media.role = "Soak'+suffix+
                     '" state.restore-props = false state.restore-target = false state.default-volume = 1.0')
            capture = folder / 'capture.wav'
            recorder = subprocess.Popen(['pw-record', '--target', graph.MONITOR_NAME, '--rate', str(rate),
                '--channels', '2', '--format', 's16', '--volume', '1', '-P', props, str(capture)], stdout=log, stderr=log)
            time.sleep(.2)
            player = subprocess.Popen(['pw-play', '--target', graph.PLAYBACK_NAME, '--volume', '1', '-P', props, str(source)], stdout=log, stderr=log)
            start = time.monotonic()
            for index in range(updates):
                due = start + index * seconds / updates
                remaining = due - time.monotonic()
                if remaining > 0: time.sleep(remaining)
                assert player.poll() is None and recorder.poll() is None and client.poll() is None, 'Stream exited early'
                values = {'gain': (-24, 0, 12)[index % 3], 'balance': (-100, -50, 0, 50, 100)[index % 5],
                          'eq_1000': (-12, 0, 12)[(index // 3) % 3], 'ceiling': -6,
                          'compressor': bool(index % 2), 'threshold': -12 - index % 30,
                          'ratio': 1 + index % 20, 'attack': 1 + index % 100,
                          'compressor_release': 10 + index % 500, 'makeup': index % 13}
                graph.apply_controls(values)
                assert graph.processing_node(raw_snapshot())['id'] == node_id, 'Apply recreated processing node'
            player.wait(timeout=seconds + 5)
            assert player.returncode == 0, 'Playback failed'
            time.sleep(.2)
            VirtualDevices.end_process(recorder)
            with wave.open(str(capture), 'rb') as stream:
                samples = array('h', stream.readframes(stream.getnframes()))
            if sys.byteorder != 'little': samples.byteswap()
            assert samples, 'Empty monitor capture'
            peak = max(abs(value) for value in samples) / 32767
            assert peak <= 10**(-6/20) + .001, ('Ceiling exceeded during control changes', peak)
            # Inspect 50 ms windows between first and last signal, allowing one
            # zero window for stream scheduling; startup/tail silence excluded.
            block = rate // 20 * 2
            peaks = [max(abs(value) for value in samples[i:i+block]) for i in range(0, len(samples)-block, block)]
            active = [i for i, value in enumerate(peaks) if value > 2]
            assert active, 'No generated signal captured'
            longest = consecutive = 0
            for value in peaks[active[0]:active[-1]+1]:
                consecutive = consecutive + 1 if value <= 2 else 0
                longest = max(longest, consecutive)
            assert longest <= 1, ('Capture gap', longest * .05)
            return {'seconds': seconds, 'updates': updates, 'sample_rate': rate,
                    'captured_seconds': len(samples) / (rate * 2), 'sample_peak': peak,
                    'longest_silent_window_seconds': longest * .05,
                    'processing_node_preserved': True, 'hardware_playback': False}
        finally:
            for process in (player, recorder, client):
                if process is not None: VirtualDevices.end_process(process)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds', type=int, default=60)
    parser.add_argument('--updates', type=int, default=30)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if not 10 <= args.seconds <= 3600 or not 1 <= args.updates <= args.seconds:
        parser.error('Use 10–3600 seconds and 1–seconds updates.')
    result = run(args.seconds, args.updates)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
