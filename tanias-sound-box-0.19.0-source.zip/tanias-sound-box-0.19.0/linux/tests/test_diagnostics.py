import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'ui'))
import diagnostics
from audio_backend import AudioError

class DiagnosticsTests(unittest.TestCase):
    @patch('diagnostics.snapshot', side_effect=AudioError('Server unavailable'))
    @patch('diagnostics.subprocess.run', side_effect=FileNotFoundError())
    @patch('diagnostics.shutil.which', return_value=None)
    @patch('diagnostics.limiter_plugin', side_effect=AudioError('Missing'))
    def test_missing_runtime_report(self, *mocks):
        data = diagnostics.report()
        self.assertFalse(data['audio']['connected'])
        self.assertFalse(any(data['runtime']['tools'].values()))
        self.assertFalse(any(data['runtime']['plugins'].values()))
        self.assertEqual(data['schema'], 1)
    def test_summary_excludes_raw_metadata(self):
        data = diagnostics.report({'connected': True, 'raw_metadata': 'secret', 'session': {'state': 'live'}})
        self.assertNotIn('raw_metadata', data['audio'])
        self.assertEqual(data['audio']['session']['state'], 'live')

if __name__ == '__main__': unittest.main()
