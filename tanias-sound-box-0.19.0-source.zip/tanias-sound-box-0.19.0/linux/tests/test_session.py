# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import sys, unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
from session import AudioSession
from audio_backend import AudioError,PLAYBACK_NAME,MONITOR_NAME


def current(hardware=True,graph=True,ready=True):
    return {'connected':True,'outputs':([{'name':'hw','role':'hardware_output'}] if hardware else [])+
            ([{'name':PLAYBACK_NAME,'role':'sound_box_playback'}] if graph else []),
            'inputs':[{'name':MONITOR_NAME}] if graph else [],'routing':{'ready':ready,'hardware_output':'hw'}}

class Devices:
    def __init__(self):
        self.active=False;self.graph_active=False;self.starts=0;self.attaches=0;self.applied=[]
    def start(self,*args):self.active=self.graph_active=True;self.starts+=1;return current()
    def stop(self):self.active=self.graph_active=False
    def detach_hardware(self):self.active=False
    def attach_hardware(self,target):self.active=True;self.attaches+=1
    def apply(self,*args):self.applied.append(args);return current()

class SessionTests(unittest.TestCase):
    @patch('session.snapshot')
    def test_device_return_preserves_graph(self,snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{'gain':-6})
        snapshot.return_value=current(hardware=False,ready=False)
        self.assertEqual(session.poll()['session']['state'],'waiting_device')
        self.assertTrue(devices.graph_active);self.assertFalse(devices.active)
        snapshot.return_value=current(ready=False)
        self.assertEqual(session.poll()['session']['state'],'live')
        self.assertEqual(devices.starts,1);self.assertEqual(devices.attaches,1)

    @patch('session.snapshot')
    def test_server_loss_and_queued_controls(self,snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        snapshot.side_effect=AudioError('server unavailable')
        self.assertEqual(session.poll()['session']['state'],'waiting_server')
        self.assertTrue(session.enabled);self.assertFalse(devices.graph_active)
        session.apply({'gain':-12})
        snapshot.side_effect=None;snapshot.return_value=current(graph=False,ready=False)
        self.assertEqual(session.poll()['session']['state'],'live')
        self.assertEqual(session.controls['gain'],-12);self.assertEqual(devices.starts,2)

    @patch('session.snapshot')
    def test_disable_cancels_recovery_and_no_fallback(self,snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        snapshot.return_value=current(hardware=False,ready=False)
        session.poll();session.disable();session.poll()
        self.assertFalse(session.enabled);self.assertEqual(devices.starts,1)
        with self.assertRaises(AudioError):session.apply({})

    @patch('session.snapshot')
    def test_apply_race_retains_intent_and_complete_controls(self, snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        snapshot.return_value=current()
        with patch.object(devices,'apply',side_effect=AudioError('client lost')):
            result=session.apply({'gain':-9,'compressor':True})
        self.assertTrue(session.enabled)
        self.assertEqual(result['session']['state'],'recovering')
        self.assertFalse(devices.graph_active)
        self.assertEqual(session.controls['gain'],-9)
        self.assertTrue(session.controls['compressor'])
        snapshot.return_value=current(graph=False,ready=False)
        session.poll()
        self.assertEqual(devices.starts,2)

    @patch('session.snapshot')
    def test_wrong_destination_is_repaired_and_generation_reported(self, snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        wrong=current();wrong['routing']['hardware_output']='other-speakers'
        snapshot.side_effect=[wrong,current()]
        result=session.poll()
        self.assertEqual(devices.attaches,1)
        self.assertEqual(result['session']['route_repairs'],1)
        self.assertEqual(result['session']['graph_generation'],1)
        self.assertEqual(result['routing']['hardware_output'],'hw')

    @patch('session.snapshot')
    def test_repeated_hotplug_and_suspend_cycles(self, snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        for _ in range(12):
            snapshot.return_value=current(hardware=False,ready=False)
            self.assertEqual(session.poll()['session']['state'],'waiting_device')
            self.assertTrue(devices.graph_active)
            snapshot.return_value=current(ready=False)
            self.assertEqual(session.poll()['session']['state'],'live')
        self.assertEqual(devices.starts,1)
        self.assertEqual(devices.attaches,12)
        devices.stop();snapshot.return_value=current(graph=False,ready=False)
        self.assertEqual(session.poll()['session']['graph_generation'],2)
        session.disable();session.poll()
        self.assertFalse(session.enabled)

    @patch('session.snapshot')
    def test_client_lost_before_apply_never_claims_confirmation(self, snapshot):
        devices=Devices();session=AudioSession(devices);session.enable('hw',{})
        devices.stop();snapshot.return_value=current(graph=False,ready=False)
        result=session.apply({'gain':-15})
        self.assertEqual(result['session']['state'],'recovering')
        self.assertIsNone(result['session']['confirmed_controls'])
        self.assertEqual(result['session']['desired_controls']['gain'],-15)
        self.assertIn('queued',result['session']['message'])

    @patch('session.snapshot')
    def test_retry_backoff(self,snapshot):
        devices=Devices();now=[0];session=AudioSession(devices,lambda:now[0]);session.enable('hw',{})
        devices.stop();snapshot.return_value=current(graph=False,ready=False)
        with patch.object(devices,'start',side_effect=AudioError('busy')) as start:
            session.poll();session.poll();self.assertEqual(start.call_count,1)
            now[0]=1;session.poll();self.assertEqual(start.call_count,2)
            self.assertEqual(session.next_retry,3)

if __name__=='__main__':unittest.main()
