# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'ui'))
import capture_backend as capture
from audio_backend import AudioError


def device(name='mic',index=1,mute=False,value=65536):
    return {'name':name,'index':index,'mute':mute,'volume':{'left':{'value':value},'right':{'value':value}}}

class CaptureTests(unittest.TestCase):
    def test_local_alias_role_storage_is_not_a_system_command(self):
        with tempfile.TemporaryDirectory() as d,patch('capture_backend.call') as call:
            profiles=capture.DeviceProfiles(Path(d)/'profiles.json')
            profiles.save('input','usb mic','Recording mic','Microphone')
            self.assertEqual(profiles.all()['input:usb mic']['alias'],'Recording mic')
            profiles.save('input','usb mic','Recording mic','Hidden from choosers')
            self.assertFalse(profiles.visible('input','usb mic'))
            with self.assertRaises(ValueError):profiles.save('output','speakers','bad\nlabel','Playback output')
            call.assert_not_called()
    def test_point_names_and_mic_delegation(self):
        d={'kind':'input','name':'alsa.source','description':'Built-in Audio Analog Stereo',
           'active_port':'headset','ports':[{'name':'headset','description':'Headset microphone'}]}
        self.assertEqual(capture.sound_box_name(d,{}),'Headset microphone')
        self.assertEqual(capture.sound_box_name({**d,'active_port':None},{}),'Laptop microphone')
        with tempfile.TemporaryDirectory() as directory:
            profiles=capture.DeviceProfiles(Path(directory)/'profiles.json')
            profiles.save('input',d['name'],'Headset voice','Auxiliary input')
            self.assertFalse(capture.microphone_allowed(d,profiles.all()))
            profiles.save('input',d['name'],'Headset voice','Microphone')
            self.assertTrue(capture.microphone_allowed(d,profiles.all()))
            self.assertEqual(capture.sound_box_name(d,profiles.all()),'Headset voice')
            profiles.save('input',d['name'],'','Unassigned')
            self.assertTrue(capture.microphone_allowed(d,profiles.all()))

    @patch('capture_backend.call')
    def test_volume_mute_are_confirmed(self,call):
        call.side_effect=[[device()], '', '', [device(mute=True,value=32768)]]
        capture.set_device('input','mic',50,True)
        self.assertEqual(call.call_args_list[1].args[0],['set-source-volume','mic','50.00%'])
        self.assertEqual(call.call_args_list[2].args[0],['set-source-mute','mic','1'])
    @patch('capture_backend.call')
    def test_partial_mutation_rolls_back_previous_state(self,call):
        call.side_effect=[[device(value=32768)],'',AudioError('disconnected'),'','']
        with self.assertRaises(AudioError):capture.set_device('input','mic',100,True)
        self.assertEqual(call.call_args_list[3].args[0],['set-source-volume','mic','32768','32768'])
        self.assertEqual(call.call_args_list[4].args[0],['set-source-mute','mic','0'])
    @patch('capture_backend.call')
    def test_defaults_are_explicit_and_confirmed(self,call):
        call.side_effect=[[device()],'','mic'];capture.make_default('input','mic')
        self.assertEqual(call.call_args_list[1].args[0],['set-default-source','mic'])
    @patch('capture_backend.call')
    def test_moves_only_correct_direction_and_rejects_owned_streams(self,call):
        with self.assertRaises(ValueError):capture.move_stream('capture',7,'output','speakers')
        call.assert_not_called()
        call.side_effect=[[device()], [{'index':7,'properties':{'node.name':'tanias_sound_box.microphone_capture'}}]]
        with self.assertRaises(AudioError):capture.move_stream('capture',7,'input','mic')
        self.assertEqual(call.call_count,2)
    @patch('capture_backend.call')
    def test_disconnected_device_is_not_silently_replaced(self,call):
        call.return_value=[device('other mic')]
        with self.assertRaises(AudioError):capture.set_device('input','missing',100,False)
        self.assertEqual(call.call_count,1)
    def test_invalid_volume_never_reaches_system(self):
        with patch('capture_backend.call') as call:
            for value in (-1,151,float('nan'),True):
                with self.assertRaises(ValueError):capture.set_device('input','mic',value,False)
            call.assert_not_called()

if __name__=='__main__':unittest.main()
