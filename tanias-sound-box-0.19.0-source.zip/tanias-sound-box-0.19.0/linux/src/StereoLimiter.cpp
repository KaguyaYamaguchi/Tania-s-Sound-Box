// SPDX-License-Identifier: AGPL-3.0-or-later
#include "StereoLimiter.h"
#include <algorithm>
#include <cmath>
namespace tania {
namespace {
double bounded(float value, double fallback, double low, double high) noexcept {
    return std::isfinite(value) ? std::clamp(static_cast<double>(value),low,high) : fallback;
}
}
StereoLimiter::StereoLimiter(double sampleRate) noexcept
    : sampleRate_(std::isfinite(sampleRate) && sampleRate>=8000 ? sampleRate : 48000) {}
void StereoLimiter::process(const float* left,const float* right,float* outLeft,
                           float* outRight,std::size_t frames,bool enabled,
                           float ceilingDb,float releaseMs,float& peakDb,
                           float& reductionDb) noexcept {
    const double ceiling=std::pow(10.,bounded(ceilingDb,-1,-12,0)/20);
    const double release=std::exp(-1./(sampleRate_*bounded(releaseMs,100,10,1000)/1000));
    double peak=0, minimumGain=1;
    if (!enabled) gain_=1;
    for (std::size_t frame=0;frame<frames;++frame) {
        const double l=std::isfinite(left[frame]) ? left[frame] : 0;
        const double r=std::isfinite(right[frame]) ? right[frame] : 0;
        const double inputPeak=std::max(std::abs(l),std::abs(r));
        if (enabled) {
            const double target=inputPeak>ceiling ? ceiling/inputPeak : 1;
            gain_=target<gain_ ? target : std::min(target,1-(1-gain_)*release);
        }
        const double ol=l*gain_,orr=r*gain_;
        outLeft[frame]=static_cast<float>(ol);outRight[frame]=static_cast<float>(orr);
        peak=std::max(peak,std::max(std::abs(ol),std::abs(orr)));
        minimumGain=std::min(minimumGain,gain_);
    }
    peakDb=static_cast<float>(20*std::log10(std::max(peak,1e-6)));
    reductionDb=static_cast<float>(-20*std::log10(std::max(minimumGain,1e-12)));
}
}
