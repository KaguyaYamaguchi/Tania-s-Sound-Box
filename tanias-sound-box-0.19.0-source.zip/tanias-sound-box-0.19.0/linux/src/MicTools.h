// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <cstddef>
namespace tania {
struct MicControls {
    int mode=0;
    bool highpass=true,gate=false,deess=false;
    float highpassHz=80,thresholdDb=-45,attackMs=5,holdMs=150,releaseMs=150,rangeDb=-60;
    float deessThresholdDb=-24,deessRatio=4,deessHz=6000;
};
class MicTools {
public:
    explicit MicTools(double sampleRate) noexcept;
    void reset() noexcept;
    void process(const float* left,const float* right,float* outLeft,float* outRight,
                 std::size_t frames,const MicControls& controls) noexcept;
private:
    double rate_,hpInput_[2]{},hpOutput_[2]{},deessInput_[2]{},deessOutput_[2]{};
    double gateGain_=1,deessReduction_=0;
    std::size_t hold_=0;
};
}
