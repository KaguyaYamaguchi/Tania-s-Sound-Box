// SPDX-License-Identifier: AGPL-3.0-or-later
#include "AudioProcessor.h"
#include <cmath>
#include <stdexcept>

namespace tania {
namespace {
void requireRange(double value, double low, double high) {
    if (!std::isfinite(value) || value < low || value > high)
        throw std::invalid_argument("Unsupported audio control or sample rate");
}
}
void AudioProcessor::configure(double sampleRate, const Controls& controls) {
    requireRange(sampleRate, 8000, 192000);
    requireRange(controls.gainDb, -24, 12);
    requireRange(controls.balance, -100, 100);
    for (double value : controls.eqDb) requireRange(value, -12, 12);
    std::array<Filter, 9> filters{};
    for (std::size_t index=0; index<bands.size(); ++index) {
        if (bands[index] >= sampleRate/2 || controls.eqDb[index] == 0) continue;
        // Peaking EQ, Q=1: https://www.w3.org/TR/audio-eq-cookbook/
        const double amplitude=std::pow(10.0, controls.eqDb[index]/40.0);
        const double omega=2*std::acos(-1.0)*bands[index]/sampleRate;
        const double alpha=std::sin(omega)/2;
        const double cosine=std::cos(omega);
        const double a0=1+alpha/amplitude;
        auto& filter=filters[index];
        filter.b0=(1+alpha*amplitude)/a0;
        filter.b1=-2*cosine/a0;
        filter.b2=(1-alpha*amplitude)/a0;
        filter.a1=-2*cosine/a0;
        filter.a2=(1-alpha/amplitude)/a0;
    }
    const double gain=std::pow(10.0, controls.gainDb/20.0);
    gains_={gain*(controls.balance>0 ? 1-controls.balance/100 : 1),
            gain*(controls.balance<0 ? 1+controls.balance/100 : 1)};
    filters_=filters;
    bypass_=controls.bypass;
}
void AudioProcessor::reset() noexcept {
    for (auto& filter : filters_) { filter.z1={}; filter.z2={}; }
}
double AudioProcessor::Filter::tick(double sample, std::size_t channel) noexcept {
    const double output=b0*sample+z1[channel];
    z1[channel]=b1*sample-a1*output+z2[channel];
    z2[channel]=b2*sample-a2*output;
    if (std::abs(z1[channel])<1e-30) z1[channel]=0;
    if (std::abs(z2[channel])<1e-30) z2[channel]=0;
    return output;
}
void AudioProcessor::process(float* samples, std::size_t frames) noexcept {
    if (!samples || bypass_) return;
    for (std::size_t frame=0; frame<frames; ++frame) {
        for (std::size_t channel=0; channel<2; ++channel) {
            const auto offset=frame*2+channel;
            double sample=std::isfinite(samples[offset]) ? samples[offset] : 0;
            for (auto& filter : filters_) sample=filter.tick(sample, channel);
            samples[offset]=static_cast<float>(sample*gains_[channel]);
        }
    }
}
}
