// SPDX-License-Identifier: AGPL-3.0-or-later
#include "MicTools.h"
#include <algorithm>
#include <cmath>
#include <limits>
namespace tania {
namespace {
double bounded(float value,double fallback,double low,double high) { return std::isfinite(value) ? std::clamp(static_cast<double>(value),low,high) : fallback; }
double clean(double value) { return std::abs(value)<1.e-20 ? 0 : value; }
}
MicTools::MicTools(double rate) noexcept : rate_(std::isfinite(rate) && rate>=8000 ? rate : 48000) {}
void MicTools::reset() noexcept {
    for(int c=0;c<2;++c) hpInput_[c]=hpOutput_[c]=deessInput_[c]=deessOutput_[c]=0;
    gateGain_=1;deessReduction_=0;hold_=0;
}
void MicTools::process(const float* left,const float* right,float* outLeft,float* outRight,std::size_t frames,const MicControls& c) noexcept {
    const double pi=std::acos(-1.);
    const double hp=std::exp(-2*pi*bounded(c.highpassHz,80,20,300)/rate_);
    const double ds=std::exp(-2*pi*std::min(bounded(c.deessHz,6000,3000,10000),rate_*.45)/rate_);
    const double threshold=std::pow(10.,bounded(c.thresholdDb,-45,-80,0)/20);
    const double floor=std::pow(10.,bounded(c.rangeDb,-60,-80,0)/20);
    const double attack=std::exp(-1/(rate_*bounded(c.attackMs,5,1,100)*.001));
    const double release=std::exp(-1/(rate_*bounded(c.releaseMs,150,10,2000)*.001));
    const auto holdFrames=static_cast<std::size_t>(rate_*bounded(c.holdMs,150,0,1000)*.001);
    const double dsThreshold=std::pow(10.,bounded(c.deessThresholdDb,-24,-60,0)/20);
    const double slope=1-1/bounded(c.deessRatio,4,1,20);
    const double dsAttack=std::exp(-1/(rate_*.002)),dsRelease=std::exp(-1/(rate_*.06));
    for(std::size_t frame=0;frame<frames;++frame) {
        double signal[2]={std::isfinite(left[frame]) ? left[frame] : 0,std::isfinite(right[frame]) ? right[frame] : 0};
        if(c.mode==0) signal[0]=signal[1]=(signal[0]+signal[1])*.5;
        else if(c.mode==1) signal[1]=signal[0];
        else if(c.mode==2) signal[0]=signal[1];
        for(int channel=0;channel<2;++channel) {
            const double high=clean(hp*(hpOutput_[channel]+signal[channel]-hpInput_[channel]));
            hpInput_[channel]=signal[channel];hpOutput_[channel]=high;
            if(c.highpass) signal[channel]=high;
        }
        const double peak=std::max(std::abs(signal[0]),std::abs(signal[1]));
        if(!c.gate) { gateGain_=1;hold_=0; }
        else {
            if(peak>=threshold) hold_=holdFrames;
            const bool opened=peak>=threshold || hold_>0;
            if(peak<threshold && hold_>0) --hold_;
            const double target=opened ? 1 : floor;
            const double coefficient=target>gateGain_ ? attack : release;
            gateGain_=clean(coefficient*gateGain_+(1-coefficient)*target);
        }
        double high[2];
        for(int channel=0;channel<2;++channel) {
            high[channel]=clean(ds*(deessOutput_[channel]+signal[channel]-deessInput_[channel]));
            deessInput_[channel]=signal[channel];deessOutput_[channel]=high[channel];
        }
        const double highPeak=std::max(std::abs(high[0]),std::abs(high[1]));
        const double reduction=c.deess && highPeak>dsThreshold ? 20*std::log10(highPeak/dsThreshold)*slope : 0;
        const double coefficient=reduction>deessReduction_ ? dsAttack : dsRelease;
        deessReduction_=coefficient*deessReduction_+(1-coefficient)*reduction;
        if(!c.deess || deessReduction_<1.e-12) deessReduction_=0;
        const double gain=std::pow(10.,-deessReduction_/20);
        const double maximum=std::numeric_limits<float>::max();
        outLeft[frame]=static_cast<float>(std::clamp((signal[0]+high[0]*(gain-1))*gateGain_,-maximum,maximum));
        outRight[frame]=static_cast<float>(std::clamp((signal[1]+high[1]*(gain-1))*gateGain_,-maximum,maximum));
    }
}
}
