// SPDX-License-Identifier: AGPL-3.0-or-later
#include <ladspa.h>
#include "StereoLimiter.h"
#include <array>
#include <new>
namespace {
struct Instance {
    explicit Instance(unsigned long rate) : limiter(static_cast<double>(rate)) {}
    tania::StereoLimiter limiter;
    std::array<LADSPA_Data*,9> ports{};
};
LADSPA_Handle instantiate(const LADSPA_Descriptor*,unsigned long rate) {
    return new(std::nothrow) Instance(rate);
}
void connect(LADSPA_Handle handle,unsigned long port,LADSPA_Data* data) {
    if(port<9) static_cast<Instance*>(handle)->ports[port]=data;
}
void activate(LADSPA_Handle handle) { static_cast<Instance*>(handle)->limiter.reset(); }
void run(LADSPA_Handle handle,unsigned long frames) {
    auto& instance=*static_cast<Instance*>(handle);
    auto& p=instance.ports;
    for(std::size_t index=0;index<7;++index) if(!p[index]) return;
    float peak=-120,reduction=0;
    instance.limiter.process(p[0],p[1],p[2],p[3],frames,*p[4]>=.5f,*p[5],*p[6],peak,reduction);
    if(p[7]) *p[7]=peak;
    if(p[8]) *p[8]=reduction;
}
void cleanup(LADSPA_Handle handle) { delete static_cast<Instance*>(handle); }
const LADSPA_PortDescriptor ports[]={
    LADSPA_PORT_INPUT|LADSPA_PORT_AUDIO,LADSPA_PORT_INPUT|LADSPA_PORT_AUDIO,
    LADSPA_PORT_OUTPUT|LADSPA_PORT_AUDIO,LADSPA_PORT_OUTPUT|LADSPA_PORT_AUDIO,
    LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,
    LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,LADSPA_PORT_OUTPUT|LADSPA_PORT_CONTROL,
    LADSPA_PORT_OUTPUT|LADSPA_PORT_CONTROL};
const char* const names[]={"Left In","Right In","Left Out","Right Out","Enabled",
                           "Ceiling dB","Release ms","Peak dB","Reduction dB"};
const LADSPA_PortRangeHint hints[]={
    {0,0,0},{0,0,0},{0,0,0},{0,0,0},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE|LADSPA_HINT_TOGGLED|LADSPA_HINT_DEFAULT_1,0,1},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE,-12,0},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE|LADSPA_HINT_DEFAULT_100,10,1000},
    {0,0,0},{0,0,0}};
const LADSPA_Descriptor descriptor={
    49001,"tania_stereo_limiter",LADSPA_PROPERTY_HARD_RT_CAPABLE,
    "Tania Stereo Limiter","Tania's Sound Box contributors","GNU AGPL v3 or later",
    9,ports,names,hints,nullptr,instantiate,connect,activate,run,nullptr,nullptr,nullptr,cleanup};
}
extern "C" const LADSPA_Descriptor* ladspa_descriptor(unsigned long index) {
    return index==0 ? &descriptor : nullptr;
}
