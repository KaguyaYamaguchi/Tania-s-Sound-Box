// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <array>
#include <cstddef>

namespace tania {
inline constexpr std::array<double, 9> bands{60,170,310,600,1000,3000,6000,12000,16000};
struct Controls {
    double gainDb = 0;
    double balance = 0; // -100 left to +100 right; attenuates opposite channel.
    std::array<double, 9> eqDb{};
    bool bypass = false;
};
// Single-owner processor. Configure only while processing is stopped.
// Real-time control handoff and smoothing are pending live integration.
class AudioProcessor {
public:
    void configure(double sampleRate, const Controls& controls);
    void reset() noexcept;
    void process(float* interleavedStereo, std::size_t frames) noexcept;
private:
    struct Filter {
        double b0=1,b1=0,b2=0,a1=0,a2=0;
        std::array<double, 2> z1{},z2{};
        double tick(double sample, std::size_t channel) noexcept;
    };
    std::array<Filter, 9> filters_{};
    std::array<double, 2> gains_{1,1};
    bool bypass_=false;
};
}
