// SPDX-License-Identifier: AGPL-3.0-or-later
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unistd.h>

#ifndef TANIA_VERSION
#define TANIA_VERSION "0.19.0"
#endif

namespace {
std::filesystem::path userPath(const char* variable, const char* fallback)
{
    const char* value = std::getenv(variable);
    if (value && std::filesystem::path(value).is_absolute())
        return std::filesystem::path(value) / "tanias-sound-box";
    const char* home = std::getenv("HOME");
    if (!home || !std::filesystem::path(home).is_absolute())
        throw std::runtime_error(std::string("Set ") + variable +
                                 " or HOME to an absolute path.");
    return std::filesystem::path(home) / fallback / "tanias-sound-box";
}
}

int main(int argc, char* argv[])
{
    const std::string option = argc > 1 ? argv[1] : "--gui";
    if (argc > 2) {
        std::cerr << "Expected one option. Use --help.\n";
        return 2;
    }
    if (option == "--gui" || option == "--audio-status" || option == "--diagnostics" || option == "--check") {
        try {
            const auto directory = std::filesystem::canonical("/proc/self/exe").parent_path();
            const auto filename = option == "--gui" ? "sound_box.py" : (option == "--audio-status" ? "audio_backend.py" : "diagnostics.py");
            auto script = directory / filename;
            if (!std::filesystem::exists(script))
                script = directory.parent_path() / "share/tanias-sound-box" / filename;
            if (!std::filesystem::exists(script))
                throw std::runtime_error("Graphical interface file is missing. Rebuild or reinstall the app.");
            if (option == "--check")
                execlp("python3", "python3", script.c_str(), "--check", static_cast<char*>(nullptr));
            else
                execlp("python3", "python3", script.c_str(), static_cast<char*>(nullptr));
            throw std::runtime_error("Cannot launch Python 3. Install python3 and python3-tk.");
        } catch (const std::exception& error) {
            std::cerr << error.what() << '\n';
            return 1;
        }
    } else if (option == "--version") {
        std::cout << "Tania's Sound Box " << TANIA_VERSION << '\n';
    } else if (option == "--paths") {
        try {
            const auto config = userPath("XDG_CONFIG_HOME", ".config");
            const auto data = userPath("XDG_DATA_HOME", ".local/share");
            const auto state = userPath("XDG_STATE_HOME", ".local/state");
            std::cout << "Configuration: " << config.string() << '\n'
                      << "Data: " << data.string() << '\n'
                      << "Logs/state: " << state.string() << '\n';
        } catch (const std::exception& error) {
            std::cerr << error.what() << '\n';
            return 1;
        }
    } else if (option == "--help") {
        std::cout << "Tania's Sound Box — Linux control panel\n"
                     "Usage: tanias-sound-box [--gui | --audio-status | --diagnostics | --check | --help | --version | --paths]\n"
                     "Target: Linux Mint 22.3 Zena (Xfce), x86_64\n"
                     "Launch without arguments to open controls; explicitly enable processing in the panel.\n";
    } else {
        std::cerr << "Unknown option: " << option << ". Use --help.\n";
        return 2;
    }
    return 0;
}
