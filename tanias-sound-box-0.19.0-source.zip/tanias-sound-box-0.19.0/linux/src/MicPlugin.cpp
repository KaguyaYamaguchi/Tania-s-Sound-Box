// SPDX-License-Identifier: AGPL-3.0-or-later
#include <ladspa.h>
#include "MicTools.h"
#include <array>
#include <new>
#include <cmath>
namespace {
struct Instance { explicit Instance(unsigned long rate):tools(rate) {} tania::MicTools tools;std::array<LADSPA_Data*,17> ports{}; };
LADSPA_Handle instantiate(const LADSPA_Descriptor*,unsigned long rate) { return new(std::nothrow) Instance(rate); }
void connect(LADSPA_Handle h,unsigned long p,LADSPA_Data* value) { if(p<17) static_cast<Instance*>(h)->ports[p]=value; }
void activate(LADSPA_Handle h) { static_cast<Instance*>(h)->tools.reset(); }
void run(LADSPA_Handle h,unsigned long frames) {
    auto& i=*static_cast<Instance*>(h);auto& p=i.ports;for(auto value:p) if(!value) return;
    tania::MicControls c;
    c.mode=std::isfinite(*p[4]) && *p[4]>=0 && *p[4]<=3 ? static_cast<int>(std::round(*p[4])) : 0;
    c.highpass=*p[5]>=.5f;c.highpassHz=*p[6];c.gate=*p[7]>=.5f;c.thresholdDb=*p[8];
    c.attackMs=*p[9];c.holdMs=*p[10];c.releaseMs=*p[11];c.rangeDb=*p[12];
    c.deess=*p[13]>=.5f;c.deessThresholdDb=*p[14];c.deessRatio=*p[15];c.deessHz=*p[16];
    i.tools.process(p[0],p[1],p[2],p[3],frames,c);
}
void cleanup(LADSPA_Handle h) { delete static_cast<Instance*>(h); }
#define AUDIO_IN (LADSPA_PORT_INPUT|LADSPA_PORT_AUDIO)
#define AUDIO_OUT (LADSPA_PORT_OUTPUT|LADSPA_PORT_AUDIO)
#define CONTROL (LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL)
#define RANGE (LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE)
const LADSPA_PortDescriptor ports[]={AUDIO_IN,AUDIO_IN,AUDIO_OUT,AUDIO_OUT,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL,CONTROL};
const char* const names[]={"Left In","Right In","Left Out","Right Out","Mode","HP Enabled","HP Hz","Gate Enabled","Gate Threshold dB","Gate Attack ms","Gate Hold ms","Gate Release ms","Gate Range dB","Deess Enabled","Deess Threshold dB","Deess Ratio","Deess Hz"};
const LADSPA_PortRangeHint hints[]={{0,0,0},{0,0,0},{0,0,0},{0,0,0},{RANGE,0,3},{RANGE|LADSPA_HINT_TOGGLED,0,1},{RANGE,20,300},{RANGE|LADSPA_HINT_TOGGLED,0,1},{RANGE,-80,0},{RANGE,1,100},{RANGE,0,1000},{RANGE,10,2000},{RANGE,-80,0},{RANGE|LADSPA_HINT_TOGGLED,0,1},{RANGE,-60,0},{RANGE,1,20},{RANGE,3000,10000}};
const LADSPA_Descriptor descriptor={49003,"tania_mic_tools",LADSPA_PROPERTY_HARD_RT_CAPABLE,"Tania Microphone Tools","Tania's Sound Box contributors","GNU AGPL v3 or later",17,ports,names,hints,nullptr,instantiate,connect,activate,run,nullptr,nullptr,nullptr,cleanup};
}
extern "C" const LADSPA_Descriptor* ladspa_descriptor(unsigned long index) { return index==0 ? &descriptor : nullptr; }
