// SPDX-License-Identifier: AGPL-3.0-or-later
#include "StereoCompressor.h"
#include <algorithm>
#include <cmath>
#include <limits>
namespace tania {
StereoCompressor::StereoCompressor(double rate) noexcept : rate_(std::isfinite(rate) && rate >= 8000 ? rate : 48000) {}
void StereoCompressor::process(const float* left, const float* right, float* outLeft, float* outRight,
                              std::size_t frames, bool enabled, float threshold, float ratio,
                              float attackMs, float releaseMs, float makeupDb) noexcept {
    auto bounded=[](float value, float low, float high, float fallback) {
        return std::isfinite(value) ? std::clamp(value,low,high) : fallback;
    };
    threshold=bounded(threshold,-60,0,-18);
    ratio=bounded(ratio,1,20,4);
    const double attack=std::exp(-1/(rate_*bounded(attackMs,1,200,10)*.001));
    const double release=std::exp(-1/(rate_*bounded(releaseMs,10,2000,150)*.001));
    const double makeup=std::pow(10.,bounded(makeupDb,0,12,0)/20.);
    const double thresholdAmplitude=std::pow(10.,threshold/20.);
    const double slope=1-1./ratio;
    const double maximum=std::numeric_limits<float>::max();
    for(std::size_t i=0;i<frames;++i) {
        const double l=std::isfinite(left[i]) ? left[i] : 0;
        const double r=std::isfinite(right[i]) ? right[i] : 0;
        if(!enabled) { reduction_=0; outLeft[i]=static_cast<float>(l); outRight[i]=static_cast<float>(r); continue; }
        const double peak=std::max(std::abs(l),std::abs(r));
        const double target=peak>thresholdAmplitude && slope>0
            ? (20*std::log10(peak)-threshold)*slope : 0;
        const double coefficient=target>reduction_ ? attack : release;
        reduction_=coefficient*reduction_+(1-coefficient)*target;
        if(reduction_<1.e-12) reduction_=0;
        const double gain=(reduction_>0 ? std::pow(10.,-reduction_/20) : 1)*makeup;
        outLeft[i]=static_cast<float>(std::clamp(l*gain,-maximum,maximum));
        outRight[i]=static_cast<float>(std::clamp(r*gain,-maximum,maximum));
    }
}
}
