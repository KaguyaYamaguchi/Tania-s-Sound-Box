// SPDX-License-Identifier: AGPL-3.0-or-later
#include <ladspa.h>
#include "StereoCompressor.h"
#include <array>
#include <new>
namespace {
struct Instance {
    explicit Instance(unsigned long rate) : compressor(static_cast<double>(rate)) {}
    tania::StereoCompressor compressor;
    std::array<LADSPA_Data*,10> ports{};
};
LADSPA_Handle instantiate(const LADSPA_Descriptor*, unsigned long rate) { return new(std::nothrow) Instance(rate); }
void connect(LADSPA_Handle handle, unsigned long port, LADSPA_Data* data) { if(port<10) static_cast<Instance*>(handle)->ports[port]=data; }
void activate(LADSPA_Handle handle) { static_cast<Instance*>(handle)->compressor.reset(); }
void run(LADSPA_Handle handle, unsigned long frames) {
    auto& instance=*static_cast<Instance*>(handle); auto& p=instance.ports;
    for(auto port:p) if(!port) return;
    instance.compressor.process(p[0],p[1],p[2],p[3],frames,*p[4]>=.5f,*p[5],*p[6],*p[7],*p[8],*p[9]);
}
void cleanup(LADSPA_Handle handle) { delete static_cast<Instance*>(handle); }
const LADSPA_PortDescriptor ports[]={
    LADSPA_PORT_INPUT|LADSPA_PORT_AUDIO,LADSPA_PORT_INPUT|LADSPA_PORT_AUDIO,
    LADSPA_PORT_OUTPUT|LADSPA_PORT_AUDIO,LADSPA_PORT_OUTPUT|LADSPA_PORT_AUDIO,
    LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,
    LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,
    LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL,LADSPA_PORT_INPUT|LADSPA_PORT_CONTROL};
const char* const names[]={"Left In","Right In","Left Out","Right Out","Enabled","Threshold dB","Ratio","Attack ms","Release ms","Makeup dB"};
const LADSPA_PortRangeHint hints[]={
    {0,0,0},{0,0,0},{0,0,0},{0,0,0},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE|LADSPA_HINT_TOGGLED|LADSPA_HINT_DEFAULT_0,0,1},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE,-60,0},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE,1,20},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE,1,200},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE,10,2000},
    {LADSPA_HINT_BOUNDED_BELOW|LADSPA_HINT_BOUNDED_ABOVE|LADSPA_HINT_DEFAULT_0,0,12}};
const LADSPA_Descriptor descriptor={49002,"tania_stereo_compressor",LADSPA_PROPERTY_HARD_RT_CAPABLE,
    "Tania Stereo Compressor","Tania's Sound Box contributors","GNU AGPL v3 or later",
    10,ports,names,hints,nullptr,instantiate,connect,activate,run,nullptr,nullptr,nullptr,cleanup};
}
extern "C" const LADSPA_Descriptor* ladspa_descriptor(unsigned long index) { return index==0 ? &descriptor : nullptr; }
