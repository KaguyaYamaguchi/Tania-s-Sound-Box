// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <cstddef>
namespace tania {
class StereoCompressor {
public:
    explicit StereoCompressor(double sampleRate) noexcept;
    void reset() noexcept { reduction_ = 0; }
    void process(const float* left, const float* right, float* outLeft, float* outRight,
                 std::size_t frames, bool enabled, float threshold, float ratio,
                 float attackMs, float releaseMs, float makeupDb) noexcept;
private:
    double rate_;
    double reduction_ = 0;
};
}
