// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <cstddef>
namespace tania {
// Stereo-linked sample-peak limiter, instantaneous attack, exponential release.
// No lookahead, allocations, locks, or I/O in process(). Single audio owner.
class StereoLimiter {
public:
    explicit StereoLimiter(double sampleRate) noexcept;
    void reset() noexcept { gain_=1; }
    void process(const float* left, const float* right, float* outputLeft,
                 float* outputRight, std::size_t frames, bool enabled,
                 float ceilingDb, float releaseMs, float& peakDb,
                 float& reductionDb) noexcept;
private:
    double sampleRate_;
    double gain_=1;
};
}
