"""Validated controls and atomic Linux settings storage."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import math
import os
from pathlib import Path
import tempfile

BANDS = (60, 170, 310, 600, 1000, 3000, 6000, 12000, 16000)
LIMITS = {"gain": (-24, 12), "balance": (-100, 100),
          'ceiling': (-12, 0), 'release': (10, 1000),
          'threshold': (-60, 0), 'ratio': (1, 20), 'attack': (1, 200),
          'compressor_release': (10, 2000), 'makeup': (0, 12),
          **{f"eq_{band}": (-12, 12) for band in BANDS}}
DEFAULTS = {key: 0 for key in LIMITS}
DEFAULTS.update(ceiling=-1, release=100, threshold=-18, ratio=4, attack=10, compressor_release=150, makeup=0)


def settings_path():
    base = os.environ.get("XDG_CONFIG_HOME", "")
    if not base or not Path(base).is_absolute():
        home = os.environ.get("HOME", "")
        if not home or not Path(home).is_absolute():
            raise ValueError("Set XDG_CONFIG_HOME or HOME to an absolute path.")
        base = str(Path(home) / ".config")
    return Path(base) / "tanias-sound-box" / "settings.json"


def validate(data):
    if not isinstance(data, dict):
        raise ValueError("Settings must contain an object.")
    result = {}
    bypass = data.get('bypass', False)
    if not isinstance(bypass, bool):
        raise ValueError('Bypass must be true or false.')
    limiter = data.get('limiter', True)
    if not isinstance(limiter, bool):
        raise ValueError('Limiter must be true or false.')
    for key, (low, high) in LIMITS.items():
        value = data.get(key, DEFAULTS[key])
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"Invalid value for {key}.")
        if not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f"Value outside supported range for {key}.")
        result[key] = float(value)
    result['bypass'] = bypass
    compressor = data.get('compressor', False)
    if not isinstance(compressor, bool):
        raise ValueError('Compressor must be true or false.')
    result['compressor'] = compressor
    result['limiter'] = limiter
    return result


def save_settings(path, values):
    values = validate(values)
    atomic_write(path, values)


def atomic_write(path, values):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", dir=path.parent,
                                         delete=False, encoding="utf-8") as stream:
            temporary = Path(stream.name)
            json.dump(values, stream, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
