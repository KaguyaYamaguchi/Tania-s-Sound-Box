"""Read-only support report; never starts or reconfigures an audio session."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import importlib.util
import json
import platform
import shutil
import subprocess
from pathlib import Path
from audio_backend import snapshot, AudioError
from controls import atomic_write
from processing_graph import limiter_plugin
from preflight import runtime_errors
try:
    from build_info import VERSION
except ImportError:
    VERSION = 'development'


def report(audio=None):
    tools = {name: shutil.which(name) is not None for name in ('pipewire', 'pw-dump', 'pw-cli', 'pw-loopback')}
    plugins = {}
    for name in ('tania_limiter.so', 'tania_compressor.so', 'tania_mic.so'):
        try:
            limiter_plugin(name)
            plugins[name] = True
        except AudioError:
            plugins[name] = False
    try:
        version = subprocess.run(['pipewire', '--version'], capture_output=True, text=True, timeout=3)
        pipewire_version = version.stdout.strip() if version.returncode == 0 else 'unavailable'
    except (OSError, subprocess.TimeoutExpired):
        pipewire_version = 'unavailable'
    if audio is None:
        try:
            audio = snapshot()
        except AudioError as error:
            audio = {'connected': False, 'error': str(error)}
    # Deliberately include the public summary, not raw PipeWire object metadata.
    audio = {key: audio[key] for key in ('connected', 'default_output', 'default_input', 'outputs', 'inputs',
                                       'processing', 'routing', 'limiter', 'session', 'microphone', 'error') if key in audio}
    return {'schema': 1, 'application': "Tania's Sound Box", 'version': VERSION,
            'system': {'distribution': platform.freedesktop_os_release().get('PRETTY_NAME', 'Linux'),
                       'architecture': platform.machine(), 'python': platform.python_version()},
            'runtime': {'tools': tools, 'tkinter': importlib.util.find_spec('tkinter') is not None,
                        'pipewire_version': pipewire_version, 'plugins': plugins},
            'audio': audio,
            'limitations': ['Sample-peak limiter; no true-peak or lookahead processing.',
                            'Control-rate smoothing; no sample-accurate parameter ramps.',
                            'Full graph recreation changes OBS device node IDs.',
                            'Requested node latency is not measured end-to-end latency.']}


def export(path, audio=None):
    atomic_write(path, report(audio))


if __name__ == '__main__':
    import sys
    data = report()
    if '--check' in sys.argv[1:]:
        errors = runtime_errors()
        if not data['audio'].get('connected'):
            errors.append(data['audio'].get('error', 'Cannot connect to PipeWire.'))
        if not data['runtime']['tkinter']:
            errors.append('Tkinter is missing. Install python3-tk.')
        data['readiness'] = {'ready': not errors, 'errors': errors}
        print(json.dumps(data, indent=2, allow_nan=False))
        raise SystemExit(1 if errors else 0)
    print(json.dumps(data, indent=2, allow_nan=False))
