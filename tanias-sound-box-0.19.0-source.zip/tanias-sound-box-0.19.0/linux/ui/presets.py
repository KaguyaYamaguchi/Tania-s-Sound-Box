"""Versioned, portable sound presets; hardware preferences stay separate."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
from controls import validate, settings_path, atomic_write

FACTORY = {
    'Flat': {},
    'Voice clarity': {'eq_60': -3, 'eq_170': -2, 'eq_1000': 2, 'eq_3000': 3, 'gain': -3},
    'Warm music': {'eq_60': 3, 'eq_170': 2, 'eq_3000': -1, 'gain': -3},
}


def preset_name(name):
    if not isinstance(name, str) or not name.strip() or len(name) > 80 or any(ord(c) < 32 for c in name):
        raise ValueError('Preset names must contain 1–80 printable characters.')
    return name.strip()


def decode(data):
    if not isinstance(data, dict) or type(data.get('schema')) is not int or data.get('schema') != 1:
        raise ValueError('Unsupported preset format. Expected schema 1.')
    return preset_name(data.get('name')), validate(data.get('controls'))


class Presets:
    def __init__(self, path=None):
        self.path = path or settings_path().with_name('presets.json')

    def custom(self):
        if not self.path.exists():
            return {}
        data = json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(data, dict) or type(data.get('schema')) is not int or data.get('schema') != 1 or not isinstance(data.get('presets'), dict):
            raise ValueError('Invalid preset library.')
        result = {}
        for name, values in data['presets'].items():
            clean = preset_name(name)
            if clean in FACTORY or clean in result:
                raise ValueError('Preset library contains reserved or duplicate names.')
            result[clean] = validate(values)
        return result

    def all(self):
        return {**{name: validate(values) for name, values in FACTORY.items()}, **self.custom()}

    def save(self, name, values):
        name = preset_name(name)
        if name in FACTORY:
            raise ValueError('Choose a new name for your custom preset.')
        presets = self.custom()
        presets[name] = validate(values)
        atomic_write(self.path, {'schema': 1, 'presets': presets})

    def export(self, path, name, values):
        name = preset_name(name)
        if name in FACTORY:
            name += ' (custom)'
        atomic_write(path, {'schema': 1, 'name': preset_name(name), 'controls': validate(values)})

    def import_file(self, path):
        name, values = decode(json.loads(path.read_text(encoding='utf-8')))
        self.save(name, values)
        return name
