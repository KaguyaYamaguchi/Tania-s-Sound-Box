"""Device preference storage kept separate from audio presets."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
from controls import settings_path, atomic_write


def validate_preference(data):
    if not isinstance(data, dict):
        raise ValueError('Preferences must contain an object.')
    name = data.get('hardware_output')
    if name is not None and (not isinstance(name, str) or not name or len(name) > 512 or
                             any(ord(character) < 32 for character in name)):
        raise ValueError('Invalid saved hardware output.')
    return {'hardware_output': name}


def load_preferences():
    path = settings_path().with_name('preferences.json')
    return validate_preference(json.loads(path.read_text())) if path.exists() else validate_preference({})


def save_preferences(output):
    atomic_write(settings_path().with_name('preferences.json'), validate_preference({'hardware_output': output}))
