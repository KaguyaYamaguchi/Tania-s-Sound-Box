"""Explicit microphone metering and five-second test recording; no auto capture."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from array import array
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import wave
from audio_backend import AudioError
from virtual_devices import VirtualDevices


def properties():
    return 'application.name = "Tania Sound Box Mic Test" media.role = "SoundBoxTest" node.dont-reconnect = true state.restore-props = false state.restore-target = false state.default-volume = 1.0'


def owned(command, **kwargs):
    return subprocess.Popen([sys.executable, str(Path(__file__).with_name('virtual_devices.py')),
                             '--owned-loopback', str(os.getpid()), *command], **kwargs)


def levels(samples):
    samples = [float(v) for v in samples if math.isfinite(v)]
    if not samples: return {'peak_db': -120., 'rms_db': -120., 'clipped_samples': 0}
    peak = max(abs(v) for v in samples)
    rms = math.sqrt(sum(v*v for v in samples)/len(samples))
    return {'peak_db': 20*math.log10(max(peak, 1e-6)), 'rms_db': 20*math.log10(max(rms, 1e-6)),
            'clipped_samples': sum(abs(v)>=.999 for v in samples)}


class LevelMeter:
    def __init__(self):
        self.process = None
        self.log = None
        self.thread = None
        self.target = None
        self.stats = None
        self.error = None
        self.lock = threading.Lock()

    def start(self, source):
        self.stop()
        if not shutil.which('pw-record'): raise AudioError('Install pipewire-bin to use microphone tests.')
        self.target = source
        self.stats = None
        self.error = None
        self.log = tempfile.TemporaryFile()
        try:
            self.process = owned(['pw-record','--target',source,'--rate','48000','--channels','2',
                                  '--format','f32','--volume','1','-P',properties(),'-'],
                                 stdout=subprocess.PIPE, stderr=self.log)
        except OSError as error:
            self.stop()
            raise AudioError(f'Cannot meter microphone: {error}') from error
        process = self.process
        def read():
            pending = b''
            while True:
                data = process.stdout.read1(7680)
                if not data: break
                pending += data
                size = len(pending)//4*4
                if size:
                    samples = array('f');samples.frombytes(pending[:size]);pending=pending[size:]
                    stats = levels(samples)
                    with self.lock: self.stats = stats
            if self.process is process:
                self.error = 'Meter stream stopped. Check the selected device.'
        self.thread = threading.Thread(target=read, daemon=True)
        self.thread.start()

    def latest(self):
        with self.lock: return dict(self.stats) if self.stats is not None else None

    def stop(self):
        process = self.process
        self.process = None
        if process is not None: VirtualDevices.end_process(process)
        if self.thread is not None: self.thread.join(timeout=2)
        self.thread = None
        if process is not None and process.stdout is not None: process.stdout.close()
        if self.log is not None: self.log.close()
        self.log = None
        self.target = None
        self.error = None
        self.stats = None


class MicRecording:
    def __init__(self):
        self.directory = tempfile.TemporaryDirectory(prefix='tania-mic-test-')
        self.path = Path(self.directory.name)/'test.wav'
        self.stats = None
        self.process = None
        self.lock = threading.Lock()

    def record(self, source, seconds=5):
        if not 1 <= seconds <= 30: raise ValueError('Microphone test duration must be 1–30 seconds.')
        self.path.unlink(missing_ok=True)
        with tempfile.TemporaryFile() as log:
            process = owned(['pw-record','--target',source,'--rate','48000','--channels','2',
                             '--format','s16','--volume','1','-P',properties(),str(self.path)], stdout=log, stderr=log)
            with self.lock: self.process=process
            try:
                deadline=time.monotonic()+seconds
                while time.monotonic()<deadline:
                    if process.poll() is not None: raise AudioError('Microphone test stream stopped before completion.')
                    time.sleep(.05)
            finally:
                VirtualDevices.end_process(process)
                with self.lock: self.process=None
        try:
            with wave.open(str(self.path),'rb') as stream:
                frames=stream.getnframes();rate=stream.getframerate()
                raw=array('h',stream.readframes(frames))
            if sys.byteorder!='little': raw.byteswap()
            if not frames: raise AudioError('No microphone samples were recorded.')
            self.stats={**levels(v/32768 for v in raw), 'seconds':frames/rate}
            return dict(self.stats)
        except (OSError,wave.Error) as error:
            raise AudioError(f'Cannot read microphone test recording: {error}') from error

    def play(self, output):
        if self.stats is None or not self.path.exists(): raise AudioError('Record a microphone test first.')
        with tempfile.TemporaryFile() as log:
            process=owned(['pw-play','--target',output,'--volume','1','-P',properties(),str(self.path)], stdout=log, stderr=log)
            with self.lock: self.process=process
            try:
                process.wait(timeout=40)
                if process.returncode: raise AudioError('Microphone test playback failed.')
            except subprocess.TimeoutExpired as error:
                raise AudioError('Microphone test playback timed out.') from error
            finally:
                VirtualDevices.end_process(process)
                with self.lock: self.process=None

    def export(self, path):
        if self.stats is None: raise AudioError('Record a microphone test first.')
        shutil.copyfile(self.path, path)

    def close(self):
        with self.lock: process=self.process
        if process is not None: VirtualDevices.end_process(process)
        self.directory.cleanup()
