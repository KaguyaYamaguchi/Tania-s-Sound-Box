"""Read-only PipeWire discovery; never changes routing or volume."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import math
import subprocess
from mic_controls import MIC_NAME

PLAYBACK_NAME = 'tanias_sound_box.playback'
MONITOR_NAME = 'tanias_sound_box.recording_monitor'


class AudioError(RuntimeError):
    pass


def parse_snapshot(objects):
    if not isinstance(objects, list):
        raise AudioError('PipeWire returned an invalid object list.')
    default = None
    default_input = None
    outputs = []
    inputs = []
    processing = False
    limiter = None
    for obj in objects:
        if not isinstance(obj, dict):
            continue
        if obj.get('type') == 'PipeWire:Interface:Metadata':
            for entry in obj.get('metadata', []):
                if entry.get('key') in ('default.audio.sink','default.audio.source') and entry.get('subject') == 0:
                    value = entry.get('value', {})
                    if isinstance(value, str):
                        try:
                            value = json.loads(value)
                        except ValueError:
                            value = {}
                    if isinstance(value, dict):
                        if entry['key']=='default.audio.sink': default=value.get('name')
                        else: default_input=value.get('name')
        info = obj.get('info') or {}
        props = info.get('props') or {}
        kind = props.get('media.class')
        if obj.get('type') != 'PipeWire:Interface:Node' or kind not in ('Audio/Sink', 'Audio/Source', 'Audio/Source/Virtual'):
            continue
        name = props.get('node.name')
        if not isinstance(name, str) or not name:
            continue
        if name == PLAYBACK_NAME and props.get('tania.processing') in (True, 'true'):
            processing = True
            controls = {}
            for entry in info.get('params', {}).get('Props', []):
                params = entry.get('params', [])
                controls.update(zip(params[::2], params[1::2]))
            ceiling = controls.get('limiter:Ceiling dB')
            enabled = controls.get('limiter:Enabled')
            if (isinstance(enabled, (int, float)) and math.isfinite(enabled) and
                    isinstance(ceiling, (int, float)) and math.isfinite(ceiling)):
                limiter = {'enabled':controls['limiter:Enabled'] >= .5,
                           'ceiling_db':controls.get('limiter:Ceiling dB'),
                           'peak_db':controls.get('limiter:Peak dB'),
                           'reduction_db':controls.get('limiter:Reduction dB')}
        devices = outputs if kind == 'Audio/Sink' else inputs
        role = ('sound_box_playback' if name == PLAYBACK_NAME else 'hardware_output') if kind == 'Audio/Sink' else (
            'sound_box_monitor' if name == MONITOR_NAME else ('sound_box_microphone' if name == MIC_NAME else 'input'))
        devices.append({'name': name,
                        'description': props.get('node.description') or props.get('node.nick') or name,
                        'role': role,
                        'state': info.get('state', 'unknown'),
                        'format': node_format(info), 'virtual': props.get('node.virtual') in (True,'true')})
    outputs.sort(key=lambda output: (str(output['description']).casefold(), output['name']))
    for output in outputs:
        output['default'] = output['name'] == default
    for source in inputs: source['default']=source['name']==default_input
    return {'connected': True, 'default_output': default, 'default_input': default_input, 'outputs': outputs,
            'inputs': inputs,
            'routing': route_status(objects),
            'limiter': limiter,
            'processing': processing}


def node_format(info):
    props = info.get('props') or {}
    result = {'sample_rate': None, 'channels': None, 'requested_latency': props.get('node.latency')}
    for key, prop in (('sample_rate', 'audio.rate'), ('channels', 'audio.channels')):
        try:
            number = int(props.get(prop, 0))
            result[key] = number if number > 0 else None
        except (ValueError, TypeError):
            pass
    for entry in info.get('params', {}).get('Format', []):
        for key, field in (('sample_rate', 'rate'), ('channels', 'channels')):
            value = entry.get(field)
            if isinstance(value, int) and not isinstance(value, bool) and value > 0:
                result[key] = value
    # Requested scheduling latency is not an end-to-end measurement.
    return result


def route_status(objects):
    nodes = {}
    target = None
    channels = {}
    for obj in objects:
        if not isinstance(obj, dict) or obj.get('type') != 'PipeWire:Interface:Node':
            continue
        props = (obj.get('info') or {}).get('props') or {}
        name = props.get('node.name')
        if isinstance(name, str) and isinstance(obj.get('id'), int):
            nodes[name] = obj['id']
            try:
                count = int(props.get('audio.channels', 2))
            except (ValueError, TypeError):
                count = 2
            channels[name] = max(1, min(node_format(obj.get('info') or {}).get('channels') or count, 2))
        if name == 'tanias_sound_box.hardware_playback':
            target = props.get('target.object')
    pairs = [(nodes.get(MONITOR_NAME), nodes.get('tanias_sound_box.hardware_capture')),
             (nodes.get('tanias_sound_box.hardware_playback'), nodes.get(target))]
    ports = [set(), set()]
    for obj in objects:
        if not isinstance(obj, dict) or obj.get('type') != 'PipeWire:Interface:Link':
            continue
        info = obj.get('info') or {}
        if info.get('state') not in ('active', 'paused'):
            continue
        pair = (info.get('output-node-id'), info.get('input-node-id'))
        for index, expected in enumerate(pairs):
            if None not in expected and pair == expected:
                # Count distinct receiving ports, not duplicate link objects.
                # Older fixtures lacking port IDs use distinct object IDs.
                port = info.get('input-port-id', obj.get('id'))
                if port is not None:
                    ports[index].add(port)
    monitor_linked = len(ports[0]) >= 2
    hardware_linked = len(ports[1]) >= channels.get(target, 2)
    return {'hardware_output': target, 'monitor_linked': monitor_linked,
            'hardware_linked': hardware_linked, 'ready': monitor_linked and hardware_linked}


def decode_dump(text):
    """pw-dump may append update arrays before its discovery roundtrip exits."""
    decoder = json.JSONDecoder()
    offset = 0
    objects = {}
    unnumbered = []
    documents = 0

    def merge(previous, update):
        result = dict(previous)
        for key, value in update.items():
            if isinstance(value, dict) and isinstance(result.get(key), dict):
                result[key] = merge(result[key], value)
            else:
                result[key] = value
        return result

    while offset < len(text):
        while offset < len(text) and text[offset].isspace():
            offset += 1
        if offset == len(text):
            break
        data, offset = decoder.raw_decode(text, offset)
        if not isinstance(data, list):
            raise ValueError('Expected a PipeWire object array.')
        documents += 1
        for obj in data:
            if not isinstance(obj, dict):
                continue
            identity = obj.get('id')
            if not isinstance(identity, int):
                unnumbered.append(obj)
            elif set(obj) == {'id'} or ('info' in obj and obj['info'] is None):
                objects.pop(identity, None)
            elif 'type' in obj:
                # A new complete object replaces stale state after ID reuse.
                objects[identity] = obj
            else:
                objects[identity] = merge(objects.get(identity, {}), obj)
    if documents == 0:
        raise ValueError('Empty PipeWire discovery response.')
    return list(objects.values()) + unnumbered


def raw_snapshot():
    try:
        completed = subprocess.run(['pw-dump', '-N'], capture_output=True, text=True,
                                   timeout=4, check=False)
    except FileNotFoundError as error:
        raise AudioError('pw-dump is missing. Install pipewire-bin.') from error
    except subprocess.TimeoutExpired as error:
        raise AudioError('PipeWire did not respond within four seconds.') from error
    except OSError as error:
        raise AudioError(f'Cannot query PipeWire: {error}') from error
    if completed.returncode:
        detail = completed.stderr.strip()[:300] or 'session unavailable'
        raise AudioError(f'Cannot connect to PipeWire: {detail}')
    try:
        return decode_dump(completed.stdout)
    except (ValueError, TypeError, AttributeError) as error:
        raise AudioError('PipeWire returned malformed discovery data.') from error


def snapshot():
    try:
        return parse_snapshot(raw_snapshot())
    except (ValueError, TypeError, AttributeError) as error:
        raise AudioError('PipeWire returned malformed discovery data.') from error


def main():
    try:
        print(json.dumps(snapshot(), indent=2))
    except AudioError as error:
        import sys
        print(str(error), file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
