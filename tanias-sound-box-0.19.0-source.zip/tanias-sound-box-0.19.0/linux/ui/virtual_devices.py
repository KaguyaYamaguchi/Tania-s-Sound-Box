"""Session-owned processed playback and OBS monitor devices."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from audio_backend import AudioError, snapshot, raw_snapshot, PLAYBACK_NAME, MONITOR_NAME
from processing_graph import graph_command, graph_configuration, apply_controls
from controls import validate
from preflight import check_runtime

PLAYBACK_LABEL = "Tania's Sound Box"
MONITOR_LABEL = "Tania's Sound Box - Recording Monitor"


def commands(hardware, config_path):
    common = {'audio.position': ['FL', 'FR'], 'node.virtual': True,
              'priority.session': 1, 'state.restore-props': False,
              'state.restore-target': False, 'state.default-volume': 1.0}
    def props(values):
        return json.dumps({**common, **values}, ensure_ascii=False)
    return [
        graph_command(config_path),
        ['pw-loopback', '--capture-props', props({
            'node.name': 'tanias_sound_box.hardware_capture',
            'node.description': "Tania's Sound Box - Processed Capture",
            'target.object': MONITOR_NAME,
            'node.dont-reconnect': True, 'node.passive': True}), '--playback-props', props({
            'node.name': 'tanias_sound_box.hardware_playback',
            'node.description': "Tania's Sound Box - Hardware Output",
            'target.object': hardware, 'node.dont-reconnect': True,
            'node.passive': True})]
    ]


class VirtualDevices:
    def __init__(self):
        self.processes = []
        self.logs = []
        self.lock = None
        self.hardware = None
        self.config_directory = None
        self.bypass = False

    @property
    def active(self):
        return len(self.processes) == 2 and all(process.poll() is None for process in self.processes)

    @property
    def graph_active(self):
        return bool(self.processes) and self.processes[0].poll() is None

    def detach_hardware(self):
        if len(self.processes) > 1:
            self.end_process(self.processes.pop())
            self.logs.pop().close()

    def attach_hardware(self, hardware):
        if not self.graph_active:
            raise AudioError('The processing graph is unavailable.')
        self.detach_hardware()
        self.hardware = hardware
        log = tempfile.TemporaryFile()
        self.logs.append(log)
        command = commands(hardware, '')[1]
        owned = [sys.executable, str(Path(__file__).resolve()), '--owned-loopback', str(os.getpid()), *command]
        try:
            self.processes.append(subprocess.Popen(owned, stdout=log, stderr=log))
            self.wait_ready(True)
        except (OSError, AudioError):
            if len(self.processes) > 1:
                self.detach_hardware()
            else:
                self.logs.pop().close()
            raise

    def start(self, hardware, values=None, bypass=False):
        values = validate({**(values or {}), 'bypass': bypass})
        if self.processes:
            raise AudioError('Disable the current Sound Box devices first.')
        check_runtime()
        current = snapshot()
        if hardware not in {o['name'] for o in current['outputs'] if o['role'] == 'hardware_output'}:
            raise AudioError('Selected hardware output is no longer available. Refresh audio.')
        if any(o['name'] == PLAYBACK_NAME for o in current['outputs']) or any(
                i['name'] == MONITOR_NAME for i in current['inputs']):
            raise AudioError('Sound Box devices already exist. Disable them in the owning app first.')
        runtime = os.environ.get('XDG_RUNTIME_DIR', '')
        if not runtime or not Path(runtime).is_absolute() or not Path(runtime).is_dir():
            raise AudioError('XDG_RUNTIME_DIR is unavailable. Run from your Linux desktop session.')
        try:
            self.lock = open(Path(runtime) / 'tanias-sound-box.lock', 'a')
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.hardware = hardware
            self.config_directory = tempfile.TemporaryDirectory(prefix='tanias-sound-box-')
            config = Path(self.config_directory.name) / 'processing.conf'
            config.write_text(graph_configuration(values), encoding='utf-8')
            for index, command in enumerate(commands(hardware, config)):
                log = tempfile.TemporaryFile()
                self.logs.append(log)
                owned = [sys.executable, str(Path(__file__).resolve()), '--owned-loopback',
                         str(os.getpid()), *command]
                self.processes.append(subprocess.Popen(owned, stdout=log,
                                                        stderr=log))
                if index == 0:
                    # The hardware loopback must not connect until its source
                    # exists: dont-reconnect intentionally fails missing targets.
                    self.wait_ready(False)
            self.wait_ready(True)
            apply_controls(values or {}, bypass)
            self.bypass = bypass
            return snapshot()
        except (OSError, AudioError) as error:
            self.stop()
            if isinstance(error, BlockingIOError):
                raise AudioError('Another Sound Box window owns the virtual devices.') from error
            if isinstance(error, AudioError):
                raise
            raise AudioError(f'Cannot start Sound Box devices: {error}') from error

    def wait_ready(self, require_hardware):
        deadline = time.monotonic() + 6
        while time.monotonic() < deadline:
            if not (self.active if require_hardware else self.graph_active):
                raise AudioError('PipeWire could not create Sound Box devices. ' + self.log_errors())
            current = snapshot()
            names = {obj.get('info', {}).get('props', {}).get('node.name') for obj in raw_snapshot()
                     if obj.get('type') == 'PipeWire:Interface:Node'} if require_hardware else set()
            if (any(o['name'] == PLAYBACK_NAME for o in current['outputs']) and
                    any(i['name'] == MONITOR_NAME for i in current['inputs']) and
                    (not require_hardware or {'tanias_sound_box.hardware_capture',
                                              'tanias_sound_box.hardware_playback'}.issubset(names) and
                     current['routing']['ready'] and current['routing'].get('hardware_output') == self.hardware)):
                return
            time.sleep(0.1)
        raise AudioError('Timed out waiting for Sound Box devices.')

    def log_errors(self):
        parts = []
        for log in self.logs:
            log.seek(0)
            parts.append(log.read(500).decode('utf-8', errors='replace').strip())
        return ' '.join(parts)

    def apply(self, values, bypass=False):
        if not self.graph_active:
            raise AudioError('Enable Sound Box before applying live controls.')
        apply_controls(values, bypass)
        self.bypass = bypass
        return snapshot()

    def stop(self):
        # Remove the hardware route before the processing devices; own clients only.
        for process in reversed(self.processes):
            self.end_process(process)
        self.processes.clear()
        for log in self.logs:
            log.close()
        self.logs.clear()
        if self.lock is not None:
            self.lock.close()
            self.lock = None
        self.hardware = None
        self.bypass = False
        if self.config_directory is not None:
            self.config_directory.cleanup()
            self.config_directory = None

    @staticmethod
    def end_process(process):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)


def run_owned_loopback():
    # A guardian watches the owning PROCESS. PR_SET_PDEATHSIG alone would also
    # fire when the short-lived UI worker thread that spawned us exits.
    import signal
    parent = int(sys.argv[2])
    command = sys.argv[3:]
    if os.getppid() != parent:
        raise SystemExit(1)
    stopping = False
    def request_stop(*_):
        nonlocal stopping
        stopping = True
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGINT, request_stop)
    process = subprocess.Popen(command)
    try:
        while not stopping and os.getppid() == parent and process.poll() is None:
            time.sleep(0.05)
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        if os.getppid() != parent and len(command) == 3 and command[:2] == ['pipewire', '-c']:
            config = Path(command[2])
            if config.name == 'processing.conf' and config.parent.name.startswith('tanias-sound-box-'):
                try:
                    config.unlink(missing_ok=True)
                    config.parent.rmdir()
                except OSError:
                    pass
    raise SystemExit(process.returncode or 0)


if __name__ == '__main__' and len(sys.argv) >= 4 and sys.argv[1] == '--owned-loopback':
    run_owned_loopback()
