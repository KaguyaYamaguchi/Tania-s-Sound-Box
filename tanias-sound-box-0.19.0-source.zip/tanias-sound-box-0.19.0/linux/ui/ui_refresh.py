"""Update discovered UI data without destroying selection or redrawing unchanged rows."""
import hashlib


def identity(*parts):
    return hashlib.sha256(repr(parts).encode()).hexdigest()


def sync_tree(tree, rows):
    # Rows are ordered parent first: (identity, parent, text, values).
    wanted={row[0] for row in rows}
    def prune(parent=''):
        for key in tree.get_children(parent):
            if key not in wanted: tree.delete(key)
            else: prune(key)
    prune()
    positions={}
    for key,parent,text,values in rows:
        position=positions.get(parent,0);positions[parent]=position+1
        if not tree.exists(key):
            tree.insert(parent,position,iid=key,text=text,values=values,open=True)
        else:
            old=tree.item(key)
            if old['text']!=text or tuple(map(str,old['values']))!=tuple(map(str,values)):
                tree.item(key,text=text,values=values)
            children=tree.get_children(parent)
            if position>=len(children) or children[position]!=key: tree.move(key,parent,position)


def choices(widget, values):
    values=tuple(values)
    if tuple(widget['values'])!=values: widget.configure(values=values)


def select_index(widget, index):
    if index>=0:
        if widget.current()!=index: widget.current(index)
    elif widget.get(): widget.set('')
