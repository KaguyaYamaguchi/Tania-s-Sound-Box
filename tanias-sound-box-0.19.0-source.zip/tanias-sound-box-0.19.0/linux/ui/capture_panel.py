"""Capture Point tab: connected devices, cards, and active capture/playback apps."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk
from audio_backend import AudioError
import capture_backend as backend
from ui_refresh import identity, sync_tree, choices, select_index
from ui_design import PALETTE, pages, table_scroll, card


class CapturePointPanel:
    def __init__(self,root,parent,profiles,on_mic,is_visible):
        self.root=root;self.profiles=profiles;self.on_mic=on_mic;self.is_visible=is_visible
        self.busy=False;self.closing=False;self.last_check=0;self.results=queue.Queue()
        self.devices=[];self.streams=[];self.cards=[];self.selected_key=None;self.last_snapshot=None;self.card_key=None
        self.status=tk.StringVar(value='Discovering connected audio devices…')
        self.alias=tk.StringVar();self.role=tk.StringVar();self.volume=tk.DoubleVar(value=100);self.muted=tk.BooleanVar(value=False)
        self.details=tk.StringVar(value='Select a device to inspect its system identity and format.')
        container=ttk.Frame(parent);container.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(container,background=PALETTE['background'],highlightthickness=0)
        scroll=ttk.Scrollbar(container,orient='vertical',command=self.canvas.yview);self.canvas.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        panel=ttk.Frame(self.canvas,padding=24);window=self.canvas.create_window((0,0),window=panel,anchor='nw')
        panel.bind('<Configure>',lambda _:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(window,width=e.width))
        top=ttk.Frame(panel);top.pack(fill='x')
        ttk.Label(top,text='Capture Point',style='Title.TLabel').pack(side='left')
        self.buttons=[]
        self.button(top,'Refresh devices',lambda:self.task(backend.inventory),side='right')
        ttk.Label(panel,text='Connected inputs, outputs and virtual capture sources',style='Muted.TLabel').pack(anchor='w',pady=(5,12))
        self.sections,(devices_page,points_page,apps_page,hardware_page)=pages(panel,('Devices','Device jobs','App routing','Hardware'))
        cols=('system','direction','state','volume','mute','default','role')
        self.tree=ttk.Treeview(devices_page,columns=cols,height=8,selectmode='browse')
        self.tree.heading('#0',text='Sound Box name');self.tree.column('#0',width=200,minwidth=170)
        for key,title,width in (('system','System name',260),('direction','Type',65),('state','State',85),('volume','Volume',70),('mute','Mute',60),('default','Default',60),('role','Sound Box role',170)):
            self.tree.heading(key,text=title);self.tree.column(key,width=width,minwidth=max(65,width-10),stretch=True)
        self.tree.pack(fill='x');table_scroll(devices_page,self.tree);self.tree.bind('<<TreeviewSelect>>',self.select_device)
        ttk.Label(devices_page,textvariable=self.details,style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=(8,4))
        ttk.Label(points_page,text='Sound Box points — assign device jobs',font=('Sans',15,'bold')).pack(anchor='w',pady=(16,6))
        ttk.Label(points_page,text='Select a point below, name it, then assign its job. Earphones can provide output while a separate input (such as WO Mic) is assigned Microphone. Unassigned points remain available. Expand hardware connections to choose a port; connections on one audio device share its job and can only be switched where Linux supports it.',style='Muted.TLabel',wraplength=850).pack(anchor='w')
        self.points=ttk.Treeview(points_page,columns=('system','direction','job','use'),height=6,selectmode='browse')
        self.points.heading('#0',text='Sound Box point');self.points.column('#0',width=220)
        for key,title in (('system','System name'),('direction','Type'),('job','Assigned job'),('use','Current use')):
            self.points.heading(key,text=title);self.points.column(key,width=160)
        self.points.pack(fill='x',pady=6);table_scroll(points_page,self.points);self.points.bind('<<TreeviewSelect>>',self.select_point)
        local=ttk.Frame(points_page);local.pack(fill='x',pady=6)
        ttk.Label(local,text='Sound Box label:').pack(side='left');ttk.Entry(local,textvariable=self.alias,width=25).pack(side='left',padx=6)
        self.role_choice=ttk.Combobox(local,textvariable=self.role,state='readonly',width=25);self.role_choice.pack(side='left',padx=6)
        self.button(local,'Save label / role',self.save_role)
        ttk.Label(points_page,text='Microphone points are offered to the mic configurator; Auxiliary input and Desktop capture points are reserved for other capture uses. Jobs do not change another app’s device automatically. Select Use input for mic to target the configurator.',style='Muted.TLabel',wraplength=850).pack(anchor='w')
        system=card(devices_page,'System level');system.pack(fill='x',pady=8)
        ttk.Label(system,text='System volume (%):').pack(side='left')
        ttk.Spinbox(system,from_=0,to=150,textvariable=self.volume,width=7).pack(side='left',padx=6)
        ttk.Checkbutton(system,text='System mute',variable=self.muted).pack(side='left',padx=6)
        self.button(system,'Apply system volume / mute',self.apply_device)
        self.button(system,'Make system default',self.default)
        ports=card(devices_page,'Hardware connection');ports.pack(fill='x',pady=4)
        ttk.Label(ports,text='Hardware port:').pack(side='left')
        self.port_choice=ttk.Combobox(ports,state='readonly',width=45);self.port_choice.pack(side='left',padx=6)
        self.button(ports,'Use port',self.port)
        self.button(ports,'Use input for mic',self.use_mic)
        ttk.Label(apps_page,text='Active app streams — route apps to a device',font=('Sans',15,'bold')).pack(anchor='w',pady=(16,8))
        self.stream_tree=ttk.Treeview(apps_page,columns=('direction','target'),height=6,selectmode='browse')
        self.stream_tree.heading('#0',text='Application / capture');self.stream_tree.column('#0',width=280)
        self.stream_tree.heading('direction',text='Use');self.stream_tree.column('direction',width=80)
        self.stream_tree.heading('target',text='Current device');self.stream_tree.column('target',width=450)
        self.stream_tree.pack(fill='x');table_scroll(apps_page,self.stream_tree)
        row=ttk.Frame(apps_page);row.pack(fill='x',pady=6)
        self.button(row,'Move selected app to selected device',self.move)
        ttk.Label(apps_page,text='Select an app below and an input/output above, then Move selected app. Example: route OBS capture to your mic, or a music player to earphones. Capture needs an input; playback needs an output. Only running streams appear; app restart may reset the route. Native PipeWire apps may require their own selector.',style='Muted.TLabel',wraplength=850).pack(anchor='w')
        ttk.Label(hardware_page,text='Audio card profiles',font=('Sans',15,'bold')).pack(anchor='w',pady=(16,8))
        cards=ttk.Frame(hardware_page);cards.pack(fill='x')
        self.card_choice=ttk.Combobox(cards,state='readonly',width=32);self.card_choice.pack(side='left',padx=(0,6));self.card_choice.bind('<<ComboboxSelected>>',self.select_card)
        self.profile_choice=ttk.Combobox(cards,state='readonly',width=40);self.profile_choice.pack(side='left',padx=6)
        self.button(cards,'Use profile',self.profile)
        ttk.Label(hardware_page,text='Profile changes can recreate device nodes. Re-select a new input/output in Sound Box if its name changes.',style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=6)
        ttk.Label(panel,textvariable=self.status,style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=10)
        self.task(backend.inventory);root.after(100,self.poll)

    def button(self,parent,text,command,side='left'):
        b=ttk.Button(parent,text=text,command=command);b.pack(side=side,padx=3);self.buttons.append(b);return b
    def task(self,work,background=False):
        if self.busy or self.closing:return
        self.busy=True;self.last_check=time.monotonic()
        if not background:
            for b in self.buttons:b.configure(state='disabled')
        def run():
            try:self.results.put((True,work()))
            except (AudioError,OSError,ValueError,KeyError,TypeError) as e:self.results.put((False,str(e)))
        threading.Thread(target=run,daemon=True).start()
    def action(self,work,note):
        def run():
            work();result=backend.inventory();result['note']=note;result['reload_selected']=True;return result
        self.task(run)
    def device(self):
        selected=self.tree.selection()
        if not selected:raise ValueError('Select a connected device first.')
        return self.device_rows[selected[0]]
    def select_point(self,*_):
        selected=self.points.selection()
        if selected:
            index,port=self.point_rows[selected[0]]
            if self.tree.selection()!= (index,):self.tree.selection_set(index)
            self.select_device()
            if port:self.port_choice.set(port);self.status.set('Hardware connection selected. Use port activates it; ports on one device share its assigned job.')

    def pulse_device(self):
        d=self.device()
        if not d.get('pulse'):raise AudioError('This device requires its native application controls; Pulse-compatible controls are unavailable.')
        return d
    def select_device(self,*_):
        try:d=self.device()
        except (ValueError,IndexError,KeyError):return
        key=(d['kind'],d['name'])
        if key==self.selected_key:return
        self.selected_key=key
        try:profile=self.profiles.all().get(d['kind']+':'+d['name'],{})
        except (OSError,ValueError) as e:self.status.set(str(e));profile={}
        self.alias.set(profile.get('alias',''));self.role.set(profile.get('role',self.default_role(d)))
        self.role_choice.configure(values=('Unassigned','Playback output','Hidden from choosers') if d['kind']=='output' else ('Unassigned','Microphone','Auxiliary input','Desktop capture','Hidden from choosers'))
        self.volume.set(d.get('volume_percent') if d.get('volume_percent') is not None else 100);self.muted.set(bool(d.get('muted')))
        ports=d.get('ports') or []
        names=list(ports) if isinstance(ports,dict) else [p['name'] for p in ports]
        self.port_choice.configure(values=names);self.port_choice.set(d.get('active_port') or '')
        fmt=d.get('format') or {};rate=fmt.get('sample_rate');channels=fmt.get('channels')
        self.details.set(f"System ID: {d['name']}\nFormat: {rate or 'unknown'} Hz • {channels or 'unknown'} channel(s) • Requested latency: {fmt.get('requested_latency') or 'unspecified'}")
    def default_role(self,d):
        if d['kind']=='output':return 'Unassigned'
        return 'Desktop capture' if d['name'].endswith('.monitor') or d.get('role')=='sound_box_monitor' else 'Unassigned'
    def save_role(self):
        try:d=self.device();self.profiles.save(d['kind'],d['name'],self.alias.get(),self.role.get());self.action(lambda:None,'Sound Box label and selection role saved.')
        except (AudioError,OSError,ValueError) as e:self.status.set(str(e))
    def apply_device(self):
        try:d=self.pulse_device();volume=self.volume.get();muted=self.muted.get()
        except (AudioError,ValueError,tk.TclError) as e:self.status.set(str(e));return
        self.action(lambda:backend.set_device(d['kind'],d['name'],volume,muted),'System volume and mute confirmed.')
    def default(self):
        try:d=self.pulse_device()
        except (AudioError,ValueError) as e:self.status.set(str(e));return
        self.action(lambda:backend.make_default(d['kind'],d['name']),'System default confirmed.')
    def port(self):
        try:d=self.pulse_device();port=self.port_choice.get()
        except (AudioError,ValueError) as e:self.status.set(str(e));return
        self.action(lambda:backend.set_port(d['kind'],d['name'],port),'Hardware port confirmed.')
    def use_mic(self):
        try:
            d=self.device()
            if d['kind']!='input':raise ValueError('Select an input for the mic configurator.')
            self.profiles.save('input',d['name'],self.alias.get(),'Microphone')
            self.role.set('Microphone');self.on_mic(d['name'])
        except (AudioError,ValueError) as e:self.status.set(str(e))
    def move(self):
        try:
            d=self.pulse_device();selection=self.stream_tree.selection()
            if not selection:raise ValueError('Select an active app stream first.')
            s=self.stream_rows[selection[0]]
            if s['internal']:raise ValueError('Change owned Sound Box routes in their own tabs.')
        except (AudioError,ValueError) as e:self.status.set(str(e));return
        self.action(lambda:backend.move_stream(s['kind'],s['index'],d['kind'],d['name']),'App stream destination confirmed.')
    def select_card(self,*_):
        index=self.card_choice.current()
        if not 0<=index<len(self.cards):self.profile_choice.set('');return
        card=self.cards[index];self.card_key=card['name'];profiles=card.get('profiles') or []
        names=list(profiles) if isinstance(profiles,dict) else [p['name'] for p in profiles]
        self.profile_choice.configure(values=names)
        active=card.get('active_profile');self.profile_choice.set(active.get('name','') if isinstance(active,dict) else (active or ''))
    def profile(self):
        index=self.card_choice.current()
        if not 0<=index<len(self.cards):self.status.set('Choose an audio card first.');return
        name=self.cards[index]['name'];profile=self.profile_choice.get()
        self.action(lambda:backend.set_profile(name,profile),'Audio card profile confirmed; check input/output selections.')
    def render(self,result):
        self.last_snapshot=result;profiles=self.profiles.all();previous=self.selected_key
        self.devices=result['devices'];self.streams=result['streams'];self.cards=result['cards']
        device_rows=[];point_rows=[];stream_rows=[]
        self.device_rows={};self.point_rows={};self.stream_rows={}
        for d in self.devices:
            key=identity(d['kind'],d['name']);self.device_rows[key]=d;self.point_rows[key]=(key,'')
            p=profiles.get(d['kind']+':'+d['name'],{});volume=d.get('volume_percent')
            name=backend.sound_box_name(d,profiles);role=p.get('role',self.default_role(d))
            device_rows.append((key,'',name,(d['name'],d['kind'],d['state'],f'{volume:.1f}%' if volume is not None else '—','Yes' if d.get('muted') else 'No' if d.get('muted') is not None else '—','Yes' if d.get('default') else '',role)))
            use='; '.join(s['application'] for s in self.streams if s['target']==d['name']) or 'Unused / available'
            point_rows.append((key,'',name,(d['name'],d['kind'],role,use)))
            ports=d.get('ports') or []
            if isinstance(ports,dict):ports=[dict(value,name=name) for name,value in ports.items()]
            for port in ports:
                if str(port.get('availability','')).lower() in ('no','not available'):continue
                child=identity(key,port['name']);self.point_rows[child]=(key,port['name'])
                active=port['name']==d.get('active_port')
                point_rows.append((child,key,port.get('description') or port['name'],(port['name'],d['kind'],'Shares device job','Active connection' if active else 'Available connection — Use port')))
        sync_tree(self.tree,device_rows);sync_tree(self.points,point_rows)
        if result.get('reload_selected'):
            self.selected_key=None;self.select_device()
        elif previous and not any((d['kind'],d['name'])==previous for d in self.devices):
            self.selected_key=None;self.details.set('Selected device disconnected. Refresh or select another device.')
        for s in self.streams:
            key=identity(s['kind'],s['index']);self.stream_rows[key]=s
            label=s['application']+(' (Sound Box owned)' if s['internal'] else '')+((' — '+s['name']) if s['name'] else '')
            target=next((backend.sound_box_name(d,profiles) for d in self.devices if d['name']==s['target']),s['target'] or 'unlinked')
            stream_rows.append((key,'',label,(s['kind'],target)))
        sync_tree(self.stream_tree,stream_rows)
        choices(self.card_choice,[c.get('properties',{}).get('device.description') or c['name'] for c in self.cards])
        index=next((i for i,c in enumerate(self.cards) if c['name']==self.card_key),0 if self.card_key is None and self.cards else -1)
        if index>=0:
            select_index(self.card_choice,index)
            if self.card_key is None:self.select_card()
        else:self.card_choice.set('');self.profile_choice.set('')
        self.status.set(result.get('note') or result.get('error') or f"{len(self.devices)} devices • {len(self.streams)} active app streams")
    def poll(self):
        try:ok,result=self.results.get_nowait()
        except queue.Empty:pass
        else:
            self.busy=False
            for b in self.buttons:b.configure(state='normal')
            if not ok:self.status.set(result)
            else:
                try:self.render(result)
                except (OSError,ValueError,KeyError,TypeError) as e:self.status.set(str(e))
        if not self.closing and not self.busy and self.is_visible() and time.monotonic()-self.last_check>5:self.task(backend.inventory,background=True)
        self.root.after(100,self.poll)
    def close(self):self.closing=True
