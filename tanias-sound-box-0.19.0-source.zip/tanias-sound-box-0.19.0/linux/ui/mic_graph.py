"""Selected input → mic tools/EQ/dynamics → named capture source."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from audio_backend import AudioError
from mic_controls import validate, MODES, MIC_CAPTURE, MIC_NAME, MIC_LABEL
from processing_graph import graph_arguments, control_params as sound_params, configuration_for, limiter_plugin


def parameters(values):
    values = validate(values)
    bypass = values['bypass']
    params = sound_params(values, bypass)
    if values['muted']:
        params['left_gain:Gain 1'] = params['right_gain:Gain 1'] = 0
    params.update({'mic:Mode': float(3 if bypass else MODES.index(values['mode'])),
                   'mic:HP Enabled': float(values['highpass_enabled'] and not bypass), 'mic:HP Hz': values['highpass'],
                   'mic:Gate Enabled': float(values['gate_enabled'] and not bypass),
                   'mic:Gate Threshold dB': values['gate_threshold'], 'mic:Gate Attack ms': values['gate_attack'],
                   'mic:Gate Hold ms': values['gate_hold'], 'mic:Gate Release ms': values['gate_release'],
                   'mic:Gate Range dB': values['gate_range'],
                   'mic:Deess Enabled': float(values['deess_enabled'] and not bypass),
                   'mic:Deess Threshold dB': values['deess_threshold'], 'mic:Deess Ratio': values['deess_ratio'],
                   'mic:Deess Hz': values['deess_frequency']})
    return params


def arguments(source, values):
    values = validate(values)
    params = parameters(values)
    args = graph_arguments(values)
    graph = args['filter.graph']
    for node in graph['nodes']:
        for key in node.get('control', {}):
            qualified = node['name'] + ':' + key
            if qualified in params: node['control'][key] = params[qualified]
    graph['nodes'].insert(0, {'type': 'ladspa', 'name': 'mic', 'plugin': str(limiter_plugin('tania_mic.so')),
                             'label': 'tania_mic_tools', 'control': {key[4:]: value for key, value in params.items() if key.startswith('mic:')}})
    for channel, port in zip(('Left', 'Right'), graph['inputs']):
        graph['links'].append({'output': f'mic:{channel} Out', 'input': port})
    graph['inputs'] = ['mic:Left In', 'mic:Right In']
    args['node.description'] = MIC_LABEL + ' Processing'
    args['capture.props'].update({'node.name': MIC_CAPTURE, 'node.description': MIC_LABEL + ' Capture',
                                  'media.class': 'Stream/Input/Audio', 'target.object': source,
                                  'node.autoconnect': True, 'node.dont-reconnect': True, 'tania.microphone': True})
    args['playback.props'].update({'node.name': MIC_NAME, 'node.description': MIC_LABEL,
                                   'tania.microphone': True})
    return args


def configuration(source, values):
    return configuration_for(arguments(source, values))


def eligible(source):
    return source.get('role') == 'input' and not source['name'].endswith('.monitor')


def route(objects, source):
    nodes = {o.get('info', {}).get('props', {}).get('node.name'): o for o in objects
             if o.get('type') == 'PipeWire:Interface:Node' and isinstance(o.get('info'), dict)}
    capture, output, physical = nodes.get(MIC_CAPTURE), nodes.get(MIC_NAME), nodes.get(source)
    linked = set()
    if capture and physical:
        for obj in objects:
            info = obj.get('info') or {}
            if (obj.get('type') == 'PipeWire:Interface:Link' and info.get('state') in ('active', 'paused') and
                    info.get('output-node-id') == physical.get('id') and info.get('input-node-id') == capture.get('id')):
                linked.add(info.get('input-port-id', obj.get('id')))
    from audio_backend import node_format
    count = min(2, node_format(physical.get('info') or {}).get('channels') or 2) if physical else 2
    target = (capture.get('info') or {}).get('props', {}).get('target.object') if capture else None
    return {'ready': bool(output and target == source and len(linked - {None}) >= count),
            'input': source, 'linked_channels': len(linked - {None}), 'source_available': bool(output)}
