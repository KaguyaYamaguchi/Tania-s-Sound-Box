"""Independent, explicitly enabled and owned microphone processing session."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from audio_backend import AudioError, raw_snapshot, parse_snapshot
from mic_controls import validate, MIC_NAME, MIC_CAPTURE, device_name
from mic_graph import configuration, parameters, eligible, route
from processing_graph import graph_command, apply_parameters, limiter_plugin
from preflight import check_runtime
from virtual_devices import VirtualDevices


class MicrophoneSession:
    def __init__(self):
        self.enabled = False
        self.source = None
        self.controls = validate({})
        self.confirmed = None
        self.state = 'disabled'
        self.message = 'Microphone disabled.'
        self.client = None
        self.log = None
        self.directory = None
        self.lock = None
        self.retry_at = 0
        self.failures = 0
        self.generation = 0
        self.monitor_target = None
        self.monitor_client = None
        self.monitor_log = None

    @property
    def active(self):
        return self.client is not None and self.client.poll() is None

    def describe(self, current, objects):
        return {**current, 'microphone': {'enabled': self.enabled, 'state': self.state,
                    'input': self.source, 'message': self.message, 'generation': self.generation,
                    'desired_controls': dict(self.controls), 'confirmed_controls': dict(self.confirmed) if self.confirmed else None,
                    'route': route(objects, self.source), 'monitor_target': self.monitor_target,
                    'monitoring': self.monitor_client is not None and self.monitor_client.poll() is None}}

    def read(self):
        try:
            objects = raw_snapshot()
            return parse_snapshot(objects), objects
        except AudioError as error:
            return {'connected': False, 'inputs': [], 'outputs': [], 'error': str(error)}, []

    def owned(self, command, log):
        return subprocess.Popen([sys.executable, str(Path(__file__).with_name('virtual_devices.py')),
                                '--owned-loopback', str(os.getpid()), *command], stdout=log, stderr=log)

    def launch(self):
        check_runtime()
        limiter_plugin('tania_mic.so')
        current, objects = self.read()
        if not current['connected']: raise AudioError(current['error'])
        if self.source not in {i['name'] for i in current['inputs'] if eligible(i)}:
            raise AudioError('Selected microphone input is unavailable.')
        if any(i['name'] == MIC_NAME for i in current['inputs']):
            raise AudioError('Another Sound Box window owns the microphone source.')
        try:
            self.lock = open(Path(os.environ['XDG_RUNTIME_DIR'])/'tanias-sound-box-microphone.lock', 'a')
            fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.directory = tempfile.TemporaryDirectory(prefix='tanias-sound-box-')
            config = Path(self.directory.name)/'processing.conf'
            config.write_text(configuration(self.source, self.controls), encoding='utf-8')
            self.log = tempfile.TemporaryFile()
            self.client = self.owned(graph_command(config), self.log)
            deadline = time.monotonic()+6
            while time.monotonic()<deadline:
                current, objects = self.read()
                if not self.active:
                    self.log.seek(0)
                    raise AudioError('Microphone processing could not start: '+self.log.read(1000).decode(errors='replace'))
                if route(objects, self.source)['ready']:
                    apply_parameters(MIC_CAPTURE, parameters(self.controls))
                    self.confirmed = dict(self.controls)
                    self.generation += 1
                    self.state = 'live'
                    self.message = 'Processed microphone is available to capture apps.'
                    return
                time.sleep(.1)
            raise AudioError('Timed out linking the selected microphone.')
        except (OSError, AudioError) as error:
            self.stop_graph()
            if isinstance(error, BlockingIOError): raise AudioError('Another Sound Box window owns the microphone.') from error
            if isinstance(error, AudioError): raise
            raise AudioError(f'Cannot start microphone: {error}') from error

    def enable(self, source, values):
        if self.enabled: raise AudioError('Disable the microphone before selecting a different input.')
        self.source = device_name(source)
        self.controls = validate(values)
        self.launch()
        self.enabled = True
        self.failures = 0
        self.retry_at = 0
        current, objects = self.read()
        return self.describe(current, objects)

    def apply(self, values, immediate=False):
        if not self.enabled: raise AudioError('Enable the microphone before applying controls.')
        self.controls = validate(values)
        if self.active:
            try:
                apply_parameters(MIC_CAPTURE, parameters(self.controls), steps=1 if immediate else 8)
                self.confirmed = dict(self.controls)
                self.message = 'Microphone controls applied.'
            except (AudioError, OSError):
                self.stop_graph()
                self.state = 'recovering'
                self.retry_at = 0
                self.message = 'Microphone controls queued for reconnection.'
        else:
            self.confirmed = None
            self.state = 'recovering'
            self.message = 'Microphone controls queued for reconnection.'
        current, objects = self.read()
        return self.describe(current, objects)

    def mute(self, value):
        return self.apply({**self.controls, 'muted': bool(value)}, immediate=True)

    def stop_monitor(self):
        if self.monitor_client is not None: VirtualDevices.end_process(self.monitor_client)
        self.monitor_client = None
        if self.monitor_log is not None: self.monitor_log.close()
        self.monitor_log = None

    def monitor(self, target):
        self.stop_monitor()
        self.monitor_target = device_name(target)
        if target is not None:
            if not self.enabled or not self.active: raise AudioError('Enable the microphone before monitoring.')
            current, _ = self.read()
            if target not in {o['name'] for o in current['outputs'] if o['role']=='hardware_output'}:
                raise AudioError('Selected monitoring output is unavailable.')
            common = {'node.virtual': True, 'audio.position': ['FL','FR'], 'audio.channels': 2,
                      'node.dont-reconnect': True, 'state.restore-props': False, 'state.restore-target': False,
                      'state.default-volume': 1.0, 'priority.session': 1}
            capture = {**common, 'node.name': 'tanias_sound_box.microphone_monitor_capture', 'target.object': MIC_NAME}
            playback = {**common, 'node.name': 'tanias_sound_box.microphone_monitor_playback', 'target.object': target}
            self.monitor_log = tempfile.TemporaryFile()
            try:
                self.monitor_client = self.owned(['pw-loopback','--capture-props',json.dumps(capture),
                                                 '--playback-props',json.dumps(playback)], self.monitor_log)
            except OSError as error:
                self.stop_monitor()
                raise AudioError(f'Cannot monitor microphone: {error}') from error
        current, objects = self.read()
        return self.describe(current, objects)

    def stop_graph(self):
        self.stop_monitor()
        if self.client is not None: VirtualDevices.end_process(self.client)
        self.client = None
        self.confirmed = None
        if self.log is not None: self.log.close()
        self.log = None
        if self.lock is not None: self.lock.close()
        self.lock = None
        if self.directory is not None: self.directory.cleanup()
        self.directory = None

    def disable(self):
        self.enabled = False
        self.monitor_target = None
        self.stop_graph()
        self.state = 'disabled'
        self.message = 'Microphone disabled.'
        current, objects = self.read()
        return self.describe(current, objects)

    def poll(self):
        current, objects = self.read()
        if not self.enabled: return self.describe(current, objects)
        available = self.source in {i['name'] for i in current['inputs'] if eligible(i)}
        if not current['connected'] or not available:
            self.stop_graph()
            self.state = 'waiting_input' if current['connected'] else 'waiting_server'
            self.message = 'Waiting for the selected microphone.' if available is False and current['connected'] else 'Waiting for PipeWire.'
            return self.describe(*self.read())
        if not self.active or not route(objects, self.source)['ready']:
            if time.monotonic()<self.retry_at: return self.describe(current, objects)
            self.stop_graph()
            try:
                self.launch()
                self.failures=0;self.retry_at=0
            except (OSError, AudioError) as error:
                self.state='recovering';self.message=str(error);self.failures+=1
                self.retry_at=time.monotonic()+min(8,2**min(self.failures-1,3))
        if self.active and self.monitor_target:
            outputs={o['name'] for o in current['outputs'] if o['role']=='hardware_output'}
            if self.monitor_target not in outputs: self.stop_monitor()
            elif self.monitor_client is None or self.monitor_client.poll() is not None:
                try: self.monitor(self.monitor_target)
                except AudioError: self.stop_monitor()
        return self.describe(*self.read())
