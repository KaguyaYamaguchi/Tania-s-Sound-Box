"""Portable microphone presets, distinct from playback presets."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
from controls import settings_path, atomic_write
from mic_controls import validate
from presets import preset_name
FACTORY = {'Natural voice': {}, 'Streaming voice': {'gate_enabled':True,'compressor':True,
           'threshold':-18,'ratio':3,'makeup':3,'deess_enabled':True},
           'Quiet speech': {'gain':6,'compressor':True,'threshold':-24,'ratio':2,'attack':15}}

class MicPresets:
    def __init__(self, path=None): self.path=path or settings_path().with_name('mic-presets.json')
    def custom(self):
        if not self.path.exists(): return {}
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or type(data.get('schema')) is not int or data['schema']!=1 or not isinstance(data.get('presets'),dict):
            raise ValueError('Unsupported microphone preset library.')
        result={}
        for name, values in data['presets'].items():
            name=preset_name(name)
            if name in FACTORY or name in result: raise ValueError('Reserved/duplicate microphone preset name.')
            result[name]=validate(values)
        return result
    def all(self): return {**{k:validate(v) for k,v in FACTORY.items()},**self.custom()}
    def save(self,name,values):
        name=preset_name(name)
        if name in FACTORY: raise ValueError('Choose a custom microphone preset name.')
        data=self.custom();data[name]=validate(values)
        atomic_write(self.path,{'schema':1,'presets':data})
    def export(self,path,name,values):
        name=preset_name(name)
        if name in FACTORY: name+=' (custom)'
        atomic_write(path,{'schema':1,'type':'microphone','name':name,'controls':validate(values)})
    def decode(self,path):
        data=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or type(data.get('schema')) is not int or data['schema']!=1 or data.get('type')!='microphone':
            raise ValueError('Choose a microphone preset file.')
        return preset_name(data.get('name')),validate(data.get('controls'))
