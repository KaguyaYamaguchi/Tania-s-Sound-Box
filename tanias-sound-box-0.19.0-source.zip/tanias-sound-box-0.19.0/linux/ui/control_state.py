"""Editor, storage and verified processing state remain independent."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from controls import validate


class ControlState:
    def __init__(self, values, persisted=True):
        self.editor = validate(values)
        self.saved = dict(self.editor) if persisted else None
        self.requested = None
        self.confirmed = None
        self.enabled = False

    def stage(self, values):
        self.editor = validate(values)

    def mark_saved(self, values):
        self.saved = validate(values)

    def observe(self, session):
        self.enabled = bool(session.get('enabled', False))
        desired = session.get('desired_controls')
        actual = session.get('confirmed_controls')
        self.requested = validate(desired) if isinstance(desired, dict) and self.enabled else None
        self.confirmed = validate(actual) if isinstance(actual, dict) and self.enabled else None

    @property
    def unsaved(self):
        return self.editor != self.saved

    @property
    def unapplied(self):
        return self.enabled and self.editor != self.confirmed

    def describe(self):
        storage = 'Changes not saved' if self.unsaved else 'Settings saved'
        if not self.enabled:
            processing = 'Processing disabled'
        elif self.confirmed is not None and self.editor == self.confirmed:
            processing = 'Controls match processing'
        elif self.requested == self.editor and self.confirmed is None:
            processing = 'Controls queued for reconnection'
        else:
            processing = 'Changes not applied'
        return processing + ' • ' + storage
