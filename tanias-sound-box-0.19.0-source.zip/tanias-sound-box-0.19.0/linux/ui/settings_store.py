"""Atomic controls/output storage with migration from pre-0.12 settings."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import os
import time
from controls import settings_path, validate, atomic_write
from preferences import load_preferences, validate_preference


class UnsupportedSettings(ValueError):
    pass


def load(path=None):
    path = path or settings_path()
    if not path.exists():
        return validate({}), load_preferences()['hardware_output']
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('Invalid settings document.')
    if 'schema' not in data:
        return validate(data), load_preferences()['hardware_output']
    if type(data['schema']) is not int or data['schema'] != 1:
        raise UnsupportedSettings('Unsupported settings format; original file preserved.')
    return validate(data.get('controls')), validate_preference(data)['hardware_output']


def save(values, output, path=None):
    document = {'schema': 1, 'controls': validate(values), **validate_preference({'hardware_output': output})}
    path = path or settings_path()
    backup = None
    if path.exists():
        original = path.read_bytes()
        try:
            previous = json.loads(original)
            if isinstance(previous, dict) and 'schema' in previous:
                if type(previous['schema']) is not int or previous['schema'] != 1:
                    raise UnsupportedSettings('Unsupported settings format; original file preserved.')
                validate(previous.get('controls'))
                validate_preference(previous)
            else:
                validate(previous)
        except UnsupportedSettings:
            raise
        except (ValueError, TypeError):
            # Keep an exact copy before recovering damaged JSON/control values.
            backup = path.with_name(path.name + '.corrupt-' + str(time.time_ns()))
            descriptor = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, 'wb') as stream:
                stream.write(original)
                stream.flush()
                os.fsync(stream.fileno())
    atomic_write(path, document)
    return backup
