"""Linux control panel for live PipeWire sound processing."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import queue
import threading
import time
import tkinter as tk
from tkinter import messagebox, ttk, filedialog, simpledialog
from audio_backend import AudioError, snapshot
from virtual_devices import PLAYBACK_LABEL, MONITOR_LABEL
from diagnostics import export as export_diagnostics
from presets import Presets
from pathlib import Path
from session import AudioSession
from settings_store import load as load_settings, save as save_settings_bundle
from control_state import ControlState
from capture_backend import DeviceProfiles
from mic_panel import MicrophonePanel
from capture_panel import CapturePointPanel
from ui_design import PALETTE, theme, card, pages

from controls import BANDS, LIMITS, DEFAULTS, settings_path, validate


class SoundBox:
    def __init__(self, root):
        self.root = root
        root.title("Tania's Sound Box")
        root.geometry(f"{min(1280,root.winfo_screenwidth()-60)}x{min(900,root.winfo_screenheight()-100)}")
        root.minsize(1000,650)
        theme(root)
        self.values = {key: tk.DoubleVar(value=DEFAULTS[key]) for key in LIMITS}
        self.bypass = tk.BooleanVar(value=False)
        self.limiter = tk.BooleanVar(value=True)
        self.compressor = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value="Enable Sound Box to process audio. Apply controls after adjustments.")
        self.path = None
        self.preferred_output = None
        load_error = None
        settings_persisted = False
        try:
            self.path = settings_path()
            loaded, self.preferred_output = load_settings(self.path)
            for key in LIMITS:
                self.values[key].set(loaded[key])
            self.bypass.set(loaded['bypass'])
            self.limiter.set(loaded['limiter'])
            self.compressor.set(loaded['compressor'])
            if self.path.exists():
                settings_persisted = True
                self.status.set("Loaded saved controls. Enable Sound Box to process audio.")
        except (OSError, ValueError) as error:
            load_error = str(error)
        self.control_state = ControlState(self.current_controls(), persisted=settings_persisted)
        self.control_status = tk.StringVar(value=self.control_state.describe())
        self.profiles = DeviceProfiles()
        header=ttk.Frame(root,padding=(24,16));header.pack(fill='x')
        self.brand_icon=tk.PhotoImage(file=str(Path(__file__).parent/'assets/icon-32.png'))
        self.window_icon=tk.PhotoImage(file=str(Path(__file__).parent/'assets/icon-256.png'))
        root.iconphoto(True,self.window_icon)
        ttk.Label(header,image=self.brand_icon).pack(side='left',padx=(0,12))
        ttk.Label(header,text="Tania's Sound Box",style='Brand.TLabel').pack(side='left')
        ttk.Label(header,text='LINUX MINT   •   AUDIO WORKSPACE',style='Muted.TLabel').pack(side='right')
        ttk.Separator(root).pack(fill='x')
        workspace=ttk.Frame(root);workspace.pack(fill='both',expand=True)
        sidebar=ttk.Frame(workspace,padding=(12,20),width=190);sidebar.pack(side='left',fill='y');sidebar.pack_propagate(False)
        ttk.Label(sidebar,text='WORKSPACE',style='Muted.TLabel').pack(anchor='w',padx=14,pady=(0,16))
        self.navigation=tk.IntVar(value=0)
        self.notebook = ttk.Notebook(workspace,style='Workspace.TNotebook')
        self.notebook.pack(side='left',fill='both', expand=True)
        for index,title in enumerate(('Sound controls','Mic configurator','Capture Point')):
            ttk.Radiobutton(sidebar,text=title,variable=self.navigation,value=index,style='Nav.TRadiobutton',command=lambda i=index:self.notebook.select(i)).pack(fill='x',pady=4)
        ttk.Label(sidebar,text='YOUR AUDIO.\nYOUR CONTROL.',style='Muted.TLabel',justify='left').pack(side='bottom',anchor='w',padx=14,pady=20)
        self.notebook.bind('<<NotebookTabChanged>>',lambda _:self.navigation.set(self.notebook.index(self.notebook.select())))
        playback_tab=ttk.Frame(self.notebook)
        mic_tab=ttk.Frame(self.notebook)
        capture_tab=ttk.Frame(self.notebook)
        self.notebook.add(playback_tab, text="Sound controls")
        self.notebook.add(mic_tab, text="Mic configurator")
        self.notebook.add(capture_tab, text="Capture Point")
        container = ttk.Frame(playback_tab)
        container.pack(fill="both", expand=True)
        canvas = tk.Canvas(container, background=PALETTE["background"], highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        panel = ttk.Frame(canvas, padding=24)
        panel_window = canvas.create_window((0, 0), window=panel, anchor="nw")
        panel.bind("<Configure>", lambda _: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(panel_window, width=event.width))
        self.playback_canvas=canvas
        root.bind("<Button-4>", lambda _: self.scroll_current(-1))
        root.bind("<Button-5>", lambda _: self.scroll_current(1))
        ttk.Label(panel, text="Sound controls", style="Title.TLabel").pack(anchor="w")
        ttk.Label(panel, text="Shape your desktop mix. Choose where it plays and what OBS captures.", style="Muted.TLabel").pack(anchor="w", pady=(4, 16))
        self.mode = tk.StringVar(value="READY — Live gain, balance and EQ available when enabled")
        ttk.Label(panel, textvariable=self.mode,
                  foreground=PALETTE["accent"]).pack(anchor="w", pady=(0, 16))
        route_card=card(panel,"01  /  OUTPUT ROUTING")
        audio_row = ttk.Frame(route_card)
        audio_row.pack(fill="x", pady=(0, 12))
        self.audio_status = tk.StringVar(value="Checking PipeWire…")
        ttk.Label(audio_row, textvariable=self.audio_status, wraplength=650,
                  style="Muted.TLabel").pack(side="left")
        self.refresh_button = ttk.Button(audio_row, text="Refresh audio", command=self.refresh_audio)
        self.refresh_button.pack(side="right")
        routing = ttk.Frame(route_card)
        routing.pack(fill="x", pady=(0, 6))
        ttk.Label(routing, text="Hardware Output:").pack(side="left")
        self.hardware_choice = ttk.Combobox(routing, state="readonly", width=44)
        self.hardware_choice.pack(side="left", fill="x", expand=True, padx=12)
        self.hardware_choice.bind('<<ComboboxSelected>>', self.remember_output)
        self.device_button = ttk.Button(routing, text="Enable Sound Box", command=self.toggle_devices)
        self.device_button.pack(side="right")
        self.apply_button = ttk.Button(routing, text="Apply controls", command=self.apply_live,style="Accent.TButton")
        self.apply_button.pack(side="right", padx=6)
        ttk.Label(route_card, text=f"Playback: {PLAYBACK_LABEL}\nOBS input: {MONITOR_LABEL}",
                  style="Muted.TLabel").pack(anchor="w", pady=(0, 12))
        self.session = AudioSession()
        self.devices = self.session.devices
        self.hardware_outputs = []
        self.audio_busy = False
        self.closing = False
        self.audio_note = None
        self.last_audio_check = 0
        self.audio_results = queue.Queue()
        self.last_snapshot = None
        self.refresh_audio()
        root.after(100, self.poll_audio)
        master = card(panel,"02  /  MASTER CONTROLS")
        self.horizontal(master, "Master gain", "gain", "dB")
        self.horizontal(master, "Balance  (left ↔ right)", "balance", "%")
        self.bypass_button = ttk.Checkbutton(master, text="Bypass processing", variable=self.bypass,
                                             command=self.controls_changed)
        self.bypass_button.pack(anchor="w", pady=4)
        self.bypass_button.configure(state="disabled" if self.audio_busy else "normal")
        self.effects_notebook,(eq_page,dynamics_page)=pages(panel,('Equalizer','Dynamics & protection'))
        dynamics_card=card(dynamics_page,'Output limiter & compressor')
        self.limiter_button = ttk.Checkbutton(dynamics_card, text="Stereo output limiter", variable=self.limiter,
                                              command=self.controls_changed)
        self.limiter_button.pack(anchor="w", pady=4)
        self.limiter_button.configure(state="disabled" if self.audio_busy else "normal")
        self.horizontal(dynamics_card, "Limiter ceiling", "ceiling", "dBFS")
        self.horizontal(dynamics_card, "Limiter release", "release", "ms")
        self.compressor_button = ttk.Checkbutton(dynamics_card, text="Stereo compressor", variable=self.compressor,
                                                 command=self.controls_changed)
        self.compressor_button.pack(anchor="w", pady=(12, 4))
        self.compressor_button.configure(state="disabled" if self.audio_busy else "normal")
        for title, key, unit in (("Compressor threshold", "threshold", "dBFS"),
                                 ("Compression ratio", "ratio", ":1"), ("Compressor attack", "attack", "ms"),
                                 ("Compressor release", "compressor_release", "ms"), ("Makeup gain", "makeup", "dB")):
            self.horizontal(dynamics_card, title, key, unit)
        self.level_status = tk.StringVar(value="Limiter: ready • default ceiling -1 dBFS")
        ttk.Label(dynamics_card, textvariable=self.level_status, style="Muted.TLabel").pack(anchor="w")
        ttk.Label(eq_page, text="Equalizer", font=("Sans", 15, "bold")).pack(anchor="w", pady=(18, 10))
        eq = ttk.Frame(eq_page)
        eq.pack(fill="both", expand=True)
        for index, band in enumerate(BANDS):
            eq.columnconfigure(index, weight=1)
            column = ttk.Frame(eq)
            column.grid(row=0, column=index, sticky="nsew", padx=4)
            key = f"eq_{band}"
            label = f"{band // 1000}k" if band >= 1000 else str(band)
            ttk.Label(column, text=label + " Hz").pack()
            ttk.Scale(column, from_=12, to=-12, orient="vertical", length=170,
                      variable=self.values[key]).pack(pady=10, fill="y", expand=True)
            self.readout(column, key, "dB").pack()
        self.presets = Presets()
        preset_row = card(panel,"PRESET LIBRARY")

        ttk.Label(preset_row, text="Sound preset:").pack(side="left")
        self.preset_choice = ttk.Combobox(preset_row, state="readonly", width=22)
        self.preset_choice.pack(side="left", padx=8)
        for title, command in (("Load", self.load_preset), ("Save as…", self.save_preset),
                               ("Import…", self.import_preset), ("Export…", self.export_preset)):
            ttk.Button(preset_row, text=title, command=command).pack(side="left", padx=2)
        self.refresh_presets()
        actions = ttk.Frame(panel)
        actions.pack(fill="x", pady=(20, 10))
        ttk.Button(actions, text="Export diagnostics…", command=self.export_diagnostics).pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Reset controls", command=self.reset).pack(side="left")
        ttk.Button(actions, text="Save settings", command=self.save).pack(side="right")
        ttk.Label(panel, textvariable=self.status, wraplength=800,
                  style="Muted.TLabel").pack(anchor="w")
        ttk.Label(panel, textvariable=self.control_status, wraplength=800,
                  style="Muted.TLabel").pack(anchor="w", pady=(8, 0))
        for variable in (*self.values.values(), self.bypass, self.limiter, self.compressor):
            variable.trace_add('write', self.controls_changed)
        self.mic_panel=MicrophonePanel(root,mic_tab,self.profiles)
        self.capture_panel=CapturePointPanel(root,capture_tab,self.profiles,self.use_mic_input,
                lambda:self.notebook.index(self.notebook.select())==2)
        root.protocol("WM_DELETE_WINDOW", self.close)
        if load_error:
            root.after(0, lambda: messagebox.showwarning("Settings unavailable", load_error, parent=root))

    def scroll_current(self, direction):
        index=self.notebook.index(self.notebook.select())
        canvas=self.playback_canvas if index==0 else (self.mic_panel.canvas if index==1 else self.capture_panel.canvas)
        canvas.yview_scroll(direction,"units")

    def use_mic_input(self,name):
        self.mic_panel.select_source(name)
        self.notebook.select(1)

    def export_diagnostics(self):
        filename = filedialog.asksaveasfilename(parent=self.root, defaultextension='.json',
                    initialfile='sound-box-diagnostics.json', filetypes=[("Diagnostics", "*.json")])
        if not filename:
            return
        try:
            audio=dict(self.last_snapshot or {})
            if self.mic_panel.last_snapshot: audio['microphone']=self.mic_panel.last_snapshot['microphone']
            export_diagnostics(Path(filename), audio or None)
            self.status.set("Diagnostics exported.")
        except (OSError, ValueError) as error:
            messagebox.showerror("Cannot export diagnostics", str(error), parent=self.root)

    def refresh_presets(self, selected=None):
        try:
            names = list(self.presets.all())
            self.preset_choice.configure(values=names)
            self.preset_choice.set(selected or names[0])
        except (OSError, ValueError) as error:
            self.status.set(f"Preset library unavailable: {error}")

    def load_preset(self):
        try:
            values = self.presets.all()[self.preset_choice.get()]
            for key in LIMITS:
                self.values[key].set(values[key])
            self.bypass.set(values['bypass'])
            self.limiter.set(values['limiter'])
            self.compressor.set(values['compressor'])
            self.status.set("Preset loaded. Apply controls to update live audio.")
        except (OSError, ValueError, KeyError) as error:
            messagebox.showerror("Cannot load preset", str(error), parent=self.root)

    def save_preset(self):
        name = simpledialog.askstring("Save preset", "Preset name:", parent=self.root)
        if name is None:
            return
        try:
            if name.strip() in self.presets.custom() and not messagebox.askyesno("Replace preset?", "Replace this saved preset?", parent=self.root):
                return
            self.presets.save(name, self.current_controls())
            self.refresh_presets(name.strip())
            self.status.set("Preset saved.")
        except (OSError, ValueError) as error:
            messagebox.showerror("Cannot save preset", str(error), parent=self.root)

    def import_preset(self):
        filename = filedialog.askopenfilename(parent=self.root, filetypes=[("Sound preset", "*.json")])
        if not filename:
            return
        try:
            from presets import decode
            name, _ = decode(json.loads(Path(filename).read_text(encoding='utf-8')))
            if name in self.presets.custom() and not messagebox.askyesno("Replace preset?", "Replace this saved preset?", parent=self.root):
                return
            self.refresh_presets(self.presets.import_file(Path(filename)))
            self.status.set("Preset imported. Load it to use its controls.")
        except (OSError, ValueError) as error:
            messagebox.showerror("Cannot import preset", str(error), parent=self.root)

    def export_preset(self):
        filename = filedialog.asksaveasfilename(parent=self.root, defaultextension='.json', filetypes=[("Sound preset", "*.json")])
        if not filename:
            return
        try:
            self.presets.export(Path(filename), self.preset_choice.get() or 'Custom', self.current_controls())
            self.status.set("Current controls exported.")
        except (OSError, ValueError) as error:
            messagebox.showerror("Cannot export preset", str(error), parent=self.root)

    def refresh_audio(self):
        self.audio_task(self.session.poll, background=True)

    def remember_output(self, *_):
        index = self.hardware_choice.current()
        if 0 <= index < len(self.hardware_outputs):
            self.preferred_output = self.hardware_outputs[index]['name']

    def controls_changed(self, *_):
        self.control_state.stage(self.current_controls())
        self.control_status.set(self.control_state.describe())
        self.status.set("Controls changed. Apply controls to update live audio; save to keep these values.")

    def audio_task(self, task, note=None, background=False):
        if self.audio_busy or self.closing:
            return
        self.audio_busy = True
        self.audio_note = note
        self.last_audio_check = time.monotonic()
        if not background:
            self.refresh_button.configure(state="disabled")
            self.device_button.configure(state="disabled")
            self.apply_button.configure(state="disabled")
            if hasattr(self, 'bypass_button'):
                self.bypass_button.configure(state="disabled")
            if hasattr(self, 'limiter_button'):
                self.limiter_button.configure(state="disabled")
            if hasattr(self, 'compressor_button'):
                self.compressor_button.configure(state='disabled')
            self.hardware_choice.configure(state="disabled")
            self.audio_status.set("Checking PipeWire…")
        def query():
            try:
                result = task()
                self.audio_results.put(result)
            except (AudioError, OSError, ValueError) as error:
                if self.devices.processes:
                    self.session.disable()
                self.audio_results.put(str(error))
        threading.Thread(target=query, daemon=True).start()

    def toggle_devices(self):
        if self.session.enabled:
            def stop():
                self.session.disable()
                return self.session.poll()
            self.audio_task(stop, "Sound Box disabled.")
        else:
            index = self.hardware_choice.current()
            if index < 0 or index >= len(self.hardware_outputs):
                self.status.set("Select an available hardware output first.")
                return
            hardware = self.hardware_outputs[index]["name"]
            self.preferred_output = hardware
            values = self.current_controls()
            self.audio_task(lambda: self.session.enable(hardware, values), "Live processing enabled.")

    def current_controls(self):
        return {**{key: value.get() for key, value in self.values.items()},
                'bypass': self.bypass.get(), 'limiter': self.limiter.get(), 'compressor': self.compressor.get()}

    def apply_live(self):
        if not self.session.enabled:
            self.status.set("Controls ready. Enable Sound Box to apply them.")
            return
        values = self.current_controls()
        bypass = self.bypass.get()
        self.audio_task(lambda: self.session.apply(values), "Live controls applied." if not bypass else "Processing bypassed; OBS capture stays available.")

    def poll_audio(self):
        try:
            result = self.audio_results.get_nowait()
        except queue.Empty:
            pass
        else:
            self.audio_busy = False
            if isinstance(result, str):
                self.audio_status.set(result)
                self.status.set(result)
            else:
                self.last_snapshot = result
                self.control_state.observe(result.get('session', {}))
                self.control_state.stage(self.current_controls())
                self.control_status.set(self.control_state.describe())
                if self.audio_note:
                    self.status.set(result.get('session', {}).get('message', self.audio_note))
                limiter = result.get('limiter')
                if limiter:
                    peak = limiter.get('peak_db')
                    reduction = limiter.get('reduction_db')
                    telemetry = f" • Sampled peak: {peak:.1f} dBFS • Reduction: {reduction:.1f} dB" if isinstance(peak, (float, int)) and isinstance(reduction, (float, int)) else ""
                    self.level_status.set(f"Limiter: {'enabled' if limiter['enabled'] else 'off'} • Ceiling: {limiter['ceiling_db']:.1f} dBFS{telemetry}")
                else:
                    self.level_status.set("Limiter: inactive")
                outputs = result["outputs"]
                selected = self.hardware_choice.current()
                previous = self.hardware_outputs[selected]["name"] if 0 <= selected < len(self.hardware_outputs) else None
                try: profiles=self.profiles.all()
                except (OSError,ValueError): profiles={}
                self.hardware_outputs = [output for output in outputs if output["role"] == "hardware_output" and
                    profiles.get('output:'+output['name'],{}).get('role')!='Hidden from choosers']
                from capture_backend import sound_box_name
                from ui_refresh import choices, select_index
                choices(self.hardware_choice,[sound_box_name({**output,'kind':'output'},profiles) for output in self.hardware_outputs])
                desired = self.session.target if self.session.enabled else (self.preferred_output or previous or result["default_output"])
                index = next((i for i, output in enumerate(self.hardware_outputs) if output["name"] == desired), -1 if self.preferred_output or self.session.enabled else 0)
                if self.hardware_outputs and index >= 0:
                    select_index(self.hardware_choice,index)
                else:
                    select_index(self.hardware_choice,-1)
                default = next((output["description"] for output in outputs if output["default"]), None)
                if not result.get("connected", False):
                    self.audio_status.set("PipeWire unavailable • " + result.get("error", "Cannot connect"))
                elif not outputs:
                    self.audio_status.set("PipeWire connected • No output devices available")
                else:
                    self.audio_status.set(f"PipeWire connected • {len(outputs)} output(s) • Default: {default or 'unavailable'}")
            self.refresh_button.configure(state="normal")
            self.apply_button.configure(state="normal" if self.session.enabled else "disabled")
            self.bypass_button.configure(state="normal")
            self.limiter_button.configure(state="normal")
            self.compressor_button.configure(state="normal")
            self.device_button.configure(state="normal" if self.hardware_outputs or self.session.enabled else "disabled",
                                         text="Disable Sound Box" if self.session.enabled else "Enable Sound Box")
            self.hardware_choice.configure(state="disabled" if self.session.enabled else "readonly")
            if self.session.enabled and self.session.state != 'live':
                self.mode.set("RECONNECTING — " + self.session.message)
            else:
                self.mode.set(("BYPASS — Sound Box audio passes through unchanged" if self.devices.bypass else
                               "LIVE — Gain, balance and EQ • OBS captures processed audio") if self.devices.active else
                              "READY — Live gain, balance and EQ available when enabled")
        interval = 1 if self.session.enabled else 3
        if not self.closing and not self.audio_busy and time.monotonic() - self.last_audio_check > interval:
            self.refresh_audio()
        self.root.after(100, self.poll_audio)

    def readout(self, parent, key, unit):
        text = tk.StringVar()
        def update(*_):
            text.set(f"{self.values[key].get():+.1f} {unit}")
        self.values[key].trace_add("write", update)
        update()
        return ttk.Label(parent, textvariable=text, width=12)

    def horizontal(self, parent, title, key, unit):
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=6)
        ttk.Label(row, text=title, width=26).pack(side="left")
        low, high = LIMITS[key]
        ttk.Scale(row, from_=low, to=high, variable=self.values[key]).pack(side="left", fill="x", expand=True, padx=12)
        self.readout(row, key, unit).pack(side="right")

    def reset(self):
        for key, value in self.values.items():
            value.set(DEFAULTS[key])
        self.bypass.set(False)
        self.limiter.set(True)
        self.compressor.set(False)
        self.status.set("Controls reset. Apply controls to update live audio; save to keep these values.")

    def save(self):
        try:
            path = self.path or settings_path()
            values = self.current_controls()
            selected = self.hardware_choice.current()
            if 0 <= selected < len(self.hardware_outputs):
                self.preferred_output = self.hardware_outputs[selected]['name']
            backup = save_settings_bundle(values, self.preferred_output, path)
            self.control_state.mark_saved(values)
            self.control_status.set(self.control_state.describe())
            self.status.set("Settings saved; previous damaged file backed up." if backup else
                            "Settings saved. Apply controls to update live audio.")
            return True
        except (OSError, ValueError) as error:
            messagebox.showerror("Cannot save settings", str(error), parent=self.root)
            return False

    def close(self):
        self.closing = True
        self.mic_panel.closing=True
        self.capture_panel.closing=True
        if self.audio_busy or self.mic_panel.busy or self.capture_panel.busy:
            self.root.after(100, self.close)
            return
        if self.save() and self.mic_panel.save():
            self.mic_panel.close()
            self.capture_panel.close()
            self.session.disable()
            self.root.destroy()
        elif messagebox.askyesno("Close without saving?", "Settings could not be saved. Close anyway?", parent=self.root):
            self.mic_panel.close()
            self.capture_panel.close()
            self.session.disable()
            self.root.destroy()
        else:
            self.closing = False
            self.mic_panel.closing=False
            self.capture_panel.closing=False


def main():
    try:
        root = tk.Tk()
    except tk.TclError as error:
        raise SystemExit(f"Cannot open the interface: {error}. Run from your desktop session.")
    SoundBox(root)
    root.mainloop()


if __name__ == "__main__":
    main()
