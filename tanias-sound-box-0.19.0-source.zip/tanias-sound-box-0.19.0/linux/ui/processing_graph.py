"""PipeWire 1.0-compatible stereo EQ and gain graph."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import math
from pathlib import Path
from controls import BANDS, validate
from audio_backend import PLAYBACK_NAME, MONITOR_NAME, raw_snapshot, AudioError


def control_params(values, bypass=False):
    values=validate(values)
    gain=1.0 if bypass else 10 ** (values['gain']/20)
    balance=0.0 if bypass else values['balance']/100
    params={}
    params.update({'limiter:Enabled': 1.0 if values['limiter'] and not bypass else 0.0,
                   'limiter:Ceiling dB': values['ceiling'], 'limiter:Release ms': values['release']})
    params.update({'compressor:Enabled': 1.0 if values['compressor'] and not bypass else 0.0,
                   'compressor:Threshold dB': values['threshold'], 'compressor:Ratio': values['ratio'],
                   'compressor:Attack ms': values['attack'], 'compressor:Release ms': values['compressor_release'],
                   'compressor:Makeup dB': values['makeup']})
    for channel in ('left', 'right'):
        attenuation=1-max(0,balance) if channel=='left' else 1+min(0,balance)
        params[f'{channel}_gain:Gain 1']=gain*attenuation
        for band in BANDS:
            params[f'{channel}_eq_{band}:Gain']=0 if bypass else values[f'eq_{band}']
    return params


def graph_arguments(values=None):
    values=validate(values or {})
    params=control_params(values, values['bypass'])
    nodes=[]; links=[]; inputs=[]; outputs=[]
    for channel in ('left','right'):
        previous=None
        for band in BANDS:
            name=f'{channel}_eq_{band}'
            nodes.append({'type':'builtin','name':name,'label':'bq_peaking',
                          'control':{'Freq':band,'Q':1.0,'Gain':params[f'{name}:Gain']}})
            if previous: links.append({'output':f'{previous}:Out','input':f'{name}:In'})
            else: inputs.append(f'{name}:In')
            previous=name
        name=f'{channel}_gain'
        nodes.append({'type':'builtin','name':name,'label':'mixer',
                      'control':{'Gain 1':params[f'{name}:Gain 1']}})
        links.append({'output':f'{previous}:Out','input':f'{name}:In 1'})
        links.append({'output':f'{name}:Out','input':f'compressor:{channel.title()} In'})
    nodes.append({'type':'ladspa','name':'compressor','plugin':str(limiter_plugin('tania_compressor.so')),
                  'label':'tania_stereo_compressor', 'control':{key.split(':',1)[1]:value
                  for key,value in params.items() if key.startswith('compressor:')}})
    for channel in ('Left', 'Right'):
        links.append({'output':f'compressor:{channel} Out','input':f'limiter:{channel} In'})
    nodes.append({'type':'ladspa','name':'limiter','plugin':str(limiter_plugin()),
                  'label':'tania_stereo_limiter', 'control':{
                      'Enabled':params['limiter:Enabled'], 'Ceiling dB':values['ceiling'],
                      'Release ms':values['release']}})
    outputs=['limiter:Left Out','limiter:Right Out']
    common={'audio.position':['FL','FR'],'audio.channels':2,'audio.rate':48000,
            'node.virtual':True,'priority.session':1}
    return {'node.description':"Tania's Sound Box Processing", 'audio.rate':48000,
            'filter.graph':{'nodes':nodes,'links':links,'inputs':inputs,'outputs':outputs},
            'capture.props':{**common,'node.name':PLAYBACK_NAME,
                             'tania.processing':True,
                             'node.description':"Tania's Sound Box",'media.class':'Audio/Sink'},
            'playback.props':{**common,'node.name':MONITOR_NAME,
                              'node.description':"Tania's Sound Box - Recording Monitor",
                              'media.class':'Audio/Source'}}


def limiter_plugin(filename='tania_limiter.so'):
    directory=Path(__file__).resolve().parent
    candidates=(directory/filename,
                directory.parents[1]/'lib/tanias-sound-box'/filename,
                directory.parents[1]/'build'/filename)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise AudioError(f'Native dynamics plugin {filename} is missing. Rebuild or reinstall Sound Box.')


def graph_configuration(values=None):
    return configuration_for(graph_arguments(values))


def configuration_for(arguments):
    # Match Mint's filter-chain client configuration. Do not start a second
    # sound server or pass the large graph through pw-cli's argument buffer.
    sections = {
        'context.properties': {'core.daemon': False, 'log.level': 2},
        'context.spa-libs': {'audio.convert.*': 'audioconvert/libspa-audioconvert',
                             'support.*': 'support/libspa-support'},
        'context.modules': [
            {'name': 'libpipewire-module-rt', 'flags': ['ifexists', 'nofail']},
            {'name': 'libpipewire-module-protocol-native'},
            {'name': 'libpipewire-module-client-node'},
            {'name': 'libpipewire-module-adapter'},
            {'name': 'libpipewire-module-filter-chain', 'args': arguments}]
    }
    def spa(value):
        if isinstance(value, dict):
            return '{ ' + ' '.join(json.dumps(key) + ' = ' + spa(item)
                                  for key, item in value.items()) + ' }'
        if isinstance(value, list):
            return '[ ' + ' '.join(spa(item) for item in value) + ' ]'
        return json.dumps(value)
    return '\n'.join(key + ' = ' + spa(value) for key, value in sections.items()) + '\n'


def graph_command(config_path):
    return ['pipewire', '-c', str(config_path)]


def processing_node(objects):
    return next((obj for obj in objects if obj.get('type') == 'PipeWire:Interface:Node'
                 and obj.get('info', {}).get('props', {}).get('node.name') == PLAYBACK_NAME), None)


def named_node(objects, name):
    return next((obj for obj in objects if obj.get('type')=='PipeWire:Interface:Node'
                 and (obj.get('info') or {}).get('props', {}).get('node.name')==name),None)


def node_controls(node):
    controls = {}
    for props in node.get('info', {}).get('params', {}).get('Props', []):
        params = props.get('params', [])
        controls.update(zip(params[::2], params[1::2]))
    return controls


def transition_params(actual, target, steps=8):
    """Small parameter steps; this is control-rate smoothing, not sample ramps."""
    changes=[]
    for step in range(1, steps+1):
        fraction=step/steps
        params={key: actual[key]+(value-actual[key])*fraction for key,value in target.items()}
        # Enable protection before boosts; disable it only at the final step.
        for key in target:
            if key.endswith('Enabled') and key!='limiter:Enabled':
                params[key]=target[key] if step==steps else actual[key]
        params['limiter:Enabled']=target['limiter:Enabled'] if target['limiter:Enabled'] else (
            actual['limiter:Enabled'] if step<steps else 0.0)
        if step==steps:
            params=dict(target)
        changes.append(params)
    return changes


def parameter_batches(params):
    # Mint pw-cli's SPA POD builder cannot fit the whole stereo control set.
    # Limit each batch by control count as well as keeping argument text small.
    items=list(params.items())
    return [dict(items[index:index+8]) for index in range(0,len(items),8)]


def apply_controls(values, bypass=False):
    import subprocess
    import time
    apply_parameters(PLAYBACK_NAME, control_params(values, bypass))


def apply_parameters(name, params, steps=8):
    import subprocess
    import time
    node = named_node(raw_snapshot(), name)
    if node is None or not set(params).issubset(node_controls(node)):
        raise AudioError('The live Sound Box processing graph is unavailable.')
    actual=node_controls(node)
    if any(not isinstance(actual[key],(float,int)) or not math.isfinite(actual[key]) for key in params):
        raise AudioError('The live graph returned invalid control values.')
    if all(math.isclose(actual[key],value,abs_tol=1e-5,rel_tol=1e-5) for key,value in params.items()):
        return
    deadline=time.monotonic()+20
    for intermediate in transition_params(actual,params,steps):
        # PipeWire advertises LADSPA toggled ports as Bool, even though the
        # plugin's control buffer uses floats. A wrong type aborts the batch.
        wire_params={key: bool(value) if key.endswith('Enabled') else value
                     for key,value in intermediate.items()}
        for batch in parameter_batches(wire_params):
            remaining=deadline-time.monotonic()
            if remaining<=0:
                raise AudioError('Timed out applying controls; session recovery will retry the complete set.')
            flat = [item for pair in batch.items() for item in pair]
            try:
                result = subprocess.run(['pw-cli', 'set-param', str(node['id']), 'Props',
                                         json.dumps({'params': flat})], capture_output=True,
                                        text=True, timeout=min(4,remaining))
            except (OSError, subprocess.TimeoutExpired) as error:
                raise AudioError(f'Cannot apply live controls: {error}') from error
            if result.returncode:
                raise AudioError('PipeWire rejected the live controls: ' + result.stderr.strip()[:300])
        time.sleep(.012)
    for _ in range(6):
        current = named_node(raw_snapshot(), name)
        actual = node_controls(current) if current else {}
        if all(key in actual and math.isclose(actual[key], value, abs_tol=1e-5, rel_tol=1e-5)
               for key, value in params.items()):
            return
        time.sleep(.05)
    raise AudioError('PipeWire did not confirm the requested control values.')
