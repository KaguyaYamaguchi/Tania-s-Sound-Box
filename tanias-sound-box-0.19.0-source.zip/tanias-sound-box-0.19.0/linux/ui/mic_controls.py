"""Independent microphone controls and settings, with explicit enable on launch."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import math
from controls import LIMITS as SOUND_LIMITS, DEFAULTS as SOUND_DEFAULTS, validate as sound_validate, settings_path, atomic_write

MIC_NAME = 'tanias_sound_box.microphone'
MIC_CAPTURE = 'tanias_sound_box.microphone_capture'
MIC_LABEL = "Tania's Sound Box - Microphone"
MODES = ('Mono mix', 'Left channel', 'Right channel', 'Stereo')
LIMITS = {**SOUND_LIMITS, 'highpass': (20, 300), 'gate_threshold': (-80, 0),
          'gate_attack': (1, 100), 'gate_hold': (0, 1000), 'gate_release': (10, 2000),
          'gate_range': (-80, 0), 'deess_threshold': (-60, 0), 'deess_ratio': (1, 20),
          'deess_frequency': (3000, 10000)}
DEFAULTS = {**SOUND_DEFAULTS, 'gain': 0, 'highpass': 80, 'gate_threshold': -45,
            'gate_attack': 5, 'gate_hold': 150, 'gate_release': 150, 'gate_range': -60,
            'deess_threshold': -24, 'deess_ratio': 4, 'deess_frequency': 6000}
BOOL_DEFAULTS = {'bypass': False, 'limiter': True, 'compressor': False, 'muted': False,
                 'highpass_enabled': True, 'gate_enabled': False, 'deess_enabled': False}


def validate(data):
    if not isinstance(data, dict):
        raise ValueError('Microphone controls must contain an object.')
    result = sound_validate(data)
    for key, (low, high) in LIMITS.items():
        value = data.get(key, DEFAULTS[key])
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not low <= value <= high:
            raise ValueError(f'Unsupported microphone value: {key}.')
        result[key] = float(value)
    for key, default in BOOL_DEFAULTS.items():
        result[key] = data.get(key, default)
        if not isinstance(result[key], bool):
            raise ValueError(f'{key} must be true or false.')
    mode = data.get('mode', 'Mono mix')
    if mode not in MODES:
        raise ValueError('Unsupported microphone channel mode.')
    result['mode'] = mode
    return result


def device_name(name):
    if name is not None and (not isinstance(name, str) or not name or len(name)>512 or any(ord(c)<32 for c in name)):
        raise ValueError('Invalid microphone device name.')
    return name


def load(path=None):
    path = path or settings_path().with_name('microphone.json')
    if not path.exists():
        return validate({}), None
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or type(data.get('schema')) is not int or data['schema'] != 1:
        raise ValueError('Unsupported microphone settings format; original preserved.')
    return validate(data.get('controls')), device_name(data.get('input'))


def save(values, source, path=None):
    path = path or settings_path().with_name('microphone.json')
    # Unreadable or future settings require recovery outside this write path.
    if path.exists(): load(path)
    atomic_write(path, {'schema': 1, 'controls': validate(values), 'input': device_name(source)})
