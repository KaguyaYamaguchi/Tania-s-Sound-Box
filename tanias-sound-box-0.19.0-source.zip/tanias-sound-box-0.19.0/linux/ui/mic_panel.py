"""Microphone configurator tab: explicit capture, independent settings and tests."""
# SPDX-License-Identifier: AGPL-3.0-or-later
from pathlib import Path
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
from audio_backend import AudioError
from controls import BANDS
from mic_controls import LIMITS, BOOL_DEFAULTS, MODES, MIC_NAME, MIC_LABEL, validate, load, save
from mic_graph import eligible
import capture_backend as capture
from ui_refresh import choices, select_index
from ui_design import PALETTE, card, pages
from mic_session import MicrophoneSession
from mic_test import LevelMeter, MicRecording
from mic_presets import MicPresets


class MicrophonePanel:
    def __init__(self, root, parent, profiles):
        self.root=root;self.profiles=profiles;self.session=MicrophoneSession()
        self.meter=LevelMeter();self.recording=MicRecording();self.presets=MicPresets()
        self.busy=False;self.closing=False;self.results=queue.Queue();self.last_check=0
        self.inputs=[];self.outputs=[];self.selected_source=None;self.saved_values=None;self.last_snapshot=None
        self.status=tk.StringVar(value='Choose an input. Enable microphone to expose processed audio to OBS.')
        try:
            values,self.selected_source=load()
            from controls import settings_path
            if settings_path().with_name('microphone.json').exists(): self.saved_values=dict(values)
        except (OSError,ValueError) as error:
            values=validate({});self.status.set('Microphone settings unavailable: '+str(error))
        self.values={k:tk.DoubleVar(value=values[k]) for k in LIMITS}
        self.flags={k:tk.BooleanVar(value=values[k]) for k in BOOL_DEFAULTS}
        self.mode=tk.StringVar(value=values['mode'])
        self.state_text=tk.StringVar(value='Microphone disabled • monitoring off')
        self.target_text=tk.StringVar(value='Controls target: choose an input.')
        self.control_text=tk.StringVar(value='')
        self.level_text=tk.StringVar(value='Meter off — no microphone samples being read')
        self.level_value=tk.DoubleVar(value=0)
        self.test_point=tk.StringVar(value='Processed microphone')
        container=ttk.Frame(parent);container.pack(fill='both',expand=True)
        self.canvas=tk.Canvas(container,background=PALETTE['background'],highlightthickness=0)
        scroll=ttk.Scrollbar(container,orient='vertical',command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scroll.set);scroll.pack(side='right',fill='y');self.canvas.pack(side='left',fill='both',expand=True)
        panel=ttk.Frame(self.canvas,padding=24);window=self.canvas.create_window((0,0),window=panel,anchor='nw')
        panel.bind('<Configure>',lambda _:self.canvas.configure(scrollregion=self.canvas.bbox('all')))
        self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(window,width=e.width))
        ttk.Label(panel,text='Mic configurator',style='Title.TLabel').pack(anchor='w')
        ttk.Label(panel,text='OBS / capture source: '+MIC_LABEL,style='Muted.TLabel').pack(anchor='w',pady=(4,12))
        ttk.Label(panel,textvariable=self.state_text,foreground=PALETTE['accent'],wraplength=850).pack(anchor='w')
        route_card=card(panel,'01  /  MICROPHONE ROUTING')
        row=ttk.Frame(route_card);row.pack(fill='x',pady=12)
        ttk.Label(row,text='Microphone input:').pack(side='left')
        self.choice=ttk.Combobox(row,state='readonly',width=40);self.choice.pack(side='left',fill='x',expand=True,padx=8)
        self.choice.bind('<<ComboboxSelected>>',self.remember_source)
        self.enable_button=ttk.Button(row,text='Enable microphone',command=self.toggle);self.enable_button.pack(side='right')
        ttk.Label(route_card,textvariable=self.target_text,style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=(0,8))
        ttk.Label(route_card,text='Wired headsets may share the laptop audio device. Choose the headset/mic hardware port in Capture Point. WO Mic appears when its Linux audio source is connected.',style='Muted.TLabel',wraplength=850).pack(anchor='w')
        actions=ttk.Frame(panel);actions.pack(fill='x',pady=(0,10))
        self.buttons=[]
        for text,command in (('Apply mic controls',self.apply),('Mute / unmute now',self.mute),('Save mic settings',self.save),('Reset mic',self.reset)):
            button=ttk.Button(actions,text=text,command=command,style='Accent.TButton' if text=='Apply mic controls' else 'TButton');button.pack(side='left',padx=(0,6));self.buttons.append(button)
        ttk.Label(panel,textvariable=self.control_text,style='Muted.TLabel').pack(anchor='w')
        self.effects_notebook,(tone_page,cleanup_page,dynamics_page,test_page)=pages(panel,('Input & EQ','Voice cleanup','Dynamics','Test & listen'))
        input_card=card(tone_page,'Input shaping')
        eq_card=card(tone_page,'Nine-band microphone EQ')
        highpass_card=card(cleanup_page,'Rumble filter')
        gate_card=card(cleanup_page,'Noise gate')
        deess_card=card(cleanup_page,'De-esser')
        compressor_card=card(dynamics_page,'Voice compressor')
        limiter_card=card(dynamics_page,'Capture limiter')
        ttk.Label(test_page,text='Mic tests',font=('Sans',15,'bold')).pack(anchor='w',pady=(16,8))
        tests=ttk.Frame(test_page);tests.pack(fill='x')
        ttk.Combobox(tests,state='readonly',textvariable=self.test_point,values=('Processed microphone','Raw selected input'),width=24).pack(side='left',padx=(0,6))
        self.meter_button=ttk.Button(tests,text='Start meter',command=self.toggle_meter);self.meter_button.pack(side='left',padx=3)
        for text,command in (('Record test (5s)',self.record),('Room noise (3s)',self.calibrate)):
            button=ttk.Button(tests,text=text,command=command);button.pack(side='left',padx=3);self.buttons.append(button)
        ttk.Progressbar(test_page,variable=self.level_value,maximum=60).pack(fill='x',pady=8)
        ttk.Label(test_page,textvariable=self.level_text,style='Muted.TLabel').pack(anchor='w')
        monitor=ttk.Frame(test_page);monitor.pack(fill='x',pady=(10,4))
        ttk.Label(monitor,text='Listen / monitoring output:').pack(side='left')
        self.output_choice=ttk.Combobox(monitor,state='readonly',width=30);self.output_choice.pack(side='left',fill='x',expand=True,padx=8)
        self.monitor_button=ttk.Button(monitor,text='Start monitoring',command=self.monitor);self.monitor_button.pack(side='right')
        play=ttk.Frame(test_page);play.pack(fill='x',pady=4)
        for text,command in (('Play recorded test',self.play),('Export test WAV…',self.export_test)):
            button=ttk.Button(play,text=text,command=command);button.pack(side='left',padx=(0,6));self.buttons.append(button)
        ttk.Label(test_page,text='Use headphones for monitoring. Tests capture only after you press a test button.',style='Muted.TLabel',wraplength=850).pack(anchor='w',pady=(4,10))
        channel=ttk.Frame(input_card);channel.pack(fill='x',pady=6)
        ttk.Label(channel,text='Input channel mode',width=27).pack(side='left')
        ttk.Combobox(channel,state='readonly',textvariable=self.mode,values=MODES,width=22).pack(side='left')
        for title,key,unit in (('Mic gain','gain','dB'),('Balance','balance','%')):self.slider(input_card,title,key,unit)
        self.check(input_card,'Bypass processing (mute still wins)','bypass')
        self.check(input_card,'Mute microphone (apply to change)','muted')
        self.check(highpass_card,'High-pass / low rumble filter','highpass_enabled');self.slider(highpass_card,'High-pass cutoff','highpass','Hz')
        self.check(gate_card,'Noise gate','gate_enabled')
        ttk.Label(gate_card,text='The gate attenuates quiet gaps; it does not remove background noise during speech.',style='Muted.TLabel',wraplength=850).pack(anchor='w')
        for title,key,unit in (('Gate threshold','gate_threshold','dBFS'),('Gate attack','gate_attack','ms'),('Gate hold','gate_hold','ms'),('Gate release','gate_release','ms'),('Closed-gate attenuation','gate_range','dB')):self.slider(gate_card,title,key,unit)
        self.check(deess_card,'De-esser / harsh sibilance control','deess_enabled')
        for title,key,unit in (('De-esser frequency','deess_frequency','Hz'),('De-esser threshold','deess_threshold','dBFS'),('De-esser ratio','deess_ratio',':1')):self.slider(deess_card,title,key,unit)
        self.check(compressor_card,'Voice compressor','compressor')
        for title,key,unit in (('Compressor threshold','threshold','dBFS'),('Compression ratio','ratio',':1'),('Compressor attack','attack','ms'),('Compressor release','compressor_release','ms'),('Makeup gain','makeup','dB')):self.slider(compressor_card,title,key,unit)
        self.check(limiter_card,'Capture output limiter','limiter')
        self.slider(limiter_card,'Limiter ceiling','ceiling','dBFS');self.slider(limiter_card,'Limiter release','release','ms')
        equalizer=ttk.Frame(eq_card);equalizer.pack(fill='x')
        for index,band in enumerate(BANDS):
            equalizer.columnconfigure(index,weight=1)
            column=ttk.Frame(equalizer);column.grid(row=0,column=index,sticky='nsew',padx=4)
            key=f'eq_{band}'
            ttk.Label(column,text=f'{band//1000}k Hz' if band>=1000 else f'{band} Hz').pack()
            ttk.Scale(column,from_=12,to=-12,orient='vertical',length=150,variable=self.values[key]).pack(pady=10)
            readout=tk.StringVar(value=f'{self.values[key].get():+.1f}')
            self.values[key].trace_add('write',lambda *_,k=key,v=readout:v.set(f'{self.values[k].get():+.1f}'))
            ttk.Label(column,textvariable=readout).pack()
        presets=card(panel,'MICROPHONE PRESETS')
        self.preset_choice=ttk.Combobox(presets,state='readonly',width=20);self.preset_choice.pack(side='left',padx=(0,5))
        for text,command in (('Load',self.load_preset),('Save as…',self.save_preset),('Import…',self.import_preset),('Export…',self.export_preset)):
            ttk.Button(presets,text=text,command=command).pack(side='left',padx=3)
        self.refresh_presets()
        ttk.Label(panel,textvariable=self.status,style='Muted.TLabel',wraplength=850).pack(anchor='w')
        for v in (*self.values.values(),*self.flags.values(),self.mode):v.trace_add('write',self.changed)
        self.changed();self.task(self.session.poll);root.after(100,self.poll)

    def current(self):return validate({**{k:v.get() for k,v in self.values.items()},**{k:v.get() for k,v in self.flags.items()},'mode':self.mode.get()})
    def changed(self,*_):
        values=self.current();actual=self.session.confirmed
        processing=('Processing disabled' if not self.session.enabled else ('Controls match processing' if values==actual else 'Changes not applied / queued'))
        self.control_text.set(processing+' • '+('Settings saved' if values==self.saved_values else 'Changes not saved'))
    def slider(self,parent,title,key,unit):
        row=ttk.Frame(parent);row.pack(fill='x',pady=4)
        ttk.Label(row,text=title,width=27).pack(side='left');low,high=LIMITS[key]
        ttk.Scale(row,from_=low,to=high,variable=self.values[key]).pack(side='left',fill='x',expand=True,padx=8)
        text=tk.StringVar();self.values[key].trace_add('write',lambda *_:text.set(f'{self.values[key].get():.1f} {unit}'))
        text.set(f'{self.values[key].get():.1f} {unit}');ttk.Label(row,textvariable=text,width=14).pack(side='right')
    def check(self,parent,title,key):ttk.Checkbutton(parent,text=title,variable=self.flags[key]).pack(anchor='w',pady=(10,3))
    def task(self,work,note=None,background=False):
        if self.busy or self.closing:return
        self.busy=True;self.last_check=time.monotonic();self.set_busy(True) if not background else None
        if note:self.status.set(note)
        def run():
            try:
                result=work()
                if isinstance(result,dict) and 'microphone' in result:
                    for kind,key,pool in (('input','inputs','sources'),('output','outputs','sinks')):
                        try:
                            pulse={d['name']:d for d in capture.call(['list',pool],True)}
                            result[key]=[{**d,'kind':kind,'ports':pulse.get(d['name'],{}).get('ports',[]),'active_port':pulse.get(d['name'],{}).get('active_port')} for d in result[key]]
                        except AudioError: pass
                self.results.put((True,result))
            except (AudioError,OSError,ValueError) as error:self.results.put((False,str(error)))
        threading.Thread(target=run,daemon=True).start()
    def set_busy(self,busy):
        for b in (*self.buttons,self.enable_button,self.meter_button,self.monitor_button):b.configure(state='disabled' if busy else 'normal')
        self.choice.configure(state='disabled' if busy or self.session.enabled else 'readonly')
    def remember_source(self,*_):
        index=self.choice.current()
        if 0<=index<len(self.inputs):self.selected_source=self.inputs[index]['name']
        self.update_target()
    def update_target(self):
        source=self.session.source if self.session.enabled else self.selected_source
        device=next((d for d in self.inputs if d['name']==source),None)
        if device:
            name=capture.sound_box_name(device,self.profiles.all())
            state='Processing' if self.session.enabled else 'Selected (processing disabled)'
            port=capture.port_description(device) or 'not reported'
            self.target_text.set(f'{state}: {name} → {MIC_LABEL}\nSystem input: {source} • Port: {port}')
        else:self.target_text.set('Controls target: selected input unavailable.' if source else 'Controls target: choose an input.')

    def select_source(self,name):
        if self.session.enabled:self.status.set('Disable the microphone before changing its input.');return
        self.selected_source=name
        index=next((i for i,d in enumerate(self.inputs) if d['name']==name),-1)
        select_index(self.choice,index);self.status.set('Selected input is unavailable or assigned to another capture job.')
        self.update_target()
    def toggle(self):
        if self.session.enabled:self.meter.stop();self.task(self.session.disable)
        else:
            self.remember_source()
            if not self.selected_source:self.status.set('Choose a microphone input first.');return
            source=self.selected_source;values=self.current();self.task(lambda:self.session.enable(source,values),'Enabling selected microphone…')
    def apply(self):
        if not self.session.enabled:self.status.set('Enable microphone to apply these controls.');return
        values=self.current();self.task(lambda:self.session.apply(values))
    def mute(self):
        if not self.session.enabled:self.flags['muted'].set(not self.flags['muted'].get());return
        muted=not self.session.controls['muted'];self.flags['muted'].set(muted);self.task(lambda:self.session.mute(muted))
    def test_source(self):
        if self.test_point.get()=='Processed microphone':
            if not self.session.enabled or self.session.state!='live':raise AudioError('Enable the microphone and wait for its route before testing processed audio.')
            return MIC_NAME
        self.remember_source()
        if not self.selected_source:raise AudioError('Choose a raw microphone input first.')
        if self.selected_source not in {d['name'] for d in self.inputs}:raise AudioError('Raw input was disconnected.')
        return self.selected_source
    def toggle_meter(self):
        if self.meter.target:self.meter.stop();self.meter_button.configure(text='Start meter');self.level_text.set('Meter off — no samples being read');return
        try:self.meter.start(self.test_source());self.meter_button.configure(text='Stop meter')
        except (AudioError,OSError,ValueError) as e:self.status.set(str(e))
    def record(self):
        try:source=self.test_source()
        except AudioError as e:self.status.set(str(e));return
        self.task(lambda:{'test':self.recording.record(source)},'Recording microphone test for 5 seconds…')
    def calibrate(self):
        self.remember_source()
        if self.selected_source not in {d['name'] for d in self.inputs}:self.status.set('Choose an available raw input first.');return
        source=self.selected_source
        def measure():
            recording=MicRecording()
            try:return {'noise':recording.record(source,seconds=3)}
            finally:recording.close()
        self.task(measure,'Measuring raw room noise for 3 seconds. Stay quiet…')
    def output(self):
        index=self.output_choice.current()
        if not 0<=index<len(self.outputs):raise AudioError('Choose an available monitoring/playback output.')
        return self.outputs[index]['name']
    def monitor(self):
        try:target=None if self.session.monitor_target else self.output()
        except AudioError as e:self.status.set(str(e));return
        self.task(lambda:self.session.monitor(target))
    def play(self):
        try:target=self.output()
        except AudioError as e:self.status.set(str(e));return
        self.task(lambda:(self.recording.play(target) or {'played':True}),'Playing recorded test…')
    def export_test(self):
        filename=filedialog.asksaveasfilename(parent=self.root,defaultextension='.wav',initialfile='microphone-test.wav',filetypes=[('WAV audio','*.wav')])
        if not filename:return
        try:self.recording.export(Path(filename));self.status.set('Microphone test exported.')
        except (AudioError,OSError) as e:self.status.set(str(e))
    def save(self):
        try:
            self.remember_source();values=self.current();save(values,self.selected_source);self.saved_values=dict(values)
            self.changed();self.status.set('Microphone settings saved. Apply updates live processing.');return True
        except (OSError,ValueError) as e:messagebox.showerror('Cannot save microphone settings',str(e),parent=self.root);return False
    def set_values(self,values):
        values=validate(values)
        for k,v in self.values.items():v.set(values[k])
        for k,v in self.flags.items():v.set(values[k])
        self.mode.set(values['mode']);self.changed()
    def reset(self):self.set_values({});self.status.set('Microphone reset. Apply to update live audio.')
    def refresh_presets(self,name=None):
        try:self.preset_choice.configure(values=list(self.presets.all()));self.preset_choice.set(name or 'Natural voice')
        except (OSError,ValueError) as e:self.status.set(str(e))
    def load_preset(self):
        try:self.set_values(self.presets.all()[self.preset_choice.get()]);self.status.set('Microphone preset loaded. Apply to update live audio.')
        except (OSError,ValueError,KeyError) as e:self.status.set(str(e))
    def save_preset(self):
        name=simpledialog.askstring('Save microphone preset','Custom preset name:',parent=self.root)
        if name is None:return
        try:
            if name.strip() in self.presets.custom() and not messagebox.askyesno('Replace preset?','Replace the existing microphone preset?',parent=self.root):return
            self.presets.save(name,self.current());self.refresh_presets(name.strip())
        except (OSError,ValueError) as e:self.status.set(str(e))
    def import_preset(self):
        filename=filedialog.askopenfilename(parent=self.root,filetypes=[('Microphone preset','*.json')])
        if not filename:return
        try:
            name,values=self.presets.decode(Path(filename))
            if name in self.presets.custom() and not messagebox.askyesno('Replace preset?','Replace the existing microphone preset?',parent=self.root):return
            self.presets.save(name,values);self.refresh_presets(name);self.status.set('Microphone preset imported. Load it to stage controls.')
        except (OSError,ValueError) as e:self.status.set(str(e))
    def export_preset(self):
        filename=filedialog.asksaveasfilename(parent=self.root,defaultextension='.json',filetypes=[('Microphone preset','*.json')])
        if not filename:return
        try:self.presets.export(Path(filename),self.preset_choice.get() or 'Custom mic',self.current());self.status.set('Microphone preset exported.')
        except (OSError,ValueError) as e:self.status.set(str(e))
    def render(self,result):
        self.last_snapshot=result;mic=result['microphone'];self.state_text.set(mic['state'].upper()+' — '+mic['message'])
        self.enable_button.configure(text='Disable microphone' if mic['enabled'] else 'Enable microphone')
        self.monitor_button.configure(text='Stop monitoring' if mic['monitor_target'] else 'Start monitoring')
        old_output=self.outputs[self.output_choice.current()]['name'] if 0<=self.output_choice.current()<len(self.outputs) else None
        profiles=self.profiles.all()
        self.inputs=[d for d in result['inputs'] if eligible(d) and (capture.microphone_allowed(d,profiles) or (self.session.enabled and d['name']==self.session.source))]
        self.outputs=[d for d in result['outputs'] if d['role']=='hardware_output' and profiles.get('output:'+d['name'],{}).get('role')!='Hidden from choosers']
        choices(self.choice,[capture.sound_box_name(d,profiles) for d in self.inputs])
        selected=self.session.source if self.session.enabled else self.selected_source
        if not selected:selected=next((d['name'] for d in self.inputs if d.get('default')),self.inputs[0]['name'] if self.inputs else None)
        self.selected_source=selected
        index=next((i for i,d in enumerate(self.inputs) if d['name']==selected),-1)
        select_index(self.choice,index)
        choices(self.output_choice,[capture.sound_box_name(d,profiles) for d in self.outputs])
        target=self.session.monitor_target or old_output or next((d['name'] for d in self.outputs if d.get('default')),None)
        index=next((i for i,d in enumerate(self.outputs) if d['name']==target),0 if not old_output and not self.session.monitor_target and self.outputs else -1)
        select_index(self.output_choice,index)
        self.update_target()
        available={d['name'] for d in result['inputs']}
        if self.meter.target and self.meter.target not in available:self.meter.stop();self.meter_button.configure(text='Start meter');self.level_text.set('Meter stopped: selected source disappeared.')
        self.changed()
    def poll(self):
        try:ok,result=self.results.get_nowait()
        except queue.Empty:pass
        else:
            self.busy=False;self.set_busy(False)
            if not ok:self.status.set(result)
            elif 'microphone' in result:
                try:self.render(result)
                except (OSError,ValueError) as e:self.status.set('Device profiles unavailable: '+str(e))
            elif 'test' in result:
                stats=result['test'];self.status.set(f"Test recorded: {stats['seconds']:.1f}s • Peak {stats['peak_db']:.1f} dBFS • RMS {stats['rms_db']:.1f} dBFS • {stats['clipped_samples']} clipped samples")
            elif 'noise' in result:
                rms=result['noise']['rms_db']
                if rms>-20:self.status.set('Room sample was too loud for gate calibration. Stay quiet and try again.')
                else:self.values['gate_threshold'].set(min(-10,max(-70,rms+10)));self.flags['gate_enabled'].set(True);self.status.set(f'Noise floor {rms:.1f} dBFS. Gate threshold staged 10 dB above it; Apply to use.')
            elif 'played' in result:self.status.set('Recorded test playback completed.')
        stats=self.meter.latest()
        if stats:
            self.level_value.set(max(0,min(60,stats['peak_db']+60)))
            self.level_text.set(f"Peak {stats['peak_db']:.1f} dBFS • RMS {stats['rms_db']:.1f} dBFS • Clipped samples: {stats['clipped_samples']}")
        elif self.meter.error:self.level_text.set(self.meter.error)
        if not self.closing and not self.busy and time.monotonic()-self.last_check>(1 if self.session.enabled else 3):self.task(self.session.poll,background=True)
        self.root.after(100,self.poll)
    def close(self):
        self.closing=True;self.meter.stop();self.recording.close();self.session.disable()
