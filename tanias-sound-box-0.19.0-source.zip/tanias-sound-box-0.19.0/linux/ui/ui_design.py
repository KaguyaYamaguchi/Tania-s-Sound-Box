"""Shared desktop presentation; palette is kept here for later changes."""
import tkinter as tk
from tkinter import ttk

PALETTE={'background':'#151d2b','panel':'#1c2738','field':'#101824',
         'text':'#e8edf5','muted':'#aab9cc','accent':'#ffc66d','border':'#304056'}


def theme(root):
    p=PALETTE;style=ttk.Style(root);style.theme_use('clam')
    root.configure(background=p['background'])
    root.option_add('*TCombobox*Listbox.background',p['field'])
    root.option_add('*TCombobox*Listbox.foreground',p['text'])
    root.option_add('*TCombobox*Listbox.selectBackground',p['border'])
    style.configure('.',background=p['background'],foreground=p['text'],font=('DejaVu Sans',10))
    style.configure('TFrame',background=p['background'])
    style.configure('TLabel',background=p['background'],foreground=p['text'])
    style.configure('Title.TLabel',font=('DejaVu Sans',23,'bold'))
    style.configure('Muted.TLabel',foreground=p['muted'])
    style.configure('Brand.TLabel',font=('DejaVu Sans',14,'bold'))
    style.configure('TButton',padding=(12,8),background=p['panel'],borderwidth=1,relief='flat')
    style.map('TButton',background=[('active',p['border'])],foreground=[('disabled','#66768b')])
    style.configure('Accent.TButton',background=p['accent'],foreground=p['field'])
    style.map('Accent.TButton',background=[('active','#ffda9c'),('disabled',p['panel'])],foreground=[('disabled','#66768b')])
    style.configure('Nav.TRadiobutton',padding=(14,14),indicatoron=False,font=('DejaVu Sans',11,'bold'))
    style.layout('Nav.TRadiobutton',[('Radiobutton.padding',{'children':[('Radiobutton.label',{'sticky':'nswe'})],'sticky':'nswe'})])
    style.map('Nav.TRadiobutton',background=[('selected',p['panel']),('active',p['border'])],foreground=[('selected',p['accent'])])
    style.configure('TNotebook',bordercolor=p['border'],lightcolor=p['border'],darkcolor=p['border'],borderwidth=0,tabmargins=(0,8,0,0))
    style.configure('TNotebook.Tab',padding=(14,10),background=p['panel'])
    style.map('TNotebook.Tab',background=[('selected',p['border'])],foreground=[('selected',p['accent'])])
    style.layout('Workspace.TNotebook.Tab',[])
    style.configure('TEntry',fieldbackground=p['field'],insertcolor=p['text'],padding=7)
    style.configure('TCombobox',fieldbackground=p['field'],background=p['panel'],arrowcolor=p['accent'],padding=6)
    style.map('TCombobox',fieldbackground=[('readonly',p['field']),('disabled',p['panel'])],foreground=[('readonly',p['text']),('disabled','#66768b')])
    style.configure('TSpinbox',fieldbackground=p['field'],arrowcolor=p['accent'],padding=6)
    style.configure('TCheckbutton',padding=(0,5))
    style.map('TCheckbutton',background=[('active',p['background'])])
    style.configure('Horizontal.TScale',troughcolor=p['field'],background=p['accent'],borderwidth=0)
    style.configure('Vertical.TScale',troughcolor=p['field'],background=p['accent'],borderwidth=0)
    style.configure('Horizontal.TProgressbar',troughcolor=p['field'],background=p['accent'],borderwidth=0)
    style.configure('Treeview',background=p['field'],fieldbackground=p['field'],foreground=p['text'],rowheight=32,borderwidth=0)
    style.map('Treeview',background=[('selected',p['border'])],foreground=[('selected',p['accent'])])
    style.configure('Treeview.Heading',background=p['panel'],foreground=p['muted'],padding=(8,10),relief='flat')
    style.configure('TLabelframe',bordercolor=p['border'],borderwidth=1,relief='solid')
    style.configure('TLabelframe.Label',foreground=p['accent'],font=('DejaVu Sans',11,'bold'))
    style.configure('Horizontal.TScrollbar',troughcolor=p['background'],background=p['border'],arrowcolor=p['muted'],borderwidth=0)
    style.configure('Vertical.TScrollbar',troughcolor=p['background'],background=p['border'],arrowcolor=p['muted'],borderwidth=0)


def card(parent,title):
    frame=ttk.LabelFrame(parent,text=title,padding=16)
    frame.pack(fill='x',pady=(12,0))
    return frame


def pages(parent, names):
    notebook=ttk.Notebook(parent);notebook.pack(fill='both',expand=True,pady=(12,8))
    result=[]
    for name in names:
        frame=ttk.Frame(notebook,padding=(14,12));notebook.add(frame,text=name);result.append(frame)
    return notebook,result


def table_scroll(parent,tree):
    bar=ttk.Scrollbar(parent,orient='horizontal',command=tree.xview)
    tree.configure(xscrollcommand=bar.set);bar.pack(fill='x')
