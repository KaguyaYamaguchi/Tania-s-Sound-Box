"""Actionable runtime requirements checked before spawning audio clients."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import os
from pathlib import Path
import shutil
from audio_backend import AudioError
from processing_graph import limiter_plugin


def runtime_errors():
    errors = []
    missing = [name for name in ('pipewire', 'pw-dump', 'pw-cli', 'pw-loopback') if not shutil.which(name)]
    if missing:
        errors.append('Missing audio tools: ' + ', '.join(missing) + '. Install pipewire-bin.')
    runtime = os.environ.get('XDG_RUNTIME_DIR', '')
    if not runtime or not Path(runtime).is_absolute() or not Path(runtime).is_dir():
        errors.append('XDG_RUNTIME_DIR is unavailable. Run from your Linux desktop session.')
    for plugin in ('tania_limiter.so', 'tania_compressor.so', 'tania_mic.so'):
        try:
            limiter_plugin(plugin)
        except AudioError:
            errors.append(f'Bundled plugin {plugin} is missing. Rebuild or reinstall Sound Box.')
    return errors


def check_runtime():
    errors = runtime_errors()
    if errors:
        raise AudioError(' '.join(errors))
