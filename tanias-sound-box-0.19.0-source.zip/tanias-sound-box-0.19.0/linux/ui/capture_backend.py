"""Capture Point: real Pulse-compatible device/stream controls plus local roles."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import json
import math
from audio_backend import snapshot, AudioError
from controls import settings_path, atomic_write

ROLES = ('Unassigned', 'Microphone', 'Auxiliary input', 'Desktop capture', 'Playback output', 'Hidden from choosers')


class DeviceProfiles:
    def __init__(self, path=None):
        self.path = path or settings_path().with_name('capture-point.json')

    def all(self):
        if not self.path.exists(): return {}
        data=json.loads(self.path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or type(data.get('schema')) is not int or data['schema']!=1 or not isinstance(data.get('devices'),dict):
            raise ValueError('Unsupported Capture Point settings format; original preserved.')
        result={}
        for key, value in data['devices'].items():
            if not isinstance(value,dict): raise ValueError('Invalid Capture Point profile.')
            alias=value.get('alias','');role=value.get('role')
            if not isinstance(alias,str) or len(alias)>100 or any(ord(c)<32 for c in alias) or role not in ROLES:
                raise ValueError('Invalid device label or role.')
            result[key]={'alias':alias,'role':role}
        return result

    def save(self, kind, name, alias, role):
        if kind not in ('input','output') or not isinstance(name,str) or not name: raise ValueError('Invalid device identity.')
        if not isinstance(alias,str) or len(alias)>100 or any(ord(c)<32 for c in alias) or role not in ROLES:
            raise ValueError('Choose a printable device label and a valid role.')
        allowed=('Unassigned','Playback output','Hidden from choosers') if kind=='output' else ('Unassigned','Microphone','Auxiliary input','Desktop capture','Hidden from choosers')
        if role not in allowed: raise ValueError('Role does not match the device direction.')
        profiles=self.all();profiles[kind+':'+name]={'alias':alias.strip(),'role':role}
        atomic_write(self.path,{'schema':1,'devices':profiles})

    def visible(self, kind, name):
        return self.all().get(kind+':'+name,{}).get('role')!='Hidden from choosers'


def call(args, json_result=False):
    import subprocess
    try:
        command=['pactl']+(['--format=json'] if json_result else [])+list(args)
        result=subprocess.run(command,capture_output=True,text=True,timeout=4)
    except (OSError,subprocess.TimeoutExpired) as error:
        raise AudioError(f'Capture Point requires a Pulse-compatible server and pulseaudio-utils: {error}') from error
    if result.returncode: raise AudioError('Capture Point: '+(result.stderr.strip()[:300] or 'command failed'))
    if json_result:
        try: return json.loads(result.stdout)
        except ValueError as error: raise AudioError('Capture Point received invalid device data.') from error
    return result.stdout.strip()


def percentage(device):
    channels=device.get('volume',{}).values()
    values=[v['value']/65536*100 for v in channels if isinstance(v,dict) and isinstance(v.get('value'),(int,float))]
    return round(sum(values)/len(values),1) if values else None


def inventory():
    current=snapshot()
    devices={(kind,d['name']):{**d,'kind':kind,'pulse':False,'volume_percent':None,'muted':None}
             for kind, collection in (('output',current['outputs']),('input',current['inputs'])) for d in collection}
    streams=[];cards=[];error=None
    try:
        pulse_outputs=call(['list','sinks'],True);pulse_inputs=call(['list','sources'],True)
        defaults={'output':call(['get-default-sink']),'input':call(['get-default-source'])}
        for kind, collection in (('output',pulse_outputs),('input',pulse_inputs)):
            for d in collection:
                name=d['name'];old=devices.get((kind,name),{})
                devices[(kind,name)]={**old,'kind':kind,'name':name,'description':d.get('description') or name,
                     'state':d.get('state','unknown'),'pulse':True,'volume_percent':percentage(d),'muted':bool(d.get('mute')),
                     'default':defaults[kind]==name,'ports':d.get('ports',[]),'active_port':d.get('active_port'),
                     'format':old.get('format',{})}
        for kind, collection in (('playback',call(['list','sink-inputs'],True)),('capture',call(['list','source-outputs'],True))):
            for d in collection:
                props=d.get('properties') or {}
                internal=(str(props.get('node.name','')).startswith('tanias_sound_box') or
                          str(props.get('application.name','')).startswith(('Tania Sound Box','Tania\'s Sound Box')))
                target_id=d.get('sink') if kind=='playback' else d.get('source')
                pool=pulse_outputs if kind=='playback' else pulse_inputs
                target=next((x['name'] for x in pool if x.get('index')==target_id),None)
                streams.append({'index':d['index'],'kind':kind,'application':props.get('application.name') or 'Unnamed application',
                                'name':props.get('media.name') or '', 'target':target,'internal':internal})
        cards=call(['list','cards'],True)
    except (AudioError,ValueError,TypeError,KeyError) as e:
        error=str(e)
    return {'devices':list(devices.values()),'streams':streams,'cards':cards,'error':error}


def current_device(kind,name):
    if kind not in ('input','output'): raise ValueError('Choose an input or output device.')
    devices=call(['list','sources' if kind=='input' else 'sinks'],True)
    device=next((d for d in devices if d.get('name')==name),None)
    if device is None: raise AudioError('Selected device was disconnected. Refresh Capture Point.')
    return device


def set_device(kind,name,volume,muted):
    if isinstance(volume,bool) or not isinstance(volume,(int,float)) or not math.isfinite(volume) or not 0<=volume<=150:
        raise ValueError('Device volume must be 0–150%.')
    if not isinstance(muted,bool): raise ValueError('Mute must be true or false.')
    old=current_device(kind,name)
    direction='source' if kind=='input' else 'sink'
    try:
        call([f'set-{direction}-volume',name,f'{volume:.2f}%'])
        call([f'set-{direction}-mute',name,'1' if muted else '0'])
        actual=current_device(kind,name)
        if abs((percentage(actual) or 0)-volume)>.2 or bool(actual.get('mute'))!=muted:
            raise AudioError('The server did not confirm the requested volume/mute.')
    except AudioError:
        try:
            # Preserve channel balance when rolling back a partial operation.
            volumes=[str(v['value']) for v in old.get('volume',{}).values()]
            if volumes: call([f'set-{direction}-volume',name,*volumes])
            call([f'set-{direction}-mute',name,'1' if old.get('mute') else '0'])
        except AudioError: pass
        raise


def make_default(kind,name):
    current_device(kind,name)
    direction='source' if kind=='input' else 'sink'
    call([f'set-default-{direction}',name])
    if call([f'get-default-{direction}'])!=name: raise AudioError('The server did not confirm the default device.')


def move_stream(kind,index,device_kind,name):
    if kind not in ('playback','capture') or type(index) is not int: raise ValueError('Choose an active application stream.')
    if device_kind!=('input' if kind=='capture' else 'output'): raise ValueError('Stream and device directions do not match.')
    current_device(device_kind,name)
    pool=call(['list','source-outputs' if kind=='capture' else 'sink-inputs'],True)
    stream=next((s for s in pool if s.get('index')==index),None)
    if stream is None: raise AudioError('Application stream ended. Refresh Capture Point.')
    props=stream.get('properties') or {}
    if str(props.get('node.name','')).startswith('tanias_sound_box') or str(props.get('application.name','')).startswith(('Tania Sound Box','Tania\'s Sound Box')):
        raise AudioError('Use the Sound Box tabs to change its owned processing/test routes.')
    call(['move-source-output' if kind=='capture' else 'move-sink-input',str(index),name])
    actual=call(['list','source-outputs' if kind=='capture' else 'sink-inputs'],True)
    target=current_device(device_kind,name)['index']
    updated=next((s for s in actual if s.get('index')==index),None)
    if updated is None or updated.get('source' if kind=='capture' else 'sink')!=target:
        raise AudioError('The server did not confirm the moved stream.')


def set_port(kind,name,port):
    device=current_device(kind,name)
    ports=device.get('ports',[])
    if isinstance(ports,dict): names=ports
    else: names={p['name'] for p in ports}
    if port not in names: raise ValueError('Choose an available device port.')
    direction='source' if kind=='input' else 'sink'
    call([f'set-{direction}-port',name,port])
    if current_device(kind,name).get('active_port')!=port: raise AudioError('The server did not confirm the selected port.')


def set_profile(name,profile):
    cards=call(['list','cards'],True)
    card=next((c for c in cards if c.get('name')==name),None)
    if card is None: raise AudioError('Selected audio card was disconnected.')
    profiles=card.get('profiles',[])
    names=profiles if isinstance(profiles,dict) else {p['name'] for p in profiles}
    if profile not in names: raise ValueError('Choose an available card profile.')
    call(['set-card-profile',name,profile])
    updated=next((c for c in call(['list','cards'],True) if c.get('name')==name),{})
    active=updated.get('active_profile')
    if isinstance(active,dict): active=active.get('name')
    if active!=profile: raise AudioError('The server did not confirm the card profile.')


def port_description(device):
    active=device.get('active_port')
    if isinstance(active,dict): active=active.get('name')
    ports=device.get('ports') or []
    if isinstance(ports,dict): ports=[dict(value,name=name) for name,value in ports.items()]
    port=next((p for p in ports if p.get('name')==active),{})
    return port.get('description') or active or ''


def sound_box_name(device,profiles):
    profile=profiles.get(device['kind']+':'+device['name'],{})
    if profile.get('alias'): return profile['alias']
    port=port_description(device)
    if port: return port
    description=device.get('description') or device['name']
    lower=description.lower()
    if 'built-in' in lower: return 'Laptop microphone' if device['kind']=='input' else 'Laptop speakers'
    return description


def microphone_allowed(device,profiles):
    role=profiles.get('input:'+device['name'],{}).get('role')
    return role in (None,'Unassigned','Microphone')
