"""Single-owner session recovery; resumes only the explicitly selected output."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import time
from audio_backend import AudioError, snapshot, PLAYBACK_NAME, MONITOR_NAME
from controls import validate
from virtual_devices import VirtualDevices


class AudioSession:
    def __init__(self, devices=None, clock=time.monotonic):
        self.devices = devices or VirtualDevices()
        self.clock = clock
        self.enabled = False
        self.target = None
        self.controls = validate({})
        self.confirmed_controls = None
        self.state = 'disabled'
        self.message = 'Sound Box disabled.'
        self.next_retry = 0
        self.failures = 0
        self.graph_generation = 0
        self.route_repairs = 0

    def describe(self, current):
        current = dict(current)
        current['session'] = {'enabled': self.enabled, 'state': self.state,
                              'hardware_output': self.target, 'message': self.message,
                              'desired_controls': dict(self.controls),
                              'confirmed_controls': dict(self.confirmed_controls) if self.confirmed_controls is not None else None,
                              'graph_generation': self.graph_generation,
                              'route_repairs': self.route_repairs,
                              'retry_in_seconds': max(0, round(self.next_retry - self.clock(), 1))}
        return current

    def enable(self, target, values):
        values = validate(values)
        current = self.devices.start(target, values, values['bypass'])
        self.graph_generation += 1
        self.enabled = True
        self.target = target
        self.controls = values
        self.confirmed_controls = dict(values)
        self.state = 'live'
        self.message = 'Live processing enabled.'
        self.failures = 0
        self.next_retry = 0
        return self.describe(current)

    def disable(self):
        self.enabled = False
        self.devices.stop()
        self.state = 'disabled'
        self.confirmed_controls = None
        self.message = 'Sound Box disabled.'
        self.next_retry = 0
        self.failures = 0

    def apply(self, values):
        if not self.enabled:
            raise AudioError('Enable Sound Box before applying live controls.')
        values = validate(values)
        current = self.read()
        if current['connected'] and not self.devices.graph_active:
            self.confirmed_controls = None
            self.state = 'recovering'
            self.next_retry = 0
        if self.devices.graph_active:
            try:
                self.devices.apply(values, values['bypass'])
                self.confirmed_controls = dict(values)
            except (AudioError, OSError):
                # A client can disappear between polling and applying controls.
                # Rebuild from the complete requested set, avoiding partial state.
                self.devices.stop()
                self.confirmed_controls = None
                self.state = 'recovering'
                self.next_retry = 0
        self.controls = values
        self.message = 'Live controls applied.' if self.state == 'live' else 'Controls queued for reconnection.'
        return self.describe(self.read())

    def read(self):
        try:
            return snapshot()
        except AudioError as error:
            if self.enabled:
                self.devices.stop()
                self.confirmed_controls = None
                self.state = 'waiting_server'
                self.message = 'Waiting for PipeWire: ' + str(error)
            return {'connected': False, 'outputs': [], 'inputs': [], 'default_output': None,
                    'processing': False, 'limiter': None,
                    'routing': {'ready': False, 'monitor_linked': False, 'hardware_linked': False},
                    'error': str(error)}

    def poll(self):
        current = self.read()
        if not self.enabled or not current['connected']:
            return self.describe(current)
        hardware = {output['name'] for output in current['outputs'] if output['role'] == 'hardware_output'}
        graph_visible = (any(o['name'] == PLAYBACK_NAME for o in current['outputs']) and
                         any(i['name'] == MONITOR_NAME for i in current['inputs']))
        if not self.devices.graph_active or not graph_visible:
            self.devices.stop()
            self.confirmed_controls = None
        if self.target not in hardware:
            self.devices.detach_hardware()
            self.state = 'waiting_device'
            self.message = 'Waiting for the selected hardware output; no automatic switch to speakers.'
            current = self.read()
            return self.describe(current)
        if (self.devices.active and current['routing']['ready'] and
                current['routing'].get('hardware_output') == self.target):
            self.state = 'live'
            self.message = 'Live processing connected.'
            self.failures = 0
            self.next_retry = 0
            return self.describe(current)
        if self.clock() < self.next_retry:
            return self.describe(current)
        self.state = 'recovering'
        try:
            if self.devices.graph_active:
                self.devices.detach_hardware()
                self.devices.attach_hardware(self.target)
                self.route_repairs += 1
                current = snapshot()
            else:
                current = self.devices.start(self.target, self.controls, self.controls['bypass'])
                self.graph_generation += 1
                self.confirmed_controls = dict(self.controls)
            self.state = 'live'
            self.message = 'Sound Box reconnected to the selected output.'
            self.failures = 0
            self.next_retry = 0
        except (AudioError, OSError) as error:
            self.devices.detach_hardware()
            self.state = 'recovering'
            self.message = 'Reconnecting: ' + str(error)
            self.failures += 1
            self.next_retry = self.clock() + min(8, 2 ** min(self.failures-1, 3))
        return self.describe(current)
