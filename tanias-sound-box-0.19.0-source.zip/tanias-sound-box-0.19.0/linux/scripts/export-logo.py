"""Export our vector mark's geometry to supersampled PNGs for Tk/Linux icons.
Build-time utility only; requires Pillow. SVG remains the editable source.
"""
from pathlib import Path
from PIL import Image,ImageDraw

assets=Path(__file__).resolve().parents[1]/'assets'
scale=4
im=Image.new('RGBA',(256*scale,256*scale))
draw=ImageDraw.Draw(im)
draw.rounded_rectangle((0,0,256*scale-1,256*scale-1),radius=52*scale,fill='#151d2b')
# Rounded open box; its top opening lets the central waveform emerge.
draw.rounded_rectangle((53*scale,57*scale,203*scale,203*scale),radius=12*scale,outline='#ffc66d',width=12*scale)
draw.rectangle((103*scale,50*scale,153*scale,64*scale),fill='#151d2b')
for x,start,end in ((82,118,142),(105,100,160),(128,50,186),(151,100,160),(174,118,142)):
    draw.line((x*scale,start*scale,x*scale,end*scale),fill='#ffc66d',width=12*scale)
    for y in (start,end):draw.ellipse(((x-6)*scale,(y-6)*scale,(x+6)*scale,(y+6)*scale),fill='#ffc66d')
for size in (32,64,256,512):im.resize((size,size),Image.Resampling.LANCZOS).save(assets/f'icon-{size}.png')
