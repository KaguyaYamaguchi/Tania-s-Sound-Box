#!/bin/sh
# SPDX-License-Identifier: AGPL-3.0-or-later
# Read-only: does not install packages or change audio settings.
set -u
if [ "$(uname -s)" != Linux ]; then
    echo 'Linux is required.' >&2
    exit 1
fi
if [ -r /etc/os-release ]; then
    cat /etc/os-release
fi
printf '\nArchitecture: %s\n' "$(uname -m)"
printf '\nBuild tools:\n'
missing=0
for tool in c++ cmake ninja pkg-config; do
    if command -v "$tool" >/dev/null 2>&1; then
        printf '  Available: %s\n' "$tool"
    else
        printf '  Missing: %s\n' "$tool"
        missing=1
    fi
done
printf '\nAudio runtime tools:\n'
for tool in pipewire pw-loopback pw-dump pw-cli wpctl; do
    if command -v "$tool" >/dev/null 2>&1; then
        printf '  Available: %s\n' "$tool"
    else
        printf '  Missing: %s\n' "$tool"
    fi
done
if [ "$missing" -ne 0 ]; then
    printf '\nBuild prerequisites: sudo apt install build-essential cmake ninja-build pkg-config\n'
fi
exit "$missing"
