#!/usr/bin/env python3
"""Extract and smoke-test a Debian package without installing it. --gui needs a desktop."""
# SPDX-License-Identifier: AGPL-3.0-or-later
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('package', type=Path)
parser.add_argument('--gui', action='store_true')
parser.add_argument('--upgrade-from', type=Path, help='Overlay an older package and exercise legacy configuration migration')
args = parser.parse_args()
package = args.package.resolve()
version = subprocess.check_output(['dpkg-deb', '-f', str(package), 'Version'], text=True).strip()
with tempfile.TemporaryDirectory(prefix='tania-package-check-') as directory:
    root = Path(directory)
    if args.upgrade_from:
        import json
        subprocess.run(['dpkg-deb', '-x', str(args.upgrade_from.resolve()), str(root)], check=True)
        config = root / 'config/tanias-sound-box'
        config.mkdir(parents=True)
        (config / 'settings.json').write_text(json.dumps({'gain':-9, 'limiter':False, 'release':150}))
        (config / 'preferences.json').write_text(json.dumps({'hardware_output':'upgrade-output'}))
        (config / 'presets.json').write_text(json.dumps({'schema':1, 'presets':{'Old preset':{'eq_60':3}}}))
    subprocess.run(['dpkg-deb', '-x', str(package), str(root)], check=True)
    assert (root / 'usr/share/doc/tanias-sound-box/LICENSE').is_file()
    assert (root / 'usr/share/applications/tanias-sound-box.desktop').is_file()
    dependencies = subprocess.check_output(['dpkg-deb','-f',str(package),'Depends'],text=True)
    assert 'python3-tk' in dependencies and 'pipewire-bin' in dependencies
    executable = root / 'usr/bin/tanias-sound-box'
    output = subprocess.check_output([str(executable), '--version'], text=True)
    assert output.strip() == "Tania's Sound Box " + version, output
    subprocess.run([str(executable), '--help'], check=True, stdout=subprocess.DEVNULL)
    assert subprocess.run([str(executable), '--unknown'], capture_output=True).returncode == 2
    ui = root / 'usr/share/tanias-sound-box'
    env = {**os.environ, 'PYTHONPATH': str(ui), 'XDG_CONFIG_HOME': str(root / 'config'),
           'PYTHONDONTWRITEBYTECODE': '1',
           'TANIA_VERIFY_LATEST_STATE': '1' if tuple(map(int,version.split('.')[:2])) >= (0,14) else '0'}
    # Resolve native plugins through installed paths, never through the source tree.
    subprocess.run(['python3', '-c', 'from processing_graph import limiter_plugin; assert limiter_plugin().is_file()'],
                   cwd=root, env=env, check=True)
    if tuple(map(int, version.split('.')[:2])) >= (0, 9):
        subprocess.run(['python3', '-c', "from processing_graph import limiter_plugin; assert limiter_plugin('tania_compressor.so').is_file()"],
                       cwd=root, env=env, check=True)
    if tuple(map(int, version.split('.')[:2])) >= (0, 14):
        checker = Path(__file__).resolve().parents[2] / 'build/test-ladspa'
        if checker.is_file():
            subprocess.run([str(checker), str(root/'usr/lib/tanias-sound-box/tania_limiter.so'),
                            str(root/'usr/lib/tanias-sound-box/tania_compressor.so')], check=True)
    if tuple(map(int, version.split('.')[:2])) >= (0, 15):
        assert 'pulseaudio-utils' in dependencies
        subprocess.run(['python3', '-c', "from processing_graph import limiter_plugin; assert limiter_plugin('tania_mic.so').is_file()"], cwd=root, env=env, check=True)
    if tuple(map(int, version.split('.')[:2])) >= (0, 19):
        assert (ui/'assets/icon-32.png').is_file()
        assert (root/'usr/share/icons/hicolor/scalable/apps/tanias-sound-box.svg').is_file()
        assert 'Icon=tanias-sound-box' in (root/'usr/share/applications/tanias-sound-box.desktop').read_text()
    if args.upgrade_from:
        migration = """from settings_store import load,save
from presets import Presets
values,output=load()
assert values['gain']==-9 and not values['limiter'] and values['release']==150
assert not values['compressor'] and output=='upgrade-output'
assert Presets().all()['Old preset']['eq_60']==3
save(values,output)
assert load()==(values,output)
"""
        subprocess.run(['python3','-c',migration],cwd=root,env=env,check=True)
    if args.gui:
        smoke = '''import time
import os
import tkinter as tk
from sound_box import SoundBox
from controls import validate
root = tk.Tk()
root.withdraw()
app = SoundBox(root)
try:
    deadline = time.monotonic() + 8
    while (app.audio_busy or (hasattr(app,'mic_panel') and (app.mic_panel.busy or app.capture_panel.busy))) and time.monotonic() < deadline:
        root.update()
        time.sleep(.02)
    assert not app.audio_busy, 'Audio query did not finish'
    assert not app.session.enabled, 'Session must require explicit enable'
    if hasattr(app, 'mic_panel'):
        assert len(app.notebook.tabs()) == 3
        assert not app.mic_panel.session.enabled
        assert app.mic_panel.meter.target is None
        assert not app.mic_panel.busy and not app.capture_panel.busy
    validate(app.current_controls())
    if os.environ['TANIA_VERIFY_LATEST_STATE']=='1':
        assert app.control_state.unsaved == (not app.path.exists())
    if hasattr(app, 'preset_choice'):
        app.preset_choice.set('Voice clarity')
        app.load_preset()
        assert app.current_controls()['eq_3000'] == 3
        assert not app.session.enabled
    if hasattr(app, 'compressor'):
        app.compressor.set(True)
        assert app.current_controls()['compressor']
    app.reset()
    validate(app.current_controls())
    assert app.save(), 'Settings failed to save in temporary config'
    if hasattr(app, 'control_state'):
        assert not app.control_state.unsaved
finally:
    app.session.disable()
    if hasattr(app, 'mic_panel'):
        app.mic_panel.close()
        app.capture_panel.close()
    root.destroy()
'''
        subprocess.run(['python3', '-c', smoke], cwd=root, env=env, check=True, timeout=15)
    if tuple(map(int, version.split('.')[:2])) >= (0, 10):
        import json
        data = json.loads(subprocess.check_output([str(executable), '--diagnostics'], cwd=root, env=env, text=True, timeout=15))
        assert data['version'] == version
        assert all(data['runtime']['plugins'].values())
    if args.gui and tuple(map(int,version.split('.')[:2])) >= (0,14):
        ready = json.loads(subprocess.check_output([str(executable),'--check'],cwd=root,env=env,text=True,timeout=15))
        assert ready['readiness']['ready']
print(f'Package {version}: installed layout, version, plugin resolution' + (', GUI smoke' if args.gui else '') + (', extracted upgrade/config migration' if args.upgrade_from else '') + ' passed.')
