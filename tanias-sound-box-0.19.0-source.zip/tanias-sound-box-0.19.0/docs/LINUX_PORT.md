# Linux Mint port

Initial platform: Linux Mint 22.3 Zena (Ubuntu Noble base), Xfce, x86_64.
Version 0.6.0 runs live processing through PipeWire builtin filters, launched by
the Linux C++ startup executable and Python/Tk panel. Gain, balance, nine-band
EQ, stereo-linked limiting, bypass, saved settings, and a post-processing OBS
source are connected.
There is no background service. The original Windows code is excluded from the
Linux build. The native C++ DSP library remains an offline reference/test target.

Version 0.15.0 adds a separate native/PipeWire microphone graph and Capture Point.
See [microphone guide](MICROPHONE.md) for OBS setup and device-control scope.

## File locations

Application identifier: `tanias-sound-box`.

| Purpose | Base variable | Default full path |
| --- | --- | --- |
| Configuration | `XDG_CONFIG_HOME` | `~/.config/tanias-sound-box` |
| Presets/data | `XDG_DATA_HOME` | `~/.local/share/tanias-sound-box` |
| Logs/state | `XDG_STATE_HOME` | `~/.local/state/tanias-sound-box` |

An absolute XDG base receives the application identifier as a subdirectory.
Empty or relative XDG values fall back to the home directory. `--paths` reports
locations without creating files. Future settings code should use these paths.

## Platform replacements

| Windows component | Linux direction |
| --- | --- |
| FxSound driver and WASAPI routing | PipeWire nodes, streams, and routing |
| COM startup and Win32 crash handling | Native Linux startup and error reporting |
| Registry settings | XDG configuration files |
| Tray, notifications, and hotkeys | Xfce-compatible desktop integrations |
| Visual Studio and Windows installer | CMake and CPack DEB |
| Windows-dependent DSP utilities | Audit and port behind Linux interfaces |

The original source directories remain as references and are excluded from the
Linux executable. Next steps: connect to PipeWire, enumerate outputs, build an
explicitly enabled processing path with bypass, audit reusable DSP, and port the
interface. Routing should restore the prior output on disable. Startup must not
change the default device before the processing path is ready.

The current executable has no PipeWire dependency. The future backend will
require `libpipewire-0.3-dev`, available through Mint's package manager.
See the [official PipeWire tutorial](https://docs.pipewire.org/page_tutorial1.html).

## Version 0.3.0 backend logic

`audio_backend.py` queries `pw-dump -N` with a four-second timeout and parses
output nodes and the active default sink from JSON metadata. Node names are
reported rather than stored numeric IDs, which can change between sessions.
Discovery is read-only and does not change volume or routing. The panel queries
in a worker thread to keep the interface responsive. Use `--audio-status` for
headless diagnostics. The DEB depends on `pipewire-bin`.

`tania-dsp` is a native C++ static library with interleaved stereo processing,
master gain, attenuating balance, bypass, and nine Q=1 peaking EQ filters using
the [W3C Audio EQ Cookbook](https://www.w3.org/TR/audio-eq-cookbook/) equations.
Bands at or above Nyquist are skipped. Configuration validates all values before
changing state. The processing loop does not allocate, lock, or perform I/O.
Configuration and processing must be serialized by a single owner; live control
handoff, smoothing, output headroom/limiting, and PipeWire stream integration
remain pending. It is not yet connected to the Python controls or system audio.

CTest covers flat response, dB gain, stereo balance endpoints, exact bypass,
EQ center gain/cut at multiple sample rates, channel isolation, filter state
across blocks, impulse stability, and invalid controls. Discovery tests cover
default metadata formats, input filtering, missing defaults, unavailable
sessions, malformed data, and timeouts.

## Version 0.4.0 virtual devices

| Role | Stable PipeWire identifier | Visible description |
| --- | --- | --- |
| Playback | `tanias_sound_box.playback` | Tania's Sound Box |
| OBS recording source | `tanias_sound_box.recording_monitor` | Tania's Sound Box - Recording Monitor |

Two session-owned `pw-loopback` clients provide a playback sink routed to the
selected hardware and a separate source capturing that sink's monitor ports.
The recording source therefore contains only the mix sent to Sound Box. This is
passthrough audio, not processed DSP audio yet. Physical device identifiers and
descriptions are left intact; the panel labels the destination Hardware Output.

Enable is explicit. No defaults are changed, no microphone is captured, and no
PipeWire daemon configuration is written. Low session priority prevents these
nodes from replacing existing hardware defaults under normal session policy.
Routing uses explicit node names and disables automatic reconnection to other
devices. A runtime lock prevents two app windows from owning the same devices.
Startup failures roll back owned processes. A Linux guardian process removes
loopbacks when the owning app exits, including abnormal termination. The panel
checks active routes every three seconds and stops them if hardware disappears.
Devices are session-only; there is no background service or boot persistence.

The recording label uses an ASCII hyphen for compatibility with the installed
PulseAudio client tooling. Integration checks verify its exact name through
`pactl`, the same server interface used by PulseAudio capture clients. Actual OBS
recording and audible playback still need user testing.

Reference: [PipeWire loopback module](https://docs.pipewire.org/page_module_loopback.html).

## Version 0.5.0 live processing

The route is: application audio → Tania's Sound Box playback sink → stereo
PipeWire EQ/gain graph → Recording Monitor source → selected hardware output.
OBS captures the same post-processing source used for hardware playback.

Each channel has nine `bq_peaking` filters with Q=1 and one single-input mixer
for gain. Gain uses dB-to-amplitude conversion; balance attenuates the opposite
channel. Bypass sets every EQ gain to zero and both channel gains to unity,
without destroying devices or interrupting OBS device identity. Device/stream
volumes set outside the app remain separate from processing bypass.

The graph requests 48 kHz stereo; PipeWire handles conversion to hardware rates.
A temporary client configuration loads the filter-chain without modifying the
sound server configuration. This avoids Mint 1.0.5 pw-cli's size limitation for
loading a large graph as a command argument. Hardware loopback starts only after
its recording-source target exists. Routing priority uses a low positive value.
Internal hardware streams disable remembered volume/target restoration so
user application volume settings do not unexpectedly attenuate the route.
Remembered user-selected Sound Box defaults may still be restored by Linux.

Apply controls sets graph control parameters in place and verifies the actual
values reported by PipeWire. It does not restart nodes. Save settings and live
application are separate. Old settings without a bypass value remain supported.
The UI queries and applies in a serialized worker, keeping audio commands out of
Tk's main thread and displaying confirmed processing/bypass state.

Verification includes an isolated signal test of measured gain, stereo balance,
EQ center boost, and bypass capture. Test nodes use unique names and have no
hardware playback connection. The automated test captures only generated test
signals, not the microphone. Limiters, smooth parameter transitions, latency
measurement, and reconnection after a server restart remain pending.

## Version 0.6.0 dynamics and routing logic

A native `tania_limiter.so` LADSPA module supplies a stereo-linked sample-peak
limiter after EQ/gain and before the recording source. Both channels share one
attenuation envelope, with instantaneous attack and exponential release.
Defaults: enabled, -1 dBFS ceiling, 100 ms release. Ceiling range: -12 to 0 dBFS;
release range: 10 to 1000 ms (currently kept in settings rather than exposed as
an additional slider). Quiet audio passes unchanged. Nonfinite input samples
are replaced by silence. Processing allocates no memory and performs no locks
or I/O. The plugin installs under `lib/tanias-sound-box` and is found relative
to the installed application prefix. Build dependency: `ladspa-sdk`; no separate
LADSPA plugin package is required at runtime.

Bypass disables limiting and neutralizes gain/balance/EQ without changing node
identity. The limiter checkbox can disable only limiting. Old settings receive
default limiter, ceiling, and release values; Reset restores these defaults.

Apply interpolates gain/balance amplitude, EQ dB, ceiling dB, and release over
eight control-rate steps. Protection is enabled before boosts and disabled only
at the end of a transition. Updates are split into batches of at most eight
controls to fit Mint pw-cli's SPA POD builder. Toggled LADSPA controls use Bool
on the PipeWire interface. Final graph parameters are verified. These are
stepped updates via IPC, not sample-accurate ramps; completely click-free changes
are not guaranteed.

Diagnostics now include routing health based on actual links and limiter state.
Startup waits for the monitor-to-hardware links, and the UI checks once per
second while enabled. Missing/error routes stop the owned session instead of
showing a healthy pipeline merely because processes are alive. The ceiling is
reported from the live graph. Native peak/reduction output ports are not exposed
by the installed PipeWire LADSPA host, so the panel does not invent meter values.

Tests cover sample ceilings, stereo linking, quiet-signal transparency, release,
bypass, nonfinite input, stepped-update endpoints and protection order, bounded
control batches, missing links, legacy settings, and measured live limiter/OBS
capture. This is a zero-lookahead sample-peak limiter; true-peak behavior,
oversampling, and mastering-grade lookahead remain future work.


## Versions 0.7.0–0.10.0

See [build history](BUILD_HISTORY.md) for validation of these four milestones.
Session recovery now preserves the chosen output and last applied controls,
repairs hardware routes while keeping the recording source, and recreates owned
processing clients when needed. It never restarts the system audio daemon or
switches to a different hardware destination. Controls can be queued while waiting.
Physical hotplug/server restart are covered with simulated failures; actual OBS
reconnection after graph recreation needs user verification.

Portable preset schema 1 stores validated controls independently of hardware
preferences. Custom names are JSON keys, never filesystem paths. Imports reject
invalid values and unknown formats before changing the library. Factory presets
cannot be overwritten. Atomic writes protect stored settings/presets from partial
JSON writes.

The live signal chain is now stereo EQ → master gain/balance → stereo-linked
compressor → stereo-linked limiter → recording source → hardware route. The
compressor is hard-knee, peak-detected, with attack/release smoothing of reduction
in dB, and makeup gain. It defaults off; controls span -60..0 dBFS threshold,
1..20 ratio, 1..200 ms attack, 10..2000 ms release and 0..12 dB makeup. DSP performs
no allocations, locking or I/O in its process callback. Compressor transients are
allowed during attack; the downstream enabled limiter protects sample peaks.
Limiter release is now exposed. Existing settings/presets receive dynamics defaults.

Diagnostics are read-only summaries, exported by the panel or `--diagnostics`.
They include version, runtime tools, plugin availability and public audio state,
excluding raw PipeWire metadata. Package smoke checks use extracted installed
paths, temporary configuration and optional hidden Tk windows; no global install
is needed. Platform work still includes microphone processing, latency measurement,
true-peak/lookahead limiting, sample-accurate transitions and broader distro support.


## Versions 0.11.0–0.14.0

Playback logic is now a validation candidate. Distinct stereo links and explicit
output identity determine route readiness; editor/storage/desired/confirmed
controls remain separate. The combined versioned settings document migrates
legacy controls/output preferences on save. Checkboxes require Apply just as
sliders do. Unknown settings versions are preserved; damaged data is backed up
before recovery.

Discovery decodes all JSON arrays emitted during pw-dump's initial roundtrip,
including transient update/removal batches. Format/latency diagnostics show
available host information without claiming measured end-to-end latency.
Native stress and isolated live capture exercise multi-rate input, buffer
boundaries, control churn, dynamics, bypass and node identity. Runtime preflight,
read-only readiness, parent-crash cleanup and extracted-upgrade checks complete
the implementation pass. See [validation](VALIDATION.md) for results and required
physical-device, suspend/resume, extended recording and OBS acceptance checks.
