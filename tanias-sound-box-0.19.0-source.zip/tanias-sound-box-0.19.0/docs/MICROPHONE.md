# Microphone and Capture Point (0.16.0)

## Use with OBS

1. Open **Mic configurator**, select your physical input, and click **Enable microphone**.
2. In OBS Audio Input Capture, select **Tania's Sound Box - Microphone**.
3. Adjust the controls and click **Apply**. Save retains the editor and selected input
   for next launch; enabling capture always requires an explicit action.

The playback **Recording Monitor** remains a separate desktop mix. Avoid capturing
both the raw mic and processed mic in OBS: doing so doubles your voice. Keep Sound
Box running. Full server/input recovery recreates the source; verify OBS reconnects
or reselect the source. Recovery waits for your chosen mic instead of substituting
another connected input.

## Controls and tests

The microphone has separate gain, nine-band EQ, channel mixing, high-pass filter,
stereo-linked gate, de-esser, compressor and sample-peak limiter. Mono mix averages
left/right; selecting one channel copies it to both outputs. Mute takes effect
immediately; other edits and presets are staged until Apply. Bypass preserves mute.
The de-esser reduces high-frequency content above its threshold. The gate attenuates
quiet sections; these are not AI noise suppression or acoustic echo cancellation.

Start a level test explicitly to see peak, RMS and clipping. Choose raw input or
processed output. **Record 5s** captures a temporary WAV; export is explicit.
**Room noise 3s** measures the selected raw input while you remain quiet, then stages
a suggested gate threshold. Review and Apply it before use. Test files are removed
when the panel closes. No recording starts merely by opening the app.

Monitoring and recorded-test playback use your selected hardware output. Monitoring
is off by default. Wear headphones to prevent feedback and avoid listening to
both OBS monitoring and Sound Box monitoring simultaneously.

Mic settings and custom presets are separate from playback settings. Preset exports
contain controls, not your hardware identity. Applying edits verifies PipeWire's
reported controls; meters measure an explicitly opened audio stream.

## Capture Point

The device table has a Sound Box name beside the full system name. The Sound Box
points table shows unused and active devices, their assigned jobs and available
hardware connections. Select a point to set its name/job. **Use input for mic**
assigns Microphone and selects it in the configurator without enabling capture.
Auxiliary input and Desktop capture jobs are excluded from the mic chooser;
Unassigned inputs can still be selected manually. Existing active mic processing
continues until explicitly disabled if its job is reassigned.

A wired headset may be a port on the built-in device, rather than a separate
source. Select its connection in the points table, then **Use port**. Ports share
the endpoint job; they are not independently usable microphones unless Linux
exposes separate sources. The mic target display shows the active port and system
ID. Renaming cannot create an input Linux has not exposed.

For active app streams, select a running app and a destination device, then
**Move selected app to selected device**. Capture uses inputs; playback uses
outputs. These moves apply to the running stream and may reset when the app
restarts. Native PipeWire apps can require their own device selector.

This tab discovers audio inputs, outputs, monitor sources, app streams and sound
cards. Device aliases and roles are local to Sound Box; they do not rename hardware
IDs or labels in OBS. Hidden devices disappear from future Sound Box choices without
stopping an already active session.

Volume/mute, **Make system default**, hardware ports, card profiles and moving an
app stream modify the Linux audio server only after you select the corresponding
command. Defaults and profile changes can affect other applications; changing a
profile may remove and recreate devices. Sound Box's own processing streams are
protected from manual moves here. Unavailable controls remain unavailable for
nodes which do not have a PulseAudio-compatible endpoint. Format and requested
scheduling latency are discovery information, not measured end-to-end latency.

## Validation

Native DSP tests cover multiple sample rates, mixing, gate, high-pass, de-essing,
neutral processing and nonfinite input. Logic tests cover settings/presets, selected
input recovery, confirmation, device edits and protected routing. An opt-in live
synthetic input test verifies actual PipeWire routing, mono/gain, meters, WAV export,
mute and limiting without opening a physical microphone. Hidden Tk checks verify
three tabs, independent settings and no automatic capture. Physical mic quality,
headphone monitoring and OBS reconnection still need your listening tests.
