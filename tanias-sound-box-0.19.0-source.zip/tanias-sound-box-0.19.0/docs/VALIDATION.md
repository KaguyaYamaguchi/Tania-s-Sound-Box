# Playback logic validation — 0.14.0 candidate

This build completes the planned implementation pass for the current Linux Mint
playback-processing scope. It is ready for user validation; physical devices,
actual OBS behavior and extended recording still need the checks below.

Run from the checkout with `./build/tanias-sound-box`, or install the latest:

```sh
sudo apt install ./build/packages/tanias-sound-box-0.14.0-Linux.deb
tanias-sound-box --version
tanias-sound-box --check
tanias-sound-box
```

`--check` is read-only and exits nonzero with actionable errors if the runtime is
not ready. Launching does not enable processing. Fresh-system installation and
an actual package-manager upgrade remain user checks; automated verification
uses extracted packages and temporary configuration.

| Check | Expected behavior |
| --- | --- |
| Route a music/video app to Tania's Sound Box | Audio reaches the selected hardware output. Other apps retain their existing routes. |
| OBS Audio Input Capture | Select Tania's Sound Box - Recording Monitor. Capture includes processed playback; microphone is separate. Avoid capturing this same mix twice. |
| Edit gain/EQ/dynamics, Save, then Apply | Edits stay pending until Apply. Save changes storage only. Confirmed controls are distinguished from new edits and reconnect queues. |
| Bypass, limiter and compressor | Checkboxes stage changes until Apply. Bypass neutralizes processing and keeps the monitor. Compressor defaults off; limiter defaults to -1 dBFS. |
| Save/export/import a preset | Controls roundtrip; output selection stays separate. Factory exports use a custom name. Loading a preset stages it without applying. |
| Unplug/reconnect selected USB/headphone output | Wait for that output, retain the processing source and last applied controls, and resume when its node returns. No switch to a different output. |
| Change Bluetooth profile or output node name | If the original node no longer exists, disable and explicitly choose the new output. Device-name guessing is intentionally avoided. |
| Suspend/resume while enabled | Restore the selected route and last applied controls. Disable must cancel reconnect intent. |
| OBS after a full graph/server recreation | Node IDs change. Verify OBS reconnects; refresh/reselect its source if necessary. Hardware-route repair alone preserves the source ID. |
| Record for 30–60 minutes | Assess audible quality, sync, CPU usage and stability. Export diagnostics with any fault. Requested node latency in diagnostics is not measured end-to-end latency. |
| Close and reopen | Virtual devices disappear on close; settings/output preference remain. Reopening requires explicit Enable. |

## Automated checks

Normal CTest creates no audio devices:

```sh
ctest --test-dir build --output-on-failure
```

Thirteen suites cover plugin ABI/wiring, native stress, DSP, discovery updates,
channel links, ownership/parent crash, runtime errors, control state,
settings migration/recovery, diagnostics, presets, session recovery and graph
controls. Native stress processes approximately 765 seconds of audio data across
8–192 kHz with varied blocks, in-place buffers and exceptional samples. This is
not a measure of the full PipeWire pipeline's CPU usage.

Live generated-signal checks create uniquely named temporary devices without a
hardware route or microphone capture:

```sh
python3 linux/tests/test_live_audio.py --rate 44100
python3 linux/tests/test_live_audio.py --rate 48000
python3 linux/tests/test_live_audio.py --rate 96000
python3 linux/tests/test_live_soak.py --seconds 60 --updates 30
```

The completed soak captured 60 seconds through 30 changes, retained node identity,
reported no detected silent windows, and stayed under the -6 dBFS ceiling. Its
JSON result is in `build/validation/live-soak.json`. Longer isolated runs are
available with `--seconds 1800 --updates 120`; they supplement actual recording.

With the panel disabled, the recovery test temporarily owns a hardware route
without playing a tone or capturing a microphone:

```sh
python3 linux/tests/test_live_recovery.py
```

Package verification does not install anything:

```sh
python3 linux/scripts/verify-package.py build/packages/tanias-sound-box-0.14.0-Linux.deb --gui --upgrade-from build/packages/tanias-sound-box-0.10.0-Linux.deb
```

Remaining advanced features, such as microphone processing, true-peak/lookahead
limiting and sample-accurate transitions, are outside this playback logic pass.
The next Sound Box phase can be scoped after user validation.
