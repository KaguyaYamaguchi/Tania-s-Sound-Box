# Linux build milestones

## 0.7.0 — Session reliability

- Saved output-node preference, separate from processing settings.
- Explicit enable remains required each app launch.
- Device loss waits for the selected output; no fallback to other speakers.
- Hardware-route repair keeps the processing graph and recording source alive.
- Processing-client/server loss retains session intent and last applied controls,
  retries with bounded backoff, and recreates the route when available.
- Disable cancels pending recovery; controls can be queued while reconnecting.

Validation: six CTest suites passed. Live owned-client loss/recovery and
hardware-route repair passed; hardware repair preserved the recording-source
ID. Physical unplug and a real PipeWire service restart were simulated in unit
tests rather than performed on the user's desktop. A full server/graph restart
recreates node IDs; OBS reconnection behavior needs user verification.

## 0.8.0 — Portable sound presets

- Flat, Voice clarity and Warm music factory presets.
- Named custom presets, JSON import/export and schema validation.
- Atomic storage; invalid imports preserve the existing library.
- Presets contain sound controls, not output-device preferences.
- Loading a preset stages controls; Apply controls updates live audio.

Validation: seven CTest suites passed, including preset roundtrip, rejection and
hardware-preference exclusion. Separate Debian package produced.

## 0.9.0 — Stereo dynamics

- Native stereo-linked compressor before the output limiter, disabled by default.
- Threshold, ratio, attack, release and makeup-gain controls.
- Limiter release exposed in the panel; legacy settings/presets migrate through defaults.
- Bypass disables both dynamics stages while keeping the OBS monitor available.
- Compressor attack intentionally permits transients; the final limiter provides
  sample-peak protection when enabled. Neither stage is a true-peak limiter.

Validation: eight CTest suites passed. Isolated live PipeWire capture verified
compression against the expected curve and preserved stereo balance, alongside
gain/EQ/limiter/bypass regression checks. At a -40 dBFS threshold and 4:1 ratio,
a 0.02-amplitude test tone measured approximately 0.01193 after compression.
Separate Debian package produced.

## 0.10.0 — Diagnostics and package verification

- Export diagnostics from the panel or read JSON with `--diagnostics`.
- Reports application/runtime versions, tools, plugin presence and public device,
  routing, limiter and session state; excludes raw server metadata.
- Honest disconnected-server status and queued-controls messages.
- If a processing client disappears during Apply, retain enable intent and queue
  the complete control set for recovery instead of cancelling the session.
- Reusable extracted-package and opt-in live recovery checks.

Validation: nine CTest suites passed, including missing-runtime diagnostics and
Apply/client-loss race coverage. All four 0.7.0–0.10.0 Debian packages passed
extracted installed-layout, executable-version, plugin-resolution and hidden Tk
UI smoke checks with temporary settings. Latest packaged diagnostics reported
0.10.0 and resolved both bundled plugins. Live route repair preserved the OBS
source ID; full processing-client recovery restored gain and compressor settings.
Isolated generated-signal capture verified gain, balance, EQ, limiter ceiling,
disabled limiting, bypass and stereo-linked compression. No microphone audio
was captured, no packages were globally installed, and no system audio daemon
was restarted during validation. Actual OBS reconnect after graph recreation,
physical device hotplug and audible assessment remain user-side checks.

## Artifacts

Packages are under `build/packages/`:

- `tanias-sound-box-0.7.0-Linux.deb`
- `tanias-sound-box-0.8.0-Linux.deb`
- `tanias-sound-box-0.9.0-Linux.deb`
- `tanias-sound-box-0.10.0-Linux.deb`

The build-directory executable and Python/native modules are the latest 0.10.0.

## 0.11.0 — Destination and channel integrity

- Route health requires distinct input ports for both stereo channels; mono
  hardware may use one. Duplicate link objects cannot fake a stereo connection.
- A healthy route must match the explicitly selected output.
- Session diagnostics include graph generations, route repairs and retry timing.
- Device-loss reports refresh after detaching the hardware route.

Validation: nine suites passed, including repeated simulated hotplug/suspend
cycles and wrong-destination repair. Live graph and hardware-route recovery
passed. Separate Debian package produced.

## 0.12.0 — Editor, saved and confirmed state

- Independent editor, persisted, desired and verified control state.
- Editing during Apply leaves the newer edit pending after the older result.
- Checkboxes stage changes until Apply, consistently with sliders and presets.
- Controls and output preference save atomically in one versioned document;
  legacy settings and preferences migrate on save.
- Writes flush/fsync before replacement; failed writes preserve the old file.
- Preset schemas reject booleans and reserved/duplicate library names.

Validation: ten suites passed, including write failure, legacy migration and
queued/confirmed state. Extracted package hidden-Tk smoke passed. Separate
Debian package produced.

## 0.13.0 — Signal and discovery stability

- Compressor avoids unnecessary silence/unity calculations and denormal tails,
  and bounds extreme makeup outputs to finite float values.
- Report available device format and requested scheduling latency without
  presenting it as measured end-to-end latency.
- Decode concatenated discovery/update arrays emitted during node churn;
  merge updates and remove disappeared objects instead of rejecting valid dumps.
- Native multi-rate/block/in-place stress and opt-in continuous live capture.

Validation: eleven suites passed. Native stress processed approximately 765
seconds of signal data across 8–192 kHz. Live gain/balance/EQ/dynamics/bypass
capture passed at 44.1, 48 and 96 kHz. Discovery failure observed during
concurrent node churn was fixed and the failing 44.1 kHz capture rerun passed.
A corrected 60-second live soak with 30 changes reported no detected silent
windows, preserved node ID and a 0.501205 sample peak under a -6 dBFS ceiling.
Extracted package hidden-Tk smoke passed. Separate Debian package produced.

## 0.14.0 — Playback logic validation candidate

- Runtime requirements fail before spawning clients, with actionable messages.
- Read-only `--check` returns readiness JSON and a meaningful exit status.
- Apply after client loss queues controls without claiming confirmation.
- Closing prevents another periodic query from delaying shutdown.
- Guardians clean owned graph configuration after parent-process death.
- Damaged settings are backed up before recovery; unknown formats are preserved.
- Factory preset exports import under a custom name.
- Native plugin-host ABI/wiring checks and extracted-package upgrade verification.
- Debian dependency specifies the required Python minimum.

Validation: thirteen suites passed, including actual killed-parent guardian
cleanup with a fake audio client, plugin ABI/dynamics, corrupt-settings backup,
unknown-format preservation and client-loss confirmation. Latest extracted
package passed native plugin load, hidden UI, readiness and 0.10-to-0.14 legacy
settings/preset migration checks. Live recovery retained selected output and
controls. No service restart or global package installation was performed.
See [validation guide](VALIDATION.md) for the remaining user-side acceptance
checks. All four 0.11–0.14 milestone packages are under `build/packages/`.

Final release verification also passed a clean Release build and installation
under a temporary prefix, resolving both installed native plugins and versioned
diagnostics. Fresh/unreadable settings are reported as unsaved until successfully
stored. Validation artifacts are under `build/validation/`; package checksums are
in `build/packages/SHA256SUMS`.

## 0.15.0 — Microphone and Capture Point

- Independent mic graph and explicitly enabled OBS microphone source.
- Native channel mixing, high-pass, gate and de-esser ahead of EQ/dynamics.
- Immediate mute; independently staged, saved and confirmed mic controls/presets.
- Explicit level testing, temporary WAV recording/export, room-noise calibration
  and optional monitoring to selected hardware.
- Capture Point device inventory, local aliases/roles, real volume/mute, explicit
  defaults, hardware ports/card profiles, and app-stream routing.
- Missing-input recovery waits for the selected device without substituting one.
- Three testing UI tabs; no automatic microphone capture on launch.

Validation: native mic DSP, mic logic and Capture Point suites added. Live generated
input passed routing, mono/gain, metering, WAV export, mute, limiter and stable source
identity. Hidden Tk passed all three tabs, real inventory and independent staged
settings without automatic capture. See [microphone guide](MICROPHONE.md).

Final 0.15 verification: all sixteen CTest suites passed. The Debian package
passed installed plugin resolution, hidden GUI, readiness and extracted upgrade
from 0.10 with playback settings/preset migration. Checksums and results are in
`build/packages/SHA256SUMS` and `build/validation/microphone-build.json`.

## 0.16.0 — Device points and target clarity

- Sound Box names and full system IDs shown in separate device columns.
- Device job table shows unused points, current app use and available hardware
  connections, including headset ports sharing a built-in audio endpoint.
- Unassigned jobs and microphone eligibility; selecting Use input for mic assigns
  the mic job without enabling capture. Existing processing remains explicit.
- Active stream routing instructions, examples and friendly destination labels.
- Mic target display identifies source, system ID, active port and processed output.
- Existing system volume and mute controls retained.

Validation: sixteen regression suites and hidden three-tab UI test passed, with
new naming, delegation, point-selection and target-display checks.

## 0.17.0 — Quiet background refresh

- Discovery tables reuse rows keyed by device identity and stream direction/index.
- Unchanged rows are not rewritten; only changed, added or removed rows update.
- Device/app selection, expanded connections and unsaved device edits survive polls.
- Device choosers update only when their list or selected identity changes.
- Periodic checks no longer flash controls disabled or show Checking PipeWire.
- Explicit processing commands still serialize work and disable controls while busy.

Validation: all sixteen regression suites passed. Hidden Tk additionally verified
no row insertion/deletion/move/rewrite on unchanged discovery, selection and draft
preservation across reordered devices, preserved collapsed points and changed volume
updates in place.

## 0.18.0 — Desktop UI overhaul

- Persistent workspace sidebar and application header; shared dark navy/amber theme.
- Output routing summary and master card ahead of separate EQ and dynamics pages.
- Mic pages for input/EQ, voice cleanup, dynamics and explicit tests/listening.
- Vertical microphone EQ faders with live values; prominent Apply action.
- Capture Point pages for devices, device jobs, app routing and hardware profiles.
- Tables retain stable refresh identity and offer horizontal scrolling.
- Palette centralized in ui_design.py; audio routing and saved-control logic retained.

Design references: [EasyEffects](https://wwmm.github.io/easyeffects/) input/output
organization and [Sonar](https://support.steelseries.com/hc/en-us/articles/16954265292173-How-does-Sonar-work)
channel/device organization. No upstream UI assets were copied.

Validation: all sixteen regression suites passed. Desktop UI tests verified sidebar
selection, grouped pages, control/settings bindings, device identity and quiet
refresh. Rendered window previews were reviewed; package and extracted upgrade
from 0.17 passed. Artifacts are under `build/validation/`.

## 0.19.0 — Logo and corrected name

- Original amber waveform-in-box mark with a navy app tile.
- Header reads Tania's Sound Box, with no separating slash.
- Logo beside the header name and in the window/desktop launcher icon.
- Scalable dark/light wordmarks and PNG icon sizes included in linux/assets.
- Packaged icon registration uses the Linux hicolor icon directory.

Validation: desktop UI smoke passed with real logo loading; extracted package
checks cover both the Tk asset path and Linux launcher icon registration.
